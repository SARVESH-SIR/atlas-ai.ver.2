'use client';

import { motion } from 'framer-motion';
import { Home, Search, Settings, User, Zap } from 'lucide-react';

export default function NavigationRing() {
  const navItems = [
    { icon: Home, label: 'Home', color: 'from-atlas-primary to-atlas-accent' },
    { icon: Search, label: 'Search', color: 'from-atlas-secondary to-atlas-primary' },
    { icon: Zap, label: 'AI Mode', color: 'from-atlas-accent to-atlas-secondary' },
    { icon: Settings, label: 'Settings', color: 'from-atlas-primary to-atlas-secondary' },
    { icon: User, label: 'Profile', color: 'from-atlas-accent to-atlas-primary' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 1.2 }}
      className="flex items-center justify-center gap-3 mt-6"
    >
      {navItems.map((item, index) => {
        const Icon = item.icon;
        return (
          <motion.button
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.3 + index * 0.1 }}
            className="group relative"
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.9 }}
          >
            <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${item.color} p-0.5`}>
              <div className="w-full h-full rounded-full bg-atlas-dark flex items-center justify-center hover:bg-transparent transition-colors">
                <Icon className="w-5 h-5 text-atlas-primary group-hover:text-white transition-colors" />
              </div>
            </div>
            <motion.div
              className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity"
              initial={false}
            >
              <span className="text-xs text-atlas-accent whitespace-nowrap">
                {item.label}
              </span>
            </motion.div>
          </motion.button>
        );
      })}
    </motion.div>
  );
}

