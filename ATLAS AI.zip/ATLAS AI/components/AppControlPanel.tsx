'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Search, Command, Zap, X, CheckCircle2, Lightbulb } from 'lucide-react';
import { actionExecutor } from '@/lib/atlas-core/actions/action-executor';
import { appController } from '@/lib/atlas-core/actions/app-controller';

interface CommandHistory {
  id: string;
  command: string;
  status: 'success' | 'error' | 'pending';
  message: string;
  timestamp: Date;
}

export default function AppControlPanel() {
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState<CommandHistory[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [availableApps] = useState(appController.getAvailableApps());
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const executeCommand = async () => {
    if (!command.trim() || isExecuting) return;

    const commandText = command.trim();
    setCommand('');
    setIsExecuting(true);

    // Add to history as pending
    const pendingId = Date.now().toString();
    setHistory(prev => [{
      id: pendingId,
      command: commandText,
      status: 'pending',
      message: 'Executing...',
      timestamp: new Date(),
    }, ...prev]);

    try {
      const result = await actionExecutor.executeCommand(commandText);

      // Update history with result
      setHistory(prev => prev.map(item =>
        item.id === pendingId
          ? {
              ...item,
              status: result.success ? 'success' : 'error',
              message: result.message,
            }
          : item
      ));
    } catch (error: any) {
      setHistory(prev => prev.map(item =>
        item.id === pendingId
          ? {
              ...item,
              status: 'error',
              message: error.message || 'Command execution failed',
            }
          : item
      ));
    } finally {
      setIsExecuting(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      executeCommand();
    }
  };

  const quickCommands = [
    { text: 'Open Google', icon: Search },
    { text: 'Open YouTube', icon: Play },
    { text: 'Volume Up', icon: Zap },
    { text: 'Take Screenshot', icon: Command },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center gap-2 mb-4">
        <Command className="w-5 h-5 text-atlas-primary" />
        <h3 className="text-atlas-primary text-lg font-bold glow-text">App Control</h3>
      </div>

      {/* Command Input */}
      <div className="mb-4">
        <div className="relative">
          <input
            type="text"
            value={command}
            onChange={(e) => {
              setCommand(e.target.value);
              // Update suggestions as user types
              if (e.target.value.trim()) {
                const { getCommandSuggestions } = require('@/lib/atlas-core/actions/command-helpers');
                const newSuggestions = getCommandSuggestions(e.target.value);
                setSuggestions(newSuggestions);
              } else {
                setSuggestions([]);
              }
            }}
            onKeyPress={handleKeyPress}
            onFocus={() => {
              if (command.trim()) {
                const { getCommandSuggestions } = require('@/lib/atlas-core/actions/command-helpers');
                setSuggestions(getCommandSuggestions(command));
              }
            }}
            placeholder='Try: "open Google" or "volume up"'
            className="w-full bg-atlas-darker border border-atlas-primary/30 rounded-lg px-4 py-2 text-white text-sm placeholder-atlas-accent/50 focus:outline-none focus:border-atlas-primary transition-colors"
            disabled={isExecuting}
          />
          
          {/* Suggestions Dropdown */}
          {suggestions.length > 0 && command.trim() && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute top-full left-0 right-0 mt-1 bg-atlas-dark border border-atlas-primary/30 rounded-lg shadow-lg z-50 max-h-40 overflow-y-auto"
            >
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setCommand(suggestion);
                    setSuggestions([]);
                  }}
                  className="w-full px-3 py-2 text-left text-white text-xs hover:bg-atlas-primary/20 transition-colors border-b border-atlas-primary/10 last:border-b-0"
                >
                  {suggestion}
                </button>
              ))}
            </motion.div>
          )}
        </div>
        <div className="flex gap-2 mt-2">
          <motion.button
            onClick={executeCommand}
            disabled={!command.trim() || isExecuting}
            className="px-4 py-2 bg-gradient-to-r from-atlas-primary to-atlas-accent rounded-lg text-white disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 transition-transform flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isExecuting ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <Zap className="w-4 h-4" />
                </motion.div>
                Execute
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Execute
              </>
            )}
          </motion.button>
        </div>
      </div>

      {/* Command Examples */}
      <div className="mb-4 p-3 bg-atlas-darker/50 rounded-lg border border-atlas-primary/20">
        <div className="flex items-center gap-2 mb-2">
          <Lightbulb className="w-4 h-4 text-atlas-primary" />
          <p className="text-atlas-accent text-xs font-semibold">Try These Commands:</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {['open Google', 'volume up', 'open YouTube', 'brightness 50%'].map((example) => (
            <button
              key={example}
              onClick={() => setCommand(example)}
              className="px-2 py-1 bg-atlas-primary/10 border border-atlas-primary/30 rounded text-atlas-accent text-xs hover:bg-atlas-primary/20 hover:border-atlas-primary transition-all"
            >
              {example}
            </button>
          ))}
        </div>
      </div>

      {/* Quick Commands */}
      <div className="mb-4">
        <p className="text-atlas-accent text-xs mb-2">Quick Commands:</p>
        <div className="flex flex-wrap gap-2">
          {quickCommands.map((qc, index) => {
            const Icon = qc.icon;
            return (
              <motion.button
                key={qc.text}
                onClick={() => setCommand(qc.text)}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="px-3 py-1.5 bg-atlas-darker border border-atlas-primary/30 rounded-lg text-atlas-accent text-xs hover:border-atlas-primary hover:text-atlas-primary transition-all flex items-center gap-1.5"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Icon className="w-3 h-3" />
                {qc.text}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Available Apps */}
      <div className="mb-4">
        <p className="text-atlas-accent text-xs mb-2">Available Apps ({availableApps.length}):</p>
        <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
          {availableApps.slice(0, 12).map((app) => (
            <button
              key={app.name}
              onClick={() => setCommand(`open ${app.name}`)}
              className="px-2 py-1 bg-atlas-darker/50 border border-atlas-primary/20 rounded text-atlas-accent text-xs hover:border-atlas-primary hover:text-atlas-primary transition-all"
            >
              {app.name}
            </button>
          ))}
        </div>
      </div>

      {/* Command History */}
      <div className="border-t border-atlas-primary/30 pt-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-atlas-accent text-xs">Recent Commands:</p>
          {history.length > 0 && (
            <button
              onClick={() => setHistory([])}
              className="text-atlas-accent text-xs hover:text-atlas-primary transition-colors"
            >
              Clear
            </button>
          )}
        </div>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          <AnimatePresence>
            {history.length === 0 ? (
              <p className="text-atlas-accent text-xs text-center py-4 opacity-50">
                No commands yet. Try a command above!
              </p>
            ) : (
              history.slice(0, 5).map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className={`p-2 rounded-lg border text-xs ${
                    item.status === 'success'
                      ? 'bg-green-500/10 border-green-500/30'
                      : item.status === 'error'
                      ? 'bg-red-500/10 border-red-500/30'
                      : 'bg-atlas-darker border-atlas-primary/30'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {item.status === 'success' ? (
                      <CheckCircle2 className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                    ) : item.status === 'error' ? (
                      <X className="w-3 h-3 text-red-400 mt-0.5 flex-shrink-0" />
                    ) : (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      >
                        <Zap className="w-3 h-3 text-yellow-400 mt-0.5 flex-shrink-0" />
                      </motion.div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-semibold truncate">{item.command}</p>
                      <p className={`text-xs mt-0.5 ${
                        item.status === 'success' ? 'text-green-400' : item.status === 'error' ? 'text-red-400' : 'text-yellow-400'
                      }`}>
                        {item.message}
                      </p>
                      <p className="text-atlas-accent/60 text-xs mt-1">
                        {item.timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

