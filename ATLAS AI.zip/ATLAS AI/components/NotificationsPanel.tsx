'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X, CheckCircle2, AlertCircle, Info, AlertTriangle } from 'lucide-react';

interface Notification {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

export default function NotificationsPanel() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'success',
      title: 'System Online',
      message: 'All systems operational and running smoothly.',
      timestamp: new Date(),
      read: false,
    },
    {
      id: '2',
      type: 'info',
      title: 'Weather Update',
      message: 'Weather data refreshed successfully.',
      timestamp: new Date(Date.now() - 60000),
      read: false,
    },
  ]);

  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    // Simulate new notifications
    const interval = setInterval(() => {
      const types: Notification['type'][] = ['success', 'info', 'warning'];
      const titles = [
        'Update Available',
        'Backup Complete',
        'New Message',
        'System Optimized',
      ];
      const messages = [
        'New features are available. Update now?',
        'System backup completed successfully.',
        'You have a new message.',
        'System optimization completed.',
      ];

      const randomIndex = Math.floor(Math.random() * titles.length);
      
      const newNotification: Notification = {
        id: Date.now().toString(),
        type: types[Math.floor(Math.random() * types.length)],
        title: titles[randomIndex],
        message: messages[randomIndex],
        timestamp: new Date(),
        read: false,
      };

      setNotifications(prev => [newNotification, ...prev].slice(0, 10));
    }, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };

  const deleteNotification = (id: string) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="w-5 h-5 text-green-400" />;
      case 'info':
        return <Info className="w-5 h-5 text-blue-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-400" />;
    }
  };

  return (
    <div className="fixed top-20 right-4 z-50">
      {/* Notification Bell */}
      <motion.button
        onClick={() => setIsExpanded(!isExpanded)}
        className="relative w-12 h-12 rounded-full bg-gradient-to-br from-atlas-primary to-atlas-accent flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Bell className="w-6 h-6 text-white" />
        {unreadCount > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full text-xs flex items-center justify-center text-white font-bold"
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </motion.span>
        )}
      </motion.button>

      {/* Notifications Panel */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="absolute top-14 right-0 w-80 bg-atlas-dark rounded-lg border border-atlas-primary shadow-2xl max-h-[500px] overflow-hidden flex flex-col hologram-effect"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-atlas-primary/30">
              <h3 className="text-atlas-primary font-semibold glow-text">Notifications</h3>
              <div className="flex gap-2">
                <button
                  onClick={clearAll}
                  className="text-xs text-atlas-accent hover:text-atlas-primary transition-colors"
                >
                  Clear All
                </button>
                <button
                  onClick={() => setIsExpanded(false)}
                  className="p-1 hover:bg-atlas-primary/20 rounded transition-colors"
                >
                  <X className="w-4 h-4 text-atlas-accent" />
                </button>
              </div>
            </div>

            {/* Notifications List */}
            <div className="flex-1 overflow-y-auto p-2">
              <AnimatePresence>
                {notifications.length === 0 ? (
                  <div className="text-center py-8 text-atlas-accent text-sm">
                    <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No notifications</p>
                  </div>
                ) : (
                  notifications.map((notification) => (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      onClick={() => markAsRead(notification.id)}
                      className={`p-3 rounded-lg mb-2 cursor-pointer transition-all ${
                        notification.read
                          ? 'bg-atlas-darker/50 opacity-60'
                          : 'bg-atlas-darker border border-atlas-primary/30'
                      } hover:bg-atlas-darker hover:border-atlas-primary`}
                    >
                      <div className="flex gap-3">
                        {getIcon(notification.type)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="text-white text-sm font-semibold">{notification.title}</h4>
                            {!notification.read && (
                              <div className="w-2 h-2 bg-atlas-primary rounded-full flex-shrink-0 mt-1" />
                            )}
                          </div>
                          <p className="text-atlas-accent text-xs mt-1">{notification.message}</p>
                          <p className="text-atlas-accent text-xs mt-2 opacity-60">
                            {notification.timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNotification(notification.id);
                          }}
                          className="p-1 hover:bg-red-500/20 rounded transition-colors flex-shrink-0"
                        >
                          <X className="w-3 h-3 text-red-400" />
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

