'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, X, Check, AlertCircle, Lightbulb, TrendingUp, Zap } from 'lucide-react';
import { proactiveAssistant, type ProactiveSuggestion } from '@/lib/atlas-core/jarvis/proactive-assistant';
import { actionExecutor } from '@/lib/atlas-core/actions/action-executor';

export default function ProactiveSuggestions() {
  const [suggestions, setSuggestions] = useState<ProactiveSuggestion[]>([]);
  const [expanded, setExpanded] = useState(true);

  useEffect(() => {
    // Get initial suggestions
    const initialSuggestions = proactiveAssistant.getContextualSuggestions();
    setSuggestions(initialSuggestions);

    // Update suggestions periodically
    const interval = setInterval(() => {
      const newSuggestions = proactiveAssistant.getContextualSuggestions();
      setSuggestions(newSuggestions);
    }, 60000); // Update every minute

    return () => clearInterval(interval);
  }, []);

  const handleDismiss = (id: string) => {
    proactiveAssistant.dismissSuggestion(id);
    setSuggestions(prev => prev.filter(s => s.id !== id));
  };

  const handleAction = async (suggestion: ProactiveSuggestion) => {
    if (suggestion.action) {
      await actionExecutor.executeCommand(suggestion.action.command);
      handleDismiss(suggestion.id);
    }
  };

  const getIcon = (type: ProactiveSuggestion['type']) => {
    switch (type) {
      case 'reminder':
        return <AlertCircle className="w-4 h-4" />;
      case 'recommendation':
        return <Lightbulb className="w-4 h-4" />;
      case 'alert':
        return <AlertCircle className="w-4 h-4" />;
      case 'optimization':
        return <TrendingUp className="w-4 h-4" />;
      case 'opportunity':
        return <Zap className="w-4 h-4" />;
      default:
        return <Sparkles className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: ProactiveSuggestion['priority']) => {
    switch (priority) {
      case 'urgent':
        return 'from-red-500 to-orange-500';
      case 'high':
        return 'from-orange-500 to-yellow-500';
      case 'medium':
        return 'from-blue-500 to-cyan-500';
      case 'low':
        return 'from-gray-500 to-gray-600';
      default:
        return 'from-blue-500 to-cyan-500';
    }
  };

  if (suggestions.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-atlas-primary animate-pulse" />
          <h3 className="text-atlas-primary text-lg font-bold glow-text">
            Proactive Suggestions
          </h3>
          <span className="px-2 py-0.5 bg-atlas-primary/20 rounded-full text-atlas-accent text-xs">
            {suggestions.length}
          </span>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-atlas-accent hover:text-atlas-primary transition-colors"
        >
          {expanded ? '−' : '+'}
        </button>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="space-y-2"
          >
            {suggestions.slice(0, 5).map((suggestion, index) => (
              <motion.div
                key={suggestion.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-3 rounded-lg border bg-gradient-to-r ${getPriorityColor(suggestion.priority)}/10 border-atlas-primary/30 hover:border-atlas-primary transition-all`}
              >
                <div className="flex items-start gap-2">
                  <div className={`mt-0.5 p-1.5 rounded-lg bg-gradient-to-r ${getPriorityColor(suggestion.priority)}/20 text-atlas-primary`}>
                    {getIcon(suggestion.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <h4 className="text-white text-sm font-semibold mb-1">
                          {suggestion.title}
                        </h4>
                        <p className="text-atlas-accent text-xs mb-2">
                          {suggestion.message}
                        </p>
                        {suggestion.action && (
                          <button
                            onClick={() => handleAction(suggestion)}
                            className="px-3 py-1 bg-gradient-to-r from-atlas-primary to-atlas-accent rounded text-white text-xs hover:scale-105 transition-transform"
                          >
                            {suggestion.action.label}
                          </button>
                        )}
                      </div>
                      <button
                        onClick={() => handleDismiss(suggestion.id)}
                        className="text-atlas-accent hover:text-atlas-primary transition-colors p-1"
                        title="Dismiss"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {suggestions.length > 5 && expanded && (
        <div className="mt-2 text-center">
          <span className="text-atlas-accent text-xs">
            +{suggestions.length - 5} more suggestions
          </span>
        </div>
      )}
    </motion.div>
  );
}

