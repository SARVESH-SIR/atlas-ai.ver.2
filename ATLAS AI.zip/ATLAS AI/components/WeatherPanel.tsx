'use client';

import { motion } from 'framer-motion';
import { Cloud, Sun, Droplets, Wind, Eye, Gauge, RefreshCw } from 'lucide-react';
import { useWeather } from '@/hooks/useWeather';

export default function WeatherPanel() {
  const { weather, isLoading, refresh } = useWeather();

  if (!weather || isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.4 }}
        className="hologram-effect rounded-lg p-4"
      >
        <div className="flex items-center justify-center h-64">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          >
            <RefreshCw className="w-8 h-8 text-atlas-primary" />
          </motion.div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.4 }}
      className="hologram-effect rounded-lg p-4"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-atlas-primary text-lg font-bold glow-text">
            {weather.location}
          </h3>
          <div className="flex items-center gap-2">
            <p className="text-atlas-accent text-xs mt-1">
              Updated at {weather.lastUpdated}
            </p>
            <motion.button
              onClick={refresh}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="text-atlas-primary hover:text-atlas-accent transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
            </motion.button>
          </div>
        </div>
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        >
          <Sun className="w-8 h-8 text-yellow-400" />
        </motion.div>
      </div>

      {/* Current Temperature */}
      <div className="text-center mb-4">
        <motion.div
          className="text-5xl font-bold text-atlas-accent glow-text"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          {weather.currentTemp}
        </motion.div>
        <p className="text-atlas-primary text-sm mt-1">{weather.condition}</p>
      </div>

      {/* Weather Details Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="flex items-center gap-2">
          <Droplets className="w-4 h-4 text-atlas-primary" />
          <div>
            <p className="text-xs text-atlas-accent">Humidity</p>
            <p className="text-sm text-white font-semibold">{weather.humidity}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Wind className="w-4 h-4 text-atlas-primary" />
          <div>
            <p className="text-xs text-atlas-accent">Wind</p>
            <p className="text-sm text-white font-semibold">{weather.wind}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-atlas-primary" />
          <div>
            <p className="text-xs text-atlas-accent">Visibility</p>
            <p className="text-sm text-white font-semibold">{weather.visibility}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Gauge className="w-4 h-4 text-atlas-primary" />
          <div>
            <p className="text-xs text-atlas-accent">Pressure</p>
            <p className="text-sm text-white font-semibold">{weather.pressure}</p>
          </div>
        </div>
      </div>

      {/* Additional Info */}
      <div className="space-y-1 text-xs mb-4">
        <div className="flex justify-between">
          <span className="text-atlas-accent">Feels Like:</span>
          <span className="text-white">{weather.feelsLike}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-atlas-accent">Sunrise:</span>
          <span className="text-white">{weather.sunrise}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-atlas-accent">Sunset:</span>
          <span className="text-white">{weather.sunset}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-atlas-accent">Moon Phase:</span>
          <span className="text-white">{weather.moonPhase}</span>
        </div>
      </div>

      {/* Forecast */}
      <div className="border-t border-atlas-primary/30 pt-3 space-y-2">
        <h4 className="text-atlas-primary text-xs font-semibold mb-2">FORECAST</h4>
        {weather.forecast.map((item, index) => (
          <motion.div
            key={item.day}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 + index * 0.1 }}
            className="flex justify-between items-center text-xs"
          >
            <div>
              <span className="text-atlas-accent">{item.day}</span>
              <span className="text-white ml-2">{item.condition}</span>
            </div>
            <div className="text-atlas-primary">
              <span>{item.high}</span>
              <span className="text-white">/{item.low}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

