'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Monitor, Smartphone, Tablet, Laptop, Cpu, HardDrive, Wifi, Battery } from 'lucide-react';

interface DeviceInfo {
  type: 'desktop' | 'mobile' | 'tablet';
  os: string;
  browser: string;
  screen: {
    width: number;
    height: number;
    orientation: 'landscape' | 'portrait';
  };
  connection: string;
  battery?: {
    level: number;
    charging: boolean;
  };
  memory?: {
    deviceMemory: number;
  };
  cpu?: {
    hardwareConcurrency: number;
  };
}

export default function DeviceDetector() {
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);

  useEffect(() => {
    const detectDevice = () => {
      const userAgent = navigator.userAgent.toLowerCase();
      const isMobile = /mobile|android|iphone|ipod|blackberry|iemobile|opera mini/i.test(userAgent);
      const isTablet = /tablet|ipad|playbook|silk/i.test(userAgent);
      
      let os = 'Unknown';
      if (userAgent.includes('win')) os = 'Windows';
      else if (userAgent.includes('mac')) os = 'macOS';
      else if (userAgent.includes('linux')) os = 'Linux';
      else if (userAgent.includes('android')) os = 'Android';
      else if (userAgent.includes('ios') || userAgent.includes('iphone') || userAgent.includes('ipad')) os = 'iOS';

      let browser = 'Unknown';
      if (userAgent.includes('chrome') && !userAgent.includes('edg')) browser = 'Chrome';
      else if (userAgent.includes('firefox')) browser = 'Firefox';
      else if (userAgent.includes('safari') && !userAgent.includes('chrome')) browser = 'Safari';
      else if (userAgent.includes('edg')) browser = 'Edge';
      else if (userAgent.includes('opera')) browser = 'Opera';

      const info: DeviceInfo = {
        type: isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop',
        os,
        browser,
        screen: {
          width: window.screen.width,
          height: window.screen.height,
          orientation: window.screen.width > window.screen.height ? 'landscape' : 'portrait',
        },
        connection: (navigator as any).connection
          ? `${(navigator as any).connection.effectiveType || 'Unknown'} (${(navigator as any).connection.downlink || 'N/A'} Mbps)`
          : 'Unknown',
        cpu: {
          hardwareConcurrency: navigator.hardwareConcurrency || 0,
        },
        memory: (navigator as any).deviceMemory
          ? { deviceMemory: (navigator as any).deviceMemory }
          : undefined,
      };

      // Battery API
      if ('getBattery' in navigator) {
        (navigator as any).getBattery().then((battery: any) => {
          setDeviceInfo({
            ...info,
            battery: {
              level: Math.round(battery.level * 100),
              charging: battery.charging,
            },
          });
        });
      } else {
        setDeviceInfo(info);
      }
    };

    detectDevice();

    // Update on orientation change
    window.addEventListener('orientationchange', detectDevice);
    window.addEventListener('resize', detectDevice);

    return () => {
      window.removeEventListener('orientationchange', detectDevice);
      window.removeEventListener('resize', detectDevice);
    };
  }, []);

  const getDeviceIcon = () => {
    if (!deviceInfo) return <Monitor className="w-6 h-6" />;
    switch (deviceInfo.type) {
      case 'mobile':
        return <Smartphone className="w-6 h-6" />;
      case 'tablet':
        return <Tablet className="w-6 h-6" />;
      default:
        return <Laptop className="w-6 h-6" />;
    }
  };

  if (!deviceInfo) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="hologram-effect rounded-lg p-4"
      >
        <div className="flex items-center justify-center h-32">
          <div className="animate-spin text-atlas-primary">Loading device info...</div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center gap-2 mb-4">
        {getDeviceIcon()}
        <h3 className="text-atlas-primary text-lg font-bold glow-text">Device Info</h3>
      </div>

      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-atlas-accent text-xs">Device Type</span>
          <span className="text-white text-sm font-semibold capitalize">{deviceInfo.type}</span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-atlas-accent text-xs">Operating System</span>
          <span className="text-white text-sm font-semibold">{deviceInfo.os}</span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-atlas-accent text-xs">Browser</span>
          <span className="text-white text-sm font-semibold">{deviceInfo.browser}</span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-atlas-accent text-xs">Screen Resolution</span>
          <span className="text-white text-sm font-semibold">
            {deviceInfo.screen.width} × {deviceInfo.screen.height}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-atlas-accent text-xs">Orientation</span>
          <span className="text-white text-sm font-semibold capitalize">{deviceInfo.screen.orientation}</span>
        </div>

        {deviceInfo.cpu && (
          <div className="flex justify-between items-center">
            <span className="text-atlas-accent text-xs flex items-center gap-1">
              <Cpu className="w-3 h-3" /> CPU Cores
            </span>
            <span className="text-white text-sm font-semibold">{deviceInfo.cpu.hardwareConcurrency}</span>
          </div>
        )}

        {deviceInfo.memory && (
          <div className="flex justify-between items-center">
            <span className="text-atlas-accent text-xs flex items-center gap-1">
              <HardDrive className="w-3 h-3" /> RAM
            </span>
            <span className="text-white text-sm font-semibold">{deviceInfo.memory.deviceMemory} GB</span>
          </div>
        )}

        <div className="flex justify-between items-center">
          <span className="text-atlas-accent text-xs flex items-center gap-1">
            <Wifi className="w-3 h-3" /> Connection
          </span>
          <span className="text-white text-sm font-semibold">{deviceInfo.connection}</span>
        </div>

        {deviceInfo.battery && (
          <div className="flex justify-between items-center">
            <span className="text-atlas-accent text-xs flex items-center gap-1">
              <Battery className={`w-3 h-3 ${deviceInfo.battery.charging ? 'text-green-400' : ''}`} /> Battery
            </span>
            <span className="text-white text-sm font-semibold">
              {deviceInfo.battery.level}% {deviceInfo.battery.charging && '(Charging)'}
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}

