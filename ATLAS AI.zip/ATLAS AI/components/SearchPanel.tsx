'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Sparkles, Code, FileText, Globe, Zap } from 'lucide-react';

interface SearchResult {
  id: string;
  type: 'code' | 'document' | 'web' | 'command';
  title: string;
  description: string;
  icon: any;
}

export default function SearchPanel() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    
    // Simulate AI-powered search
    setTimeout(() => {
      const mockResults: SearchResult[] = [
        {
          id: '1',
          type: 'code',
          title: 'Code Generation',
          description: `Generate code for: ${searchQuery}`,
          icon: Code,
        },
        {
          id: '2',
          type: 'document',
          title: 'Documentation',
          description: `Search documentation for: ${searchQuery}`,
          icon: FileText,
        },
        {
          id: '3',
          type: 'web',
          title: 'Web Search',
          description: `Search the web for: ${searchQuery}`,
          icon: Globe,
        },
        {
          id: '4',
          type: 'command',
          title: 'Command',
          description: `Execute command: ${searchQuery}`,
          icon: Zap,
        },
      ];

      setResults(mockResults);
      setIsSearching(false);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch(query);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-5 h-5 text-atlas-primary" />
        <h3 className="text-atlas-primary text-lg font-bold glow-text">AI Search</h3>
      </div>

      {/* Search Input */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-atlas-accent" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Search anything..."
          className="w-full bg-atlas-darker border border-atlas-primary/30 rounded-lg pl-10 pr-4 py-2 text-white placeholder-atlas-accent/50 focus:outline-none focus:border-atlas-primary transition-colors"
        />
        {isSearching && (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="absolute right-3 top-1/2 transform -translate-y-1/2"
          >
            <Search className="w-4 h-4 text-atlas-primary" />
          </motion.div>
        )}
      </div>

      {/* Search Results */}
      <AnimatePresence>
        {results.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-2 max-h-[300px] overflow-y-auto"
          >
            {results.map((result, index) => {
              const Icon = result.icon;
              return (
                <motion.div
                  key={result.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-3 rounded-lg bg-atlas-darker border border-atlas-primary/30 hover:border-atlas-primary cursor-pointer transition-all group"
                  whileHover={{ scale: 1.02, x: 4 }}
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-atlas-primary to-atlas-accent group-hover:scale-110 transition-transform">
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white text-sm font-semibold mb-1">{result.title}</h4>
                      <p className="text-atlas-accent text-xs">{result.description}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {query && results.length === 0 && !isSearching && (
        <p className="text-atlas-accent text-xs text-center py-4">
          Press Enter to search
        </p>
      )}
    </motion.div>
  );
}

