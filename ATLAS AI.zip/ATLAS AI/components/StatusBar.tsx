'use client';

import { motion } from 'framer-motion';
import { Cpu, HardDrive, Activity, Wifi } from 'lucide-react';
import { useFormattedTime } from '@/hooks/useRealTime';
import { useSystemStats } from '@/hooks/useSystemStats';

interface StatusBarProps {
  userName: string;
  systemStatus: string;
}

export default function StatusBar({ userName, systemStatus }: StatusBarProps) {
  const { time, date } = useFormattedTime();
  const systemStats = useSystemStats();

  const systemMetrics = [
    { icon: Cpu, label: 'CPU', value: `${systemStats.cpu.temperature.toFixed(1)}°C`, usage: Math.round(systemStats.cpu.usage) },
    { icon: HardDrive, label: 'GPU', value: `${systemStats.gpu.temperature.toFixed(1)}°C`, usage: Math.round(systemStats.gpu.usage) },
    { icon: Activity, label: 'RAM', value: `${systemStats.memory.used.toFixed(1)}GB`, usage: Math.round(systemStats.memory.usage) },
    { icon: Wifi, label: 'HDD', value: `${systemStats.disk.used.toFixed(1)}GB`, usage: Math.round(systemStats.disk.usage) },
  ];

  return (
    <div className="hologram-effect rounded-lg p-4 mb-4">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        {/* Left: System Info */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-atlas-primary to-atlas-accent p-0.5">
              <div className="w-full h-full rounded-full bg-atlas-dark" />
            </div>
            <motion.div
              className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-atlas-dark"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
          <div>
            <h2 className="text-atlas-primary text-xl font-bold glow-text">
              ATLAS AI OS v1.2.5
            </h2>
            <p className="text-atlas-accent text-sm">User: {userName}</p>
            <p className="text-atlas-primary text-xs mt-1">{systemStatus}</p>
          </div>
        </div>

        {/* Center: System Metrics */}
        <div className="flex gap-4">
          {systemMetrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="hologram-effect rounded-lg p-3 min-w-[80px]"
              >
                <Icon className="w-5 h-5 text-atlas-primary mb-1" />
                <p className="text-xs text-atlas-accent mb-1">{metric.label}</p>
                <p className="text-xs text-white mb-2">{metric.value}</p>
                <div className="w-full h-1.5 bg-atlas-dark rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-atlas-primary to-atlas-accent"
                    animate={{ width: `${metric.usage}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Right: Time - Auto-updating */}
        <div className="text-right">
          <motion.div
            className="text-atlas-primary text-2xl font-mono font-bold glow-text"
            key={time}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            {time}
          </motion.div>
          <motion.p
            key={date}
            className="text-atlas-accent text-xs mt-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {date}
          </motion.p>
        </div>
      </div>
    </div>
  );
}

