'use client';

import { motion } from 'framer-motion';
import { Zap, Search, FileText, Image, Code, Music, Video, Calendar, Settings, Moon, Sun } from 'lucide-react';

interface QuickAction {
  id: string;
  label: string;
  icon: any;
  action: () => void;
  color: string;
}

export default function QuickActions() {
  const actions: QuickAction[] = [
    {
      id: 'search',
      label: 'Search',
      icon: Search,
      action: () => alert('Search feature coming soon!'),
      color: 'from-blue-500 to-cyan-500',
    },
    {
      id: 'code',
      label: 'Code',
      icon: Code,
      action: () => alert('Code generation feature coming soon!'),
      color: 'from-purple-500 to-pink-500',
    },
    {
      id: 'image',
      label: 'Image',
      icon: Image,
      action: () => alert('Image generation feature coming soon!'),
      color: 'from-orange-500 to-red-500',
    },
    {
      id: 'music',
      label: 'Music',
      icon: Music,
      action: () => alert('Music feature coming soon!'),
      color: 'from-green-500 to-emerald-500',
    },
    {
      id: 'video',
      label: 'Video',
      icon: Video,
      action: () => alert('Video feature coming soon!'),
      color: 'from-pink-500 to-rose-500',
    },
    {
      id: 'document',
      label: 'Document',
      icon: FileText,
      action: () => alert('Document feature coming soon!'),
      color: 'from-indigo-500 to-blue-500',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center gap-2 mb-4">
        <Zap className="w-5 h-5 text-atlas-primary" />
        <h3 className="text-atlas-primary text-lg font-bold glow-text">Quick Actions</h3>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <motion.button
              key={action.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={action.action}
              className="flex flex-col items-center gap-2 p-4 rounded-lg bg-atlas-darker border border-atlas-primary/30 hover:border-atlas-primary transition-all group"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${action.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <span className="text-xs text-atlas-accent group-hover:text-atlas-primary transition-colors">
                {action.label}
              </span>
            </motion.button>
          );
        })}
      </div>

      {/* Quick Tips */}
      <div className="mt-4 pt-4 border-t border-atlas-primary/30">
        <p className="text-atlas-accent text-xs text-center">
          Click any action to get started
        </p>
      </div>
    </motion.div>
  );
}

