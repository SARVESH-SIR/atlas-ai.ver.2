'use client';

import { motion } from 'framer-motion';
import { Brain, Zap, Cpu, Sparkles, FlaskConical, Heart, Languages, Code, Search } from 'lucide-react';
import { useState, useEffect } from 'react';
import { masterBrain } from '@/lib/atlas-core/knowledge-brains/master-brain';

interface BrainStatus {
  name: string;
  icon: any;
  status: 'active' | 'idle' | 'processing';
  capabilities: string[];
  color: string;
}

export default function KnowledgeBrainsStatus() {
  const [brains, setBrains] = useState<BrainStatus[]>([]);
  const [activeCount, setActiveCount] = useState(0);

  useEffect(() => {
    const availableBrains = masterBrain.getAvailableBrains();
    
    const brainIcons: Record<string, any> = {
      knowledge: Brain,
      reasoning: Zap,
      research: Search,
      coding: Code,
      creative: Sparkles,
      science: FlaskConical,
      medical: Heart,
      language: Languages,
    };

    const brainColors: Record<string, string> = {
      knowledge: 'from-blue-500 to-cyan-500',
      reasoning: 'from-purple-500 to-pink-500',
      research: 'from-green-500 to-emerald-500',
      coding: 'from-orange-500 to-red-500',
      creative: 'from-pink-500 to-rose-500',
      science: 'from-indigo-500 to-blue-500',
      medical: 'from-red-500 to-pink-500',
      language: 'from-yellow-500 to-orange-500',
    };

    const brainData: BrainStatus[] = availableBrains.map((name) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      icon: brainIcons[name] || Brain,
      status: Math.random() > 0.5 ? 'active' : 'idle',
      capabilities: masterBrain.getBrainCapabilities(name),
      color: brainColors[name] || 'from-blue-500 to-cyan-500',
    }));

    setBrains(brainData);
    setActiveCount(brainData.filter(b => b.status === 'active').length);

    // Simulate status changes
    const interval = setInterval(() => {
      setBrains(prev => prev.map(brain => ({
        ...brain,
        status: Math.random() > 0.7 ? 'processing' : Math.random() > 0.5 ? 'active' : 'idle',
      })));
      setActiveCount(brains.filter(b => Math.random() > 0.5).length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-atlas-primary" />
          <h3 className="text-atlas-primary text-lg font-bold glow-text">Knowledge Brains</h3>
        </div>
        <div className="text-atlas-accent text-sm">
          {activeCount}/{brains.length} Active
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {brains.map((brain, index) => {
          const Icon = brain.icon;
          const statusColor = {
            active: 'bg-green-500',
            processing: 'bg-yellow-500',
            idle: 'bg-gray-500',
          }[brain.status];

          return (
            <motion.div
              key={brain.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-3 rounded-lg bg-atlas-darker border border-atlas-primary/30 hover:border-atlas-primary transition-all group"
              whileHover={{ scale: 1.05 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${brain.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-white text-sm font-semibold truncate">{brain.name}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <div className={`w-2 h-2 rounded-full ${statusColor} ${brain.status === 'processing' ? 'animate-pulse' : ''}`} />
                    <span className="text-atlas-accent text-xs capitalize">{brain.status}</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-2">
                <p className="text-atlas-accent text-xs">
                  {brain.capabilities[0]} • {brain.capabilities[1]}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-4 pt-4 border-t border-atlas-primary/30">
        <p className="text-atlas-accent text-xs text-center">
          {brains.length} specialized knowledge brains working together
        </p>
      </div>
    </motion.div>
  );
}

