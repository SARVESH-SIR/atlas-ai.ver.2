'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Home,
  Lightbulb,
  Thermometer,
  Lock,
  Camera,
  Speaker,
  Tv,
  Power,
  PowerOff,
  Settings,
  Zap,
} from 'lucide-react';
import {
  smartHomeController,
  type SmartDevice,
  type SmartScene,
} from '@/lib/atlas-core/jarvis/smart-home';

export default function SmartHomeControl() {
  const [devices, setDevices] = useState<SmartDevice[]>([]);
  const [scenes, setScenes] = useState<SmartScene[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<string>('all');
  const [expanded, setExpanded] = useState(false);
  const [statusSummary, setStatusSummary] = useState({
    totalDevices: 0,
    activeDevices: 0,
    rooms: 0,
    scenes: 0,
    currentScene: null as string | null,
  });

  useEffect(() => {
    const loadData = () => {
      const allDevices = smartHomeController.getAllDevices();
      const allScenes = smartHomeController.getAllScenes();
      const summary = smartHomeController.getStatusSummary();

      setDevices(allDevices);
      setScenes(allScenes);
      setStatusSummary(summary);
    };

    loadData();
    const interval = setInterval(loadData, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, []);

  const handleDeviceControl = async (
    deviceId: string,
    action: string,
    parameters?: Record<string, any>
  ) => {
    const result = await smartHomeController.controlDevice(deviceId, action, parameters);
    
    if (result.success) {
      // Reload devices
      const allDevices = smartHomeController.getAllDevices();
      setDevices(allDevices);
    }
  };

  const handleSceneActivate = async (sceneId: string) => {
    const result = await smartHomeController.activateScene(sceneId);
    
    if (result.success) {
      // Reload data
      const allDevices = smartHomeController.getAllDevices();
      const allScenes = smartHomeController.getAllScenes();
      const summary = smartHomeController.getStatusSummary();
      
      setDevices(allDevices);
      setScenes(allScenes);
      setStatusSummary(summary);
    }
  };

  const getDeviceIcon = (type: SmartDevice['type']) => {
    switch (type) {
      case 'light':
        return <Lightbulb className="w-5 h-5" />;
      case 'thermostat':
        return <Thermometer className="w-5 h-5" />;
      case 'lock':
        return <Lock className="w-5 h-5" />;
      case 'camera':
        return <Camera className="w-5 h-5" />;
      case 'speaker':
        return <Speaker className="w-5 h-5" />;
      case 'tv':
        return <Tv className="w-5 h-5" />;
      default:
        return <Power className="w-5 h-5" />;
    }
  };

  const filteredDevices = selectedRoom === 'all'
    ? devices
    : devices.filter(d => d.room === selectedRoom);

  const rooms = smartHomeController.getAllRooms();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Home className="w-5 h-5 text-atlas-primary" />
          <h3 className="text-atlas-primary text-lg font-bold glow-text">
            Smart Home
          </h3>
          <span className="px-2 py-0.5 bg-atlas-primary/20 rounded-full text-atlas-accent text-xs">
            {statusSummary.activeDevices}/{statusSummary.totalDevices}
          </span>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-atlas-accent hover:text-atlas-primary transition-colors"
        >
          {expanded ? '−' : '+'}
        </button>
      </div>

      {/* Quick Scenes */}
      {scenes.length > 0 && (
        <div className="mb-3 flex gap-2 overflow-x-auto pb-2">
          {scenes.map((scene) => (
            <button
              key={scene.id}
              onClick={() => handleSceneActivate(scene.id)}
              className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all ${
                statusSummary.currentScene === scene.id
                  ? 'bg-gradient-to-r from-atlas-primary to-atlas-accent text-white font-semibold'
                  : 'bg-atlas-darker border border-atlas-primary/30 text-atlas-accent hover:border-atlas-primary'
              }`}
            >
              <Zap className="w-3 h-3 inline mr-1" />
              {scene.name}
            </button>
          ))}
        </div>
      )}

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="space-y-3"
          >
            {/* Room Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              <button
                onClick={() => setSelectedRoom('all')}
                className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all ${
                  selectedRoom === 'all'
                    ? 'bg-gradient-to-r from-atlas-primary to-atlas-accent text-white font-semibold'
                    : 'bg-atlas-darker border border-atlas-primary/30 text-atlas-accent hover:border-atlas-primary'
                }`}
              >
                All Rooms
              </button>
              {rooms.map((room) => (
                <button
                  key={room.id}
                  onClick={() => setSelectedRoom(room.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all ${
                    selectedRoom === room.id
                      ? 'bg-gradient-to-r from-atlas-primary to-atlas-accent text-white font-semibold'
                      : 'bg-atlas-darker border border-atlas-primary/30 text-atlas-accent hover:border-atlas-primary'
                  }`}
                >
                  {room.name}
                </button>
              ))}
            </div>

            {/* Devices */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {filteredDevices.map((device) => (
                <motion.div
                  key={device.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-lg border ${
                    device.status === 'on' || device.status === 'active'
                      ? 'bg-atlas-darker/50 border-atlas-primary/50'
                      : 'bg-atlas-darker/30 border-atlas-primary/20'
                  } hover:border-atlas-primary transition-all`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 flex-1">
                      <div
                        className={`p-2 rounded-lg ${
                          device.status === 'on' || device.status === 'active'
                            ? 'bg-gradient-to-r from-atlas-primary to-atlas-accent text-white'
                            : 'bg-atlas-primary/20 text-atlas-primary'
                        }`}
                      >
                        {getDeviceIcon(device.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white text-sm font-semibold truncate">
                          {device.name}
                        </h4>
                        <p className="text-atlas-accent text-xs">
                          {device.room} • {device.status}
                          {device.type === 'light' && device.state?.brightness && (
                            <span> • {device.state.brightness}%</span>
                          )}
                          {device.type === 'thermostat' && device.state?.temperature && (
                            <span> • {device.state.temperature}°C</span>
                          )}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      {device.controllable && (
                        <>
                          {device.status === 'off' || device.status === 'inactive' ? (
                            <button
                              onClick={() => handleDeviceControl(device.id, 'turn_on')}
                              className="p-2 bg-gradient-to-r from-atlas-primary to-atlas-accent rounded-lg text-white hover:scale-105 transition-transform"
                              title="Turn On"
                            >
                              <Power className="w-4 h-4" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleDeviceControl(device.id, 'turn_off')}
                              className="p-2 bg-atlas-primary/20 border border-atlas-primary rounded-lg text-atlas-primary hover:bg-atlas-primary/30 transition-colors"
                              title="Turn Off"
                            >
                              <PowerOff className="w-4 h-4" />
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

