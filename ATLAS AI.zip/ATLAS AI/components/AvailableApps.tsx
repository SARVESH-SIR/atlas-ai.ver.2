'use client';

import { motion } from 'framer-motion';
import { ExternalLink, Play, Search, MessageCircle, Music, Code, Mail } from 'lucide-react';
import { useState } from 'react';
import { appController } from '@/lib/atlas-core/actions/app-controller';
import { actionExecutor } from '@/lib/atlas-core/actions/action-executor';

export default function AvailableApps() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const apps = appController.getAvailableApps();

  const categories = [
    { id: 'all', name: 'All Apps' },
    { id: 'web', name: 'Web' },
    { id: 'communication', name: 'Communication' },
    { id: 'development', name: 'Development' },
    { id: 'media', name: 'Media' },
  ];

  const getAppIcon = (appName: string) => {
    const iconMap: Record<string, any> = {
      'Google': Search,
      'YouTube': Play,
      'WhatsApp': MessageCircle,
      'Telegram': MessageCircle,
      'Gmail': Mail,
      'Spotify': Music,
      'GitHub': Code,
      'VS Code': Code,
    };

    return iconMap[appName] || ExternalLink;
  };

  const categorizeApp = (app: typeof apps[0]): string => {
    if (app.name === 'VS Code' || app.name === 'GitHub') return 'development';
    if (app.name === 'WhatsApp' || app.name === 'Telegram' || app.name === 'Discord' || app.name === 'Gmail') return 'communication';
    if (app.name === 'YouTube' || app.name === 'Spotify') return 'media';
    return 'web';
  };

  const filteredApps = selectedCategory === 'all'
    ? apps
    : apps.filter(app => categorizeApp(app) === selectedCategory);

  const executeApp = async (appName: string) => {
    const command = `open ${appName}`;
    await actionExecutor.executeCommand(command);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-atlas-primary text-lg font-bold glow-text flex items-center gap-2">
          <ExternalLink className="w-5 h-5" />
          Available Apps
        </h3>
        <span className="text-atlas-accent text-xs">{apps.length} apps</span>
      </div>

      {/* Categories */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-3 py-1 rounded-lg text-xs whitespace-nowrap transition-all ${
              selectedCategory === category.id
                ? 'bg-atlas-primary text-atlas-dark font-semibold'
                : 'bg-atlas-darker text-atlas-accent hover:bg-atlas-primary/20'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* Apps Grid */}
      <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
        {filteredApps.map((app, index) => {
          const Icon = getAppIcon(app.name);
          return (
            <motion.button
              key={app.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => executeApp(app.name)}
              className="p-3 rounded-lg bg-atlas-darker border border-atlas-primary/30 hover:border-atlas-primary transition-all group text-left"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-atlas-primary to-atlas-accent flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-semibold truncate">{app.name}</p>
                </div>
              </div>
              <p className="text-atlas-accent text-xs line-clamp-2">
                {app.actions.slice(0, 2).join(', ')}
              </p>
            </motion.button>
          );
        })}
      </div>

      {/* Instructions */}
      <div className="mt-4 pt-4 border-t border-atlas-primary/30">
        <p className="text-atlas-accent text-xs text-center">
          Click any app to open it • Use voice: "Hey ATLAS, open [App Name]"
        </p>
      </div>
    </motion.div>
  );
}

