'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Play, Pause, Settings, Clock, CheckCircle2, XCircle, Plus } from 'lucide-react';
import { smartAutomation, type AutomationRule } from '@/lib/atlas-core/jarvis/smart-automation';

export default function SmartAutomationPanel() {
  const [rules, setRules] = useState<AutomationRule[]>([]);
  const [expanded, setExpanded] = useState(false);
  const [selectedRule, setSelectedRule] = useState<string | null>(null);

  useEffect(() => {
    const loadRules = () => {
      const allRules = smartAutomation.getAllRules();
      setRules(allRules);
    };

    loadRules();
    const interval = setInterval(loadRules, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const handleToggle = (id: string) => {
    smartAutomation.toggleRule(id);
    setRules(prev => prev.map(rule =>
      rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
    ));
  };

  const getTriggerDescription = (rule: AutomationRule): string => {
    if (rule.trigger.type === 'time' && rule.trigger.schedule) {
      const days = rule.trigger.schedule.days;
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const dayList = days ? days.map(d => dayNames[d]).join(', ') : 'Daily';
      return `${rule.trigger.schedule.time} • ${dayList}`;
    }
    return rule.trigger.condition;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-atlas-primary" />
          <h3 className="text-atlas-primary text-lg font-bold glow-text">
            Smart Automation
          </h3>
          <span className="px-2 py-0.5 bg-atlas-primary/20 rounded-full text-atlas-accent text-xs">
            {rules.filter(r => r.enabled).length}/{rules.length}
          </span>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setExpanded(!expanded)}
            className="text-atlas-accent hover:text-atlas-primary transition-colors p-1"
            title={expanded ? 'Collapse' : 'Expand'}
          >
            {expanded ? '−' : '+'}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="space-y-2"
          >
            {rules.length === 0 ? (
              <div className="text-center py-8">
                <Zap className="w-8 h-8 mx-auto mb-2 text-atlas-primary/50" />
                <p className="text-atlas-accent text-sm">No automation rules yet</p>
                <button className="mt-3 px-4 py-2 bg-gradient-to-r from-atlas-primary to-atlas-accent rounded-lg text-white text-sm hover:scale-105 transition-transform flex items-center gap-2 mx-auto">
                  <Plus className="w-4 h-4" />
                  Create Rule
                </button>
              </div>
            ) : (
              rules.map((rule) => (
                <motion.div
                  key={rule.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-lg border ${
                    rule.enabled
                      ? 'bg-atlas-darker/50 border-atlas-primary/30'
                      : 'bg-atlas-darker/30 border-atlas-primary/10 opacity-60'
                  } hover:border-atlas-primary transition-all`}
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          rule.enabled
                            ? 'bg-gradient-to-r from-atlas-primary to-atlas-accent'
                            : 'bg-atlas-primary/20'
                        }`}
                      >
                        {rule.enabled ? (
                          <Play className="w-5 h-5 text-white" />
                        ) : (
                          <Pause className="w-5 h-5 text-atlas-primary" />
                        )}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <h4 className="text-white text-sm font-semibold mb-1">
                            {rule.name}
                          </h4>
                          <p className="text-atlas-accent text-xs mb-2 line-clamp-2">
                            {rule.description}
                          </p>
                          <div className="flex items-center gap-3 text-xs">
                            <div className="flex items-center gap-1 text-atlas-accent">
                              <Clock className="w-3 h-3" />
                              <span>{getTriggerDescription(rule)}</span>
                            </div>
                            {rule.lastExecuted && (
                              <div className="flex items-center gap-1 text-atlas-accent">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>
                                  {rule.executionCount}x • {new Date(rule.lastExecuted).toLocaleTimeString()}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => handleToggle(rule.id)}
                          className={`p-2 rounded-lg transition-all ${
                            rule.enabled
                              ? 'bg-atlas-primary/20 text-atlas-primary hover:bg-atlas-primary/30'
                              : 'bg-atlas-primary/10 text-atlas-accent hover:bg-atlas-primary/20'
                          }`}
                          title={rule.enabled ? 'Disable' : 'Enable'}
                        >
                          {rule.enabled ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

