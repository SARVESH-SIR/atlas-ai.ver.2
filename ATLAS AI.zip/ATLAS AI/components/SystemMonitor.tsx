'use client';

import { motion } from 'framer-motion';
import { TrendingUp, Database, HardDrive, Network } from 'lucide-react';
import { useSystemStats } from '@/hooks/useSystemStats';
import { useState, useEffect } from 'react';

export default function SystemMonitor() {
  const systemStats = useSystemStats();
  const [cpuHistory, setCpuHistory] = useState<number[]>([]);
  const [memoryHistory, setMemoryHistory] = useState<number[]>([]);

  // Maintain history for charts
  useEffect(() => {
    setCpuHistory((prev) => {
      const newHistory = [...prev, systemStats.cpu.usage];
      return newHistory.slice(-7); // Keep last 7 values
    });
  }, [systemStats.cpu.usage]);

  useEffect(() => {
    setMemoryHistory((prev) => {
      const newHistory = [...prev, systemStats.memory.usage];
      return newHistory.slice(-7); // Keep last 7 values
    });
  }, [systemStats.memory.usage]);

  const stats = [
    {
      title: 'CPU USAGE',
      value: `${Math.round(systemStats.cpu.usage)}%`,
      icon: TrendingUp,
      data: cpuHistory.length > 0 ? cpuHistory : [systemStats.cpu.usage],
      color: 'from-atlas-primary to-atlas-accent',
    },
    {
      title: 'MEMORY',
      value: `${Math.round(systemStats.memory.usage)}%`,
      icon: Database,
      data: memoryHistory.length > 0 ? memoryHistory : [systemStats.memory.usage],
      color: 'from-atlas-secondary to-atlas-primary',
    },
    {
      title: 'DISK SPACE',
      value: `${systemStats.disk.used.toFixed(1)} GB`,
      subtitle: `of ${systemStats.disk.total.toFixed(1)} GB`,
      icon: HardDrive,
      total: systemStats.disk.total,
      used: systemStats.disk.used,
      color: 'from-atlas-accent to-atlas-secondary',
    },
  ];

  return (
    <div className="space-y-4">
      {/* CPU Usage Card */}
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3 }}
        className="hologram-effect rounded-lg p-4"
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-atlas-primary text-sm font-semibold glow-text">
            CPU USAGE
          </h3>
          <TrendingUp className="w-4 h-4 text-atlas-accent" />
        </div>
        <div className="flex items-end gap-1 h-16 mb-2">
          {stats[0].data.length > 0 ? (
            stats[0].data.map((value, index) => (
              <motion.div
                key={`cpu-${index}-${value}`}
                className="flex-1 bg-gradient-to-t from-atlas-primary to-atlas-accent rounded-t"
                animate={{ height: `${Math.max(5, (value / 100) * 100)}%` }}
                transition={{ duration: 0.5 }}
              />
            ))
          ) : (
            <div className="flex-1 bg-gradient-to-t from-atlas-primary to-atlas-accent rounded-t h-full" />
          )}
        </div>
        <p className="text-atlas-accent text-lg font-bold">{stats[0].value}</p>
      </motion.div>

      {/* Memory Usage Card */}
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5 }}
        className="hologram-effect rounded-lg p-4"
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-atlas-primary text-sm font-semibold glow-text">
            MEMORY USAGE
          </h3>
          <Database className="w-4 h-4 text-atlas-accent" />
        </div>
        <div className="flex items-end gap-1 h-16 mb-2">
          {stats[1].data.length > 0 ? (
            stats[1].data.map((value, index) => (
              <motion.div
                key={`mem-${index}-${value}`}
                className="flex-1 bg-gradient-to-t from-atlas-secondary to-atlas-primary rounded-t"
                animate={{ height: `${Math.max(5, (value / 100) * 100)}%` }}
                transition={{ duration: 0.5 }}
              />
            ))
          ) : (
            <div className="flex-1 bg-gradient-to-t from-atlas-secondary to-atlas-primary rounded-t h-full" />
          )}
        </div>
        <p className="text-atlas-accent text-lg font-bold">{stats[1].value}</p>
      </motion.div>

      {/* Disk Space Card */}
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.7 }}
        className="hologram-effect rounded-lg p-4"
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-atlas-primary text-sm font-semibold glow-text">
            DISK SPACE
          </h3>
          <HardDrive className="w-4 h-4 text-atlas-accent" />
        </div>
        <div className="space-y-2 mb-2">
          <div className="flex justify-between text-xs">
            <span className="text-atlas-accent">TOTAL</span>
            <span className="text-white">{stats[2].total} GB</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-atlas-accent">USED</span>
            <span className="text-white">{stats[2].used} GB</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-atlas-accent">FREE</span>
            <span className="text-white">{stats[2].total - stats[2].used} GB</span>
          </div>
        </div>
        <div className="w-full h-3 bg-atlas-dark rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-atlas-accent to-atlas-secondary"
            animate={{ width: `${(stats[2].used / stats[2].total) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </motion.div>

      {/* Network Traffic */}
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.9 }}
        className="hologram-effect rounded-lg p-4"
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-atlas-primary text-sm font-semibold glow-text">
            NETWORK TRAFFIC
          </h3>
          <Network className="w-4 h-4 text-atlas-accent" />
        </div>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span>UP</span>
              <span className="text-atlas-accent">{systemStats.network.uploadSpeed.toFixed(1)} KB/s</span>
            </div>
            <div className="w-full h-2 bg-atlas-dark rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-atlas-primary to-atlas-accent"
                animate={{ width: `${systemStats.network.upload}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span>DOWN</span>
              <span className="text-atlas-accent">{systemStats.network.downloadSpeed.toFixed(1)} KB/s</span>
            </div>
            <div className="w-full h-2 bg-atlas-dark rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-atlas-secondary to-atlas-primary"
                animate={{ width: `${systemStats.network.download}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

