'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Circle, Plus, Trash2, Clock, Calendar } from 'lucide-react';
import { useFormattedTime } from '@/hooks/useRealTime';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  dueDate?: Date;
  createdAt: Date;
}

export default function TaskManager() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTask, setNewTask] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const { date } = useFormattedTime();

  const addTask = () => {
    if (!newTask.trim()) return;

    const task: Task = {
      id: Date.now().toString(),
      title: newTask.trim(),
      completed: false,
      priority,
      createdAt: new Date(),
    };

    setTasks([...tasks, task]);
    setNewTask('');
    setPriority('medium');
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const completedCount = tasks.filter(t => t.completed).length;
  const pendingTasks = tasks.filter(t => !t.completed);
  const completedTasks = tasks.filter(t => t.completed);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-red-500';
      case 'medium': return 'border-yellow-500';
      case 'low': return 'border-green-500';
      default: return 'border-atlas-primary';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-atlas-primary text-lg font-bold glow-text flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Task Manager
          </h3>
          <p className="text-atlas-accent text-xs mt-1">
            {pendingTasks.length} pending • {completedCount} completed
          </p>
        </div>
      </div>

      {/* Add Task */}
      <div className="mb-4 space-y-2">
        <div className="flex gap-2">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTask()}
            placeholder="Add a new task..."
            className="flex-1 bg-atlas-darker border border-atlas-primary/30 rounded-lg px-3 py-2 text-white text-sm placeholder-atlas-accent/50 focus:outline-none focus:border-atlas-primary transition-colors"
          />
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high')}
            className="bg-atlas-darker border border-atlas-primary/30 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-atlas-primary"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <motion.button
            onClick={addTask}
            className="px-3 py-2 bg-gradient-to-r from-atlas-primary to-atlas-accent rounded-lg text-white hover:scale-105 transition-transform"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Plus className="w-4 h-4" />
          </motion.button>
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-2 max-h-[400px] overflow-y-auto">
        <AnimatePresence>
          {pendingTasks.map((task) => (
            <motion.div
              key={task.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className={`flex items-center gap-3 p-3 rounded-lg border ${getPriorityColor(task.priority)} bg-atlas-darker/50 hover:bg-atlas-darker transition-colors`}
            >
              <button
                onClick={() => toggleTask(task.id)}
                className="flex-shrink-0"
              >
                <Circle className="w-5 h-5 text-atlas-primary hover:text-atlas-accent transition-colors" />
              </button>
              <div className="flex-1">
                <p className="text-white text-sm">{task.title}</p>
                <p className="text-atlas-accent text-xs mt-1">
                  Priority: <span className="capitalize">{task.priority}</span>
                </p>
              </div>
              <button
                onClick={() => deleteTask(task.id)}
                className="p-1 hover:bg-red-500/20 rounded transition-colors"
              >
                <Trash2 className="w-4 h-4 text-red-400" />
              </button>
            </motion.div>
          ))}

          {completedTasks.length > 0 && (
            <div className="pt-4 border-t border-atlas-primary/30">
              <p className="text-atlas-accent text-xs mb-2">Completed ({completedCount})</p>
              {completedTasks.slice(0, 3).map((task) => (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex items-center gap-3 p-2 rounded-lg bg-atlas-darker/30 opacity-60"
                >
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  <p className="text-white text-sm line-through">{task.title}</p>
                  <button
                    onClick={() => deleteTask(task.id)}
                    className="ml-auto p-1 hover:bg-red-500/20 rounded transition-colors"
                  >
                    <Trash2 className="w-3 h-3 text-red-400" />
                  </button>
                </motion.div>
              ))}
            </div>
          )}
        </AnimatePresence>

        {tasks.length === 0 && (
          <div className="text-center py-8 text-atlas-accent text-sm">
            <Calendar className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No tasks yet. Add one above!</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

