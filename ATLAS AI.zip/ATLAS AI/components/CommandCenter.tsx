'use client';

import { motion } from 'framer-motion';
import { Terminal, Settings, Shield, Zap } from 'lucide-react';
import { useState } from 'react';

export default function CommandCenter() {
  const [activeTab, setActiveTab] = useState<'terminal' | 'settings' | 'security'>('terminal');

  const commands = [
    { id: 1, command: 'atlas status', output: 'All systems operational' },
    { id: 2, command: 'atlas scan', output: 'Scanning... No threats detected' },
    { id: 3, command: 'atlas optimize', output: 'System optimization complete' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.6 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-atlas-primary text-sm font-semibold glow-text">
          COMMAND CENTER
        </h3>
        <Zap className="w-4 h-4 text-atlas-accent" />
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setActiveTab('terminal')}
          className={`px-3 py-1 text-xs rounded transition-all ${
            activeTab === 'terminal'
              ? 'bg-atlas-primary text-atlas-dark font-semibold glow-border'
              : 'bg-atlas-dark text-atlas-accent hover:bg-atlas-primary/20'
          }`}
        >
          <Terminal className="w-3 h-3 inline mr-1" />
          Terminal
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`px-3 py-1 text-xs rounded transition-all ${
            activeTab === 'settings'
              ? 'bg-atlas-primary text-atlas-dark font-semibold glow-border'
              : 'bg-atlas-dark text-atlas-accent hover:bg-atlas-primary/20'
          }`}
        >
          <Settings className="w-3 h-3 inline mr-1" />
          Settings
        </button>
        <button
          onClick={() => setActiveTab('security')}
          className={`px-3 py-1 text-xs rounded transition-all ${
            activeTab === 'security'
              ? 'bg-atlas-primary text-atlas-dark font-semibold glow-border'
              : 'bg-atlas-dark text-atlas-accent hover:bg-atlas-primary/20'
          }`}
        >
          <Shield className="w-3 h-3 inline mr-1" />
          Security
        </button>
      </div>

      {/* Content */}
      <div className="bg-atlas-darker rounded-lg p-3 min-h-[200px] max-h-[300px] overflow-y-auto">
        {activeTab === 'terminal' && (
          <div className="space-y-2 font-mono text-xs">
            <div className="text-atlas-primary mb-2">ATLAS Terminal v1.2.5</div>
            <div className="text-atlas-accent text-xs mb-2">Type commands like: open Google, volume up, brightness 50%</div>
            {commands.map((cmd) => (
              <motion.div
                key={cmd.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: cmd.id * 0.1 }}
                className="space-y-1"
              >
                <div className="text-atlas-accent">
                  $ <span className="text-white">{cmd.command}</span>
                </div>
                <div className="text-green-400 ml-4">{cmd.output}</div>
              </motion.div>
            ))}
            <div className="flex items-center gap-2 mt-4">
              <span className="text-atlas-primary">$</span>
              <motion.div
                className="w-2 h-4 bg-atlas-primary"
                animate={{ opacity: [1, 0, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
              />
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-3 text-xs">
            <div>
              <label className="text-atlas-accent block mb-1">Voice Speed</label>
              <input type="range" min="0.5" max="2" step="0.1" defaultValue="1" className="w-full" />
            </div>
            <div>
              <label className="text-atlas-accent block mb-1">Theme</label>
              <select className="w-full bg-atlas-dark border border-atlas-primary rounded p-1 text-white">
                <option>JARVIS Blue</option>
                <option>Matrix Green</option>
                <option>Neon Purple</option>
              </select>
            </div>
            <div>
              <label className="text-atlas-accent block mb-1">Language</label>
              <select className="w-full bg-atlas-dark border border-atlas-primary rounded p-1 text-white">
                <option>English (Indian)</option>
                <option>Tamil</option>
                <option>Telugu</option>
                <option>Hindi</option>
              </select>
            </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-atlas-accent">Firewall</span>
              <span className="text-green-400">Active</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-atlas-accent">Encryption</span>
              <span className="text-green-400">Quantum-Safe</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-atlas-accent">Threat Detection</span>
              <span className="text-green-400">Enabled</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-atlas-accent">Last Scan</span>
              <span className="text-white">2 min ago</span>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

