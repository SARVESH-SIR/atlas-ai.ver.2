'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ExternalLink, Grid, List, Filter, Play, Star } from 'lucide-react';
import { playStoreAppsRegistry } from '@/lib/atlas-core/actions/playstore-apps';
import { actionExecutor } from '@/lib/atlas-core/actions/action-executor';
import type { PlayStoreApp } from '@/lib/atlas-core/actions/playstore-apps';

export default function PlayStoreAppsBrowser() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'popular'>('name');

  const categories = ['all', ...playStoreAppsRegistry.getAllCategories()];
  const allApps = playStoreAppsRegistry.getAllApps();

  // Filter and sort apps
  const filteredApps = useMemo(() => {
    let apps = allApps;

    // Filter by category
    if (selectedCategory !== 'all') {
      apps = apps.filter(app => 
        app.categories.some(cat => cat.toLowerCase() === selectedCategory.toLowerCase())
      );
    }

    // Filter by search query
    if (searchQuery.trim()) {
      apps = playStoreAppsRegistry.searchApps(searchQuery).filter(app =>
        selectedCategory === 'all' || 
        app.categories.some(cat => cat.toLowerCase() === selectedCategory.toLowerCase())
      );
      
      // Remove duplicates
      const uniqueApps = new Map<string, PlayStoreApp>();
      apps.forEach(app => uniqueApps.set(app.name, app));
      apps = Array.from(uniqueApps.values());
    }

    // Sort
    if (sortBy === 'name') {
      apps.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      // Sort by popularity (alphabetically for now, can be enhanced)
      apps.sort((a, b) => a.name.localeCompare(b.name));
    }

    return apps;
  }, [searchQuery, selectedCategory, sortBy, allApps]);

  const handleOpenApp = async (app: PlayStoreApp) => {
    const result = playStoreAppsRegistry.openApp(app);
    
    // Show notification or feedback
    if (result.success) {
      // Optional: Show toast notification
      console.log(result.message);
    }
  };

  const handleOpenPlayStore = (app: PlayStoreApp) => {
    if (typeof window !== 'undefined') {
      window.open(app.playStoreUrl, '_blank');
    }
  };

  const getCategoryColor = (category: string): string => {
    const colors: Record<string, string> = {
      'Communication': 'from-blue-500 to-cyan-500',
      'Social': 'from-purple-500 to-pink-500',
      'Media': 'from-red-500 to-orange-500',
      'Music': 'from-green-500 to-emerald-500',
      'Video': 'from-red-500 to-pink-500',
      'Productivity': 'from-indigo-500 to-blue-500',
      'Development': 'from-orange-500 to-red-500',
      'Shopping': 'from-yellow-500 to-orange-500',
      'Education': 'from-blue-500 to-indigo-500',
      'Gaming': 'from-purple-500 to-pink-500',
    };
    
    return colors[category] || 'from-gray-500 to-gray-600';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="hologram-effect rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-atlas-primary text-lg font-bold glow-text flex items-center gap-2">
            <Play className="w-5 h-5" />
            Play Store Apps
          </h3>
          <p className="text-atlas-accent text-xs mt-1">
            {filteredApps.length} of {allApps.length} apps • {categories.length - 1} categories
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
            className="p-2 bg-atlas-darker border border-atlas-primary/30 rounded-lg hover:border-atlas-primary transition-colors"
            title={viewMode === 'grid' ? 'List View' : 'Grid View'}
          >
            {viewMode === 'grid' ? <List className="w-4 h-4 text-atlas-primary" /> : <Grid className="w-4 h-4 text-atlas-primary" />}
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-atlas-accent" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search apps (e.g., WhatsApp, Instagram, YouTube)..."
          className="w-full bg-atlas-darker border border-atlas-primary/30 rounded-lg pl-10 pr-4 py-2 text-white text-sm placeholder-atlas-accent/50 focus:outline-none focus:border-atlas-primary transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-atlas-accent hover:text-atlas-primary transition-colors"
          >
            ×
          </button>
        )}
      </div>

      {/* Category Filter */}
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-2">
          <Filter className="w-4 h-4 text-atlas-primary" />
          <span className="text-atlas-accent text-xs font-semibold">Categories:</span>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-atlas-primary">
          {categories.slice(0, 8).map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-atlas-primary to-atlas-accent text-white font-semibold'
                  : 'bg-atlas-darker border border-atlas-primary/30 text-atlas-accent hover:border-atlas-primary'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Apps Display */}
      <div className={`${
        viewMode === 'grid' 
          ? 'grid grid-cols-2 gap-2' 
          : 'space-y-2'
      } max-h-[400px] overflow-y-auto`}>
        <AnimatePresence>
          {filteredApps.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="col-span-2 text-center py-8"
            >
              <Search className="w-8 h-8 mx-auto mb-2 text-atlas-primary/50" />
              <p className="text-atlas-accent text-sm">
                No apps found. Try a different search or category.
              </p>
            </motion.div>
          ) : (
            filteredApps.map((app, index) => (
              <motion.div
                key={app.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.02 }}
                className={`${
                  viewMode === 'grid'
                    ? 'p-3 rounded-lg bg-atlas-darker border border-atlas-primary/30 hover:border-atlas-primary transition-all cursor-pointer group'
                    : 'flex items-center gap-3 p-3 rounded-lg bg-atlas-darker border border-atlas-primary/30 hover:border-atlas-primary transition-all'
                }`}
                onClick={() => handleOpenApp(app)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {viewMode === 'grid' ? (
                  <>
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${getCategoryColor(app.categories[0])} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <Play className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white text-sm font-semibold truncate">{app.name}</h4>
                        <p className="text-atlas-accent text-xs truncate">{app.categories[0]}</p>
                      </div>
                    </div>
                    <p className="text-atlas-accent text-xs line-clamp-2 mb-2">{app.description}</p>
                    <div className="flex gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenApp(app);
                        }}
                        className="flex-1 px-2 py-1 bg-gradient-to-r from-atlas-primary to-atlas-accent rounded text-white text-xs hover:scale-105 transition-transform"
                      >
                        Open
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenPlayStore(app);
                        }}
                        className="px-2 py-1 bg-atlas-primary/20 border border-atlas-primary rounded text-atlas-primary text-xs hover:bg-atlas-primary/30 transition-colors"
                        title="Open in Play Store"
                      >
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${getCategoryColor(app.categories[0])} flex items-center justify-center flex-shrink-0`}>
                      <Play className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-white text-sm font-semibold">{app.name}</h4>
                      <p className="text-atlas-accent text-xs mt-1">{app.description}</p>
                      <div className="flex gap-2 mt-1">
                        {app.categories.slice(0, 2).map((cat) => (
                          <span key={cat} className="text-atlas-primary text-xs bg-atlas-primary/10 px-2 py-0.5 rounded">
                            {cat}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenApp(app);
                        }}
                        className="px-3 py-1.5 bg-gradient-to-r from-atlas-primary to-atlas-accent rounded-lg text-white text-xs hover:scale-105 transition-transform"
                      >
                        Open
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenPlayStore(app);
                        }}
                        className="p-1.5 bg-atlas-primary/20 border border-atlas-primary rounded-lg text-atlas-primary hover:bg-atlas-primary/30 transition-colors"
                        title="Play Store"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </div>
                  </>
                )}
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Stats */}
      <div className="mt-4 pt-4 border-t border-atlas-primary/30">
        <div className="flex justify-between items-center text-xs text-atlas-accent">
          <span>Showing {filteredApps.length} apps</span>
          <span>Total: {allApps.length} apps</span>
        </div>
      </div>
    </motion.div>
  );
}

