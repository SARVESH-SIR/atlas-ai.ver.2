'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState } from 'react';

interface WelcomeAnimationProps {
  userName: string;
  systemStatus: string;
}

export default function WelcomeAnimation({ userName, systemStatus }: WelcomeAnimationProps) {
  const [showGreeting, setShowGreeting] = useState(true);
  const [currentMessage, setCurrentMessage] = useState(0);

  const messages = [
    'Loading Core Modules...',
    'Establishing Secure Connection...',
    'Activating Quantum Kernel...',
    `Good ${getTimeOfDay()}, ${userName.split(' ').pop()}.`,
    'ATLAS systems are now online and fully operational.',
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentMessage((prev) => {
        if (prev < messages.length - 1) {
          return prev + 1;
        } else {
          setTimeout(() => setShowGreeting(false), 2000);
          return prev;
        }
      });
    }, 1500);

    return () => clearInterval(timer);
  }, []);

  function getTimeOfDay() {
    const hour = new Date().getHours();
    if (hour < 12) return 'Morning';
    if (hour < 18) return 'Afternoon';
    return 'Evening';
  }

  return (
    <AnimatePresence>
      {showGreeting && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-atlas-darker/95 backdrop-blur-sm"
        >
          <div className="text-center space-y-8">
            {/* ATLAS Logo/Text */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 20 }}
            >
              <h1 className="text-6xl md:text-8xl font-bold text-atlas-primary glow-text mb-4">
                ATLAS
              </h1>
              <p className="text-atlas-accent text-lg">Advanced Technical Learning and Assembly System</p>
            </motion.div>

            {/* Loading Indicator */}
            <div className="flex items-center justify-center gap-2">
              {[0, 1, 2].map((index) => (
                <motion.div
                  key={index}
                  className="w-3 h-3 rounded-full bg-atlas-primary"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                    delay: index * 0.2,
                  }}
                />
              ))}
            </div>

            {/* Status Messages */}
            <AnimatePresence mode="wait">
              <motion.p
                key={currentMessage}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="text-atlas-primary text-xl md:text-2xl font-semibold glow-text"
              >
                {messages[currentMessage]}
              </motion.p>
            </AnimatePresence>

            {/* Progress Bar */}
            <div className="w-64 md:w-96 mx-auto h-1 bg-atlas-dark rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-atlas-primary to-atlas-accent"
                initial={{ width: 0 }}
                animate={{ width: `${((currentMessage + 1) / messages.length) * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

