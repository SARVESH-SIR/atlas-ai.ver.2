'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useVoiceRecognition } from '@/hooks/useVoiceRecognition';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { atlasAIEngine } from '@/lib/atlas-core/ai-engine';

export default function VoiceInterface() {
  const { isListening, transcript, isSupported: voiceSupported, startListening, stopListening } = useVoiceRecognition();
  const { isSpeaking, speak, stop: stopSpeaking, voices } = useTextToSpeech();
  const [wakeWord, setWakeWord] = useState('Hey ATLAS!');

  const toggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  // Auto-process transcript when it changes
  useEffect(() => {
    if (transcript && !isListening) {
      // Process the command
      processVoiceCommand(transcript);
    }
  }, [transcript, isListening]);

  const processVoiceCommand = async (command: string) => {
    if (!command.trim()) return;

    try {
      // Check if it's an app/system command first
      const { actionExecutor } = await import('@/lib/atlas-core/actions/action-executor');
      const result = await actionExecutor.executeCommand(command);
      
      if (result.success) {
        // Speak the result
        const indianVoice = voices.find(v => v.lang.includes('en-IN') || v.lang.includes('en-GB')) || voices[0];
        speak(result.message, {
          rate: 1.0,
          pitch: 1.0,
          voice: indianVoice,
          lang: 'en-IN',
        });
        return;
      }

      // If not an app command, process with AI
      const response = await atlasAIEngine.processQuery('creator', command);
      
      // Speak the response
      const indianVoice = voices.find(v => v.lang.includes('en-IN') || v.lang.includes('en-GB')) || voices[0];
      speak(response.text, {
        rate: 1.0,
        pitch: 1.0,
        voice: indianVoice,
        lang: 'en-IN',
      });
    } catch (error) {
      console.error('Voice command error:', error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.8 }}
      className="hologram-effect rounded-lg p-6 mt-4"
    >
      {/* Wake Word Display */}
      <div className="text-center mb-4">
        <p className="text-atlas-accent text-xs mb-2">Wake Word</p>
        <motion.div
          className="text-atlas-primary text-xl font-bold glow-text"
          animate={{
            textShadow: isListening
              ? [
                  "0 0 10px rgba(0, 217, 255, 0.8)",
                  "0 0 20px rgba(0, 217, 255, 1)",
                  "0 0 10px rgba(0, 217, 255, 0.8)",
                ]
              : "0 0 10px rgba(0, 217, 255, 0.5)",
          }}
          transition={{
            duration: isListening ? 1.5 : 0.5,
            repeat: isListening ? Infinity : 0,
          }}
        >
          {wakeWord}
        </motion.div>
      </div>

      {/* Voice Controls */}
      <div className="flex items-center justify-center gap-6 mb-4">
        {/* Microphone Button */}
        <motion.button
          onClick={toggleListening}
          className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all ${
            isListening
              ? 'bg-red-500/20 border-2 border-red-500'
              : 'bg-atlas-primary/20 border-2 border-atlas-primary'
          }`}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          {isListening ? (
            <>
              <MicOff className="w-8 h-8 text-red-400" />
              <motion.div
                className="absolute inset-0 rounded-full border-2 border-red-500"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.8, 0, 0.8],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                }}
              />
            </>
          ) : (
            <Mic className="w-8 h-8 text-atlas-primary" />
          )}
        </motion.button>

        {/* Speaker Indicator */}
        <motion.div
          className={`relative w-16 h-16 rounded-full flex items-center justify-center ${
            isSpeaking ? 'bg-atlas-accent/20' : 'bg-atlas-dark'
          }`}
          animate={{
            scale: isSpeaking ? [1, 1.2, 1] : 1,
          }}
          transition={{
            duration: isSpeaking ? 1 : 0.5,
            repeat: isSpeaking ? Infinity : 0,
          }}
        >
          <Volume2 className="w-6 h-6 text-atlas-accent" />
        </motion.div>
      </div>

      {/* Status */}
      <div className="text-center">
        <AnimatePresence mode="wait">
          {isListening ? (
            <motion.div
              key="listening"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-2"
            >
              <p className="text-green-400 text-sm font-semibold">Listening...</p>
              {transcript && (
                <p className="text-atlas-accent text-xs italic">{transcript}</p>
              )}
            </motion.div>
          ) : isSpeaking ? (
            <motion.p
              key="speaking"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-atlas-accent text-sm font-semibold"
            >
              Speaking...
            </motion.p>
          ) : (
            <motion.p
              key="idle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-atlas-accent text-sm"
            >
              {voiceSupported ? 'Ready to listen' : 'Voice not supported'}
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      {/* Language Selector */}
      <div className="mt-4 pt-4 border-t border-atlas-primary/30">
        <p className="text-atlas-accent text-xs mb-2 text-center">Active Language</p>
        <div className="flex justify-center gap-2">
          {['EN', 'TA', 'TE', 'HI'].map((lang) => (
            <motion.button
              key={lang}
              className="px-3 py-1 bg-atlas-dark border border-atlas-primary rounded text-xs text-atlas-primary hover:bg-atlas-primary hover:text-atlas-dark transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              {lang}
            </motion.button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

