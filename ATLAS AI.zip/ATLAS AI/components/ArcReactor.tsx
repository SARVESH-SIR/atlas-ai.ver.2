'use client';

import { motion } from 'framer-motion';

export default function ArcReactor() {
  return (
    <div className="relative w-[300px] h-[300px] flex items-center justify-center">
      {/* Outer Rings */}
      <div className="absolute inset-0 flex items-center justify-center">
        {[1, 2, 3].map((ring) => (
          <motion.div
            key={ring}
            className="absolute border-2 border-atlas-primary rounded-full opacity-60"
            style={{
              width: `${100 + ring * 40}px`,
              height: `${100 + ring * 40}px`,
            }}
            animate={{
              rotate: 360,
              scale: [1, 1.05, 1],
            }}
            transition={{
              rotate: {
                duration: 20 - ring * 3,
                repeat: Infinity,
                ease: "linear",
              },
              scale: {
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              },
            }}
          />
        ))}
      </div>

      {/* Menu Labels Around Ring */}
      <div className="absolute inset-0">
        {[
          'COMP', 'DOCS', 'CTRL', 'DESK', 'GAME', 'CFG',
          'EQ', 'PL', 'SYS', 'SPK', 'DASH', 'MODE'
        ].map((label, index) => {
          const angle = (index * 30) - 90; // Start from top
          const radius = 140;
          const x = Math.cos((angle * Math.PI) / 180) * radius;
          const y = Math.sin((angle * Math.PI) / 180) * radius;

          return (
            <motion.div
              key={label}
              className="absolute text-atlas-primary text-xs font-semibold cursor-pointer hover:text-atlas-accent transition-colors glow-text"
              style={{
                left: `calc(50% + ${x}px)`,
                top: `calc(50% + ${y}px)`,
                transform: 'translate(-50%, -50%)',
              }}
              whileHover={{ scale: 1.2 }}
            >
              {label}
            </motion.div>
          );
        })}
      </div>

      {/* Central Core */}
      <motion.div
        className="relative w-24 h-24 bg-gradient-radial from-atlas-accent via-atlas-primary to-transparent rounded-full"
        animate={{
          scale: [1, 1.1, 1],
          boxShadow: [
            '0 0 40px rgba(0, 255, 255, 0.8)',
            '0 0 80px rgba(0, 217, 255, 1)',
            '0 0 40px rgba(0, 255, 255, 0.8)',
          ],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        {/* Inner Glow */}
        <div className="absolute inset-0 bg-atlas-accent rounded-full opacity-50 blur-xl" />
        
        {/* Core Center */}
        <div className="absolute inset-4 bg-atlas-primary rounded-full opacity-90" />
        
        {/* Pulsing Dot */}
        <motion.div
          className="absolute top-1/2 left-1/2 w-2 h-2 bg-white rounded-full"
          style={{ transform: 'translate(-50%, -50%)' }}
          animate={{
            scale: [1, 2, 1],
            opacity: [1, 0.5, 1],
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </motion.div>

      {/* Radial Lines */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i * 45);
        return (
          <motion.div
            key={i}
            className="absolute w-1 bg-atlas-primary opacity-30 origin-center"
            style={{
              height: '140px',
              left: '50%',
              top: '50%',
              transform: `translate(-50%, -50%) rotate(${angle}deg)`,
              transformOrigin: 'center',
            }}
          />
        );
      })}
    </div>
  );
}

