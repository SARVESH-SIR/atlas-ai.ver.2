'use client';

import { useState, useEffect } from 'react';
import { useFormattedTime } from './useRealTime';

interface WeatherData {
  location: string;
  currentTemp: string;
  condition: string;
  humidity: string;
  feelsLike: string;
  precipitation: string;
  visibility: string;
  wind: string;
  pressure: string;
  sunrise: string;
  sunset: string;
  moonPhase: string;
  forecast: Array<{
    day: string;
    high: string;
    low: string;
    condition: string;
  }>;
  lastUpdated: string;
  isLoading: boolean;
  error: string | null;
}

/**
 * Hook to fetch and auto-update weather data
 * Auto-updates every 5 minutes
 */
export function useWeather(location?: string) {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { fullDateTime } = useFormattedTime();

  // Default to Chennai if location not provided
  const weatherLocation = location || 'Chennai, India';

  const fetchWeather = async () => {
    try {
      setIsLoading(true);
      
      // Try to get user's location first
      let coords = null;
      if (navigator.geolocation && !location) {
        try {
          const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject);
          });
          coords = { lat: position.coords.latitude, lon: position.coords.longitude };
        } catch (err) {
          console.log('Geolocation not available, using default location');
        }
      }

      // If API key is available, use real weather API
      const apiKey = process.env.NEXT_PUBLIC_WEATHER_API_KEY;
      
      if (apiKey && coords) {
        // Use OpenWeatherMap API
        const response = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?lat=${coords.lat}&lon=${coords.lon}&appid=${apiKey}&units=metric`
        );
        
        if (response.ok) {
          const data = await response.json();
          
          // Get forecast
          const forecastResponse = await fetch(
            `https://api.openweathermap.org/data/2.5/forecast?lat=${coords.lat}&lon=${coords.lon}&appid=${apiKey}&units=metric&cnt=3`
          );
          
          const forecastData = forecastResponse.ok ? await forecastResponse.json() : null;
          
          setWeather({
            location: data.name + ', ' + (data.sys.country || ''),
            currentTemp: `${Math.round(data.main.temp)}°C`,
            condition: data.weather[0].description.split(' ').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
            humidity: `${data.main.humidity}%`,
            feelsLike: `${Math.round(data.main.feels_like)}°`,
            precipitation: data.rain ? `${(data.rain['1h'] || 0) * 10}%` : '0%',
            visibility: `${(data.visibility / 1000).toFixed(1)} km`,
            wind: `${Math.round(data.wind.speed * 3.6)} km/h ${getWindDirection(data.wind.deg)}`,
            pressure: `${data.main.pressure} mb`,
            sunrise: new Date(data.sys.sunrise * 1000).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }),
            sunset: new Date(data.sys.sunset * 1000).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }),
            moonPhase: getMoonPhase(),
            forecast: forecastData ? forecastData.list.slice(0, 3).map((item: any, index: number) => ({
              day: index === 0 ? 'Tonight' : index === 1 ? 'Tomorrow' : new Date(item.dt * 1000).toLocaleDateString('en-US', { weekday: 'long' }),
              high: `${Math.round(item.main.temp_max)}°`,
              low: `${Math.round(item.main.temp_min)}°`,
              condition: item.weather[0].description.split(' ').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
            })) : [],
            lastUpdated: fullDateTime,
            isLoading: false,
            error: null,
          });
          setIsLoading(false);
          return;
        }
      }

      // Fallback to mock data with auto-updating time
      setWeather({
        location: weatherLocation,
        currentTemp: generateMockTemp(),
        condition: getMockCondition(),
        humidity: `${40 + Math.floor(Math.random() * 30)}%`,
        feelsLike: `${25 + Math.floor(Math.random() * 10)}°`,
        precipitation: `${Math.floor(Math.random() * 20)}%`,
        visibility: `${10 + Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)} km`,
        wind: `${5 + Math.floor(Math.random() * 15)} km/h ${['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.floor(Math.random() * 8)]}`,
        pressure: `${1000 + Math.floor(Math.random() * 30)}.${Math.floor(Math.random() * 10)} mb`,
        sunrise: getSunriseTime(),
        sunset: getSunsetTime(),
        moonPhase: getMoonPhase(),
        forecast: [
          { day: 'Tonight', high: `${20 + Math.floor(Math.random() * 5)}°`, low: `${18 + Math.floor(Math.random() * 4)}°`, condition: 'Mostly Clear' },
          { day: 'Tomorrow', high: `${28 + Math.floor(Math.random() * 5)}°`, low: `${22 + Math.floor(Math.random() * 4)}°`, condition: 'Partly Cloudy' },
          { day: 'Tuesday', high: `${30 + Math.floor(Math.random() * 5)}°`, low: `${24 + Math.floor(Math.random() * 4)}°`, condition: 'Mostly Sunny' },
        ],
        lastUpdated: fullDateTime,
        isLoading: false,
        error: null,
      });
      setIsLoading(false);
    } catch (error) {
      console.error('Weather fetch error:', error);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather();
    
    // Auto-update every 5 minutes (300000 ms)
    const interval = setInterval(() => {
      fetchWeather();
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [location]);

  return { weather, isLoading, refresh: fetchWeather };
}

// Helper functions
function generateMockTemp(): string {
  const hour = new Date().getHours();
  // Simulate temperature based on time of day
  const baseTemp = 25 + (hour > 6 && hour < 18 ? 5 : -5);
  const variation = Math.floor(Math.random() * 5);
  return `${baseTemp + variation}°C`;
}

function getMockCondition(): string {
  const conditions = ['Sunny', 'Partly Cloudy', 'Cloudy', 'Clear', 'Mostly Sunny'];
  return conditions[Math.floor(Math.random() * conditions.length)];
}

function getWindDirection(deg: number): string {
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  return directions[Math.round(deg / 45) % 8];
}

function getSunriseTime(): string {
  const now = new Date();
  const sunrise = new Date(now);
  sunrise.setHours(6, 15, 0, 0);
  return sunrise.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

function getSunsetTime(): string {
  const now = new Date();
  const sunset = new Date(now);
  sunset.setHours(18, 45, 0, 0);
  return sunset.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

function getMoonPhase(): string {
  const phases = ['New Moon', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous', 'Full Moon', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent'];
  const day = new Date().getDate();
  return phases[day % 8];
}

