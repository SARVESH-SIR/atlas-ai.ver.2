'use client';

import { useState, useEffect } from 'react';

/**
 * Hook to get current time that updates every second
 */
export function useRealTime() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000); // Update every second

    return () => clearInterval(timer);
  }, []);

  return time;
}

/**
 * Hook to get formatted time string
 */
export function useFormattedTime() {
  const currentTime = useRealTime();
  
  const timeString = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });

  const dateString = currentTime.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const dateShortString = currentTime.toLocaleDateString('en-US', {
    month: 'numeric',
    day: 'numeric',
    year: '2-digit',
  });

  return {
    time: timeString,
    date: dateString,
    dateShort: dateShortString,
    fullDateTime: currentTime.toLocaleString('en-US', {
      month: 'numeric',
      day: 'numeric',
      year: '2-digit',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    }),
    timestamp: currentTime,
  };
}

