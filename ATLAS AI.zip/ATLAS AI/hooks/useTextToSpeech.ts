'use client';

import { useState, useEffect } from 'react';

interface TextToSpeechState {
  isSpeaking: boolean;
  isSupported: boolean;
  voices: SpeechSynthesisVoice[];
}

/**
 * Hook for text-to-speech using Web Speech API
 */
export function useTextToSpeech() {
  const [state, setState] = useState<TextToSpeechState>({
    isSpeaking: false,
    isSupported: false,
    voices: [],
  });

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      setState(prev => ({ ...prev, isSupported: true }));
      
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        setState(prev => ({ ...prev, voices }));
      };

      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  const speak = (text: string, options?: {
    rate?: number;
    pitch?: number;
    volume?: number;
    voice?: SpeechSynthesisVoice;
    lang?: string;
  }) => {
    if (!state.isSupported || !text) return;

    // Stop any current speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options?.rate || 1.0;
    utterance.pitch = options?.pitch || 1.0;
    utterance.volume = options?.volume || 1.0;
    utterance.lang = options?.lang || 'en-US';
    
    if (options?.voice) {
      utterance.voice = options.voice;
    }

    utterance.onstart = () => {
      setState(prev => ({ ...prev, isSpeaking: true }));
    };

    utterance.onend = () => {
      setState(prev => ({ ...prev, isSpeaking: false }));
    };

    utterance.onerror = () => {
      setState(prev => ({ ...prev, isSpeaking: false }));
    };

    window.speechSynthesis.speak(utterance);
  };

  const stop = () => {
    if (state.isSupported) {
      window.speechSynthesis.cancel();
      setState(prev => ({ ...prev, isSpeaking: false }));
    }
  };

  const pause = () => {
    if (state.isSupported) {
      window.speechSynthesis.pause();
    }
  };

  const resume = () => {
    if (state.isSupported) {
      window.speechSynthesis.resume();
    }
  };

  return {
    ...state,
    speak,
    stop,
    pause,
    resume,
  };
}

