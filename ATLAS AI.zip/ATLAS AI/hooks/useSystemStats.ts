'use client';

import { useState, useEffect } from 'react';

interface SystemStats {
  cpu: {
    usage: number;
    temperature: number;
  };
  memory: {
    usage: number;
    total: number;
    used: number;
    free: number;
  };
  disk: {
    total: number;
    used: number;
    free: number;
    usage: number;
  };
  network: {
    upload: number;
    download: number;
    uploadSpeed: number;
    downloadSpeed: number;
  };
  gpu: {
    usage: number;
    temperature: number;
  };
}

/**
 * Hook to get system statistics with auto-update
 * Updates every 2 seconds
 */
export function useSystemStats() {
  const [stats, setStats] = useState<SystemStats>(() => getInitialStats());

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prevStats) => ({
        cpu: {
          usage: Math.max(0, Math.min(100, prevStats.cpu.usage + (Math.random() * 10 - 5))),
          temperature: Math.max(20, Math.min(80, prevStats.cpu.temperature + (Math.random() * 2 - 1))),
        },
        memory: {
          usage: Math.max(30, Math.min(90, prevStats.memory.usage + (Math.random() * 5 - 2.5))),
          total: prevStats.memory.total,
          used: (prevStats.memory.total * (prevStats.memory.usage / 100)),
          free: prevStats.memory.total * (1 - prevStats.memory.usage / 100),
        },
        disk: {
          ...prevStats.disk,
          used: prevStats.disk.total * (prevStats.disk.usage / 100),
          free: prevStats.disk.total * (1 - prevStats.disk.usage / 100),
        },
        network: {
          upload: Math.max(0, Math.min(100, prevStats.network.upload + (Math.random() * 10 - 5))),
          download: Math.max(0, Math.min(100, prevStats.network.download + (Math.random() * 10 - 5))),
          uploadSpeed: Math.max(0, prevStats.network.uploadSpeed + (Math.random() * 20 - 10)),
          downloadSpeed: Math.max(0, prevStats.network.downloadSpeed + (Math.random() * 30 - 15)),
        },
        gpu: {
          usage: Math.max(0, Math.min(100, prevStats.gpu.usage + (Math.random() * 8 - 4))),
          temperature: Math.max(25, Math.min(75, prevStats.gpu.temperature + (Math.random() * 1.5 - 0.75))),
        },
      }));
    }, 2000); // Update every 2 seconds

    return () => clearInterval(interval);
  }, []);

  return stats;
}

function getInitialStats(): SystemStats {
  return {
    cpu: {
      usage: 45,
      temperature: 35,
    },
    memory: {
      usage: 68,
      total: 16, // GB
      used: 10.88,
      free: 5.12,
    },
    disk: {
      total: 441.1, // GB
      used: 241.1,
      free: 200.0,
      usage: 54.65,
    },
    network: {
      upload: 65,
      download: 82,
      uploadSpeed: 124.5,
      downloadSpeed: 312.8,
    },
    gpu: {
      usage: 32,
      temperature: 42,
    },
  };
}

