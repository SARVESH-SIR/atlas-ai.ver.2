# ATLAS AI - Setup Guide

## Quick Start

### Step 1: Install Node.js

If Node.js is not installed:

1. Download Node.js from [https://nodejs.org/](https://nodejs.org/)
2. Install the LTS version (recommended: 18.x or higher)
3. Verify installation:
   ```bash
   node --version
   npm --version
   ```

### Step 2: Install Dependencies

Open terminal/PowerShell in the project directory and run:

```bash
npm install
```

This will install all required packages:
- Next.js 14+
- React 18
- TypeScript
- Tailwind CSS
- Framer Motion
- And all other dependencies

### Step 3: Configure Environment Variables (Optional)

1. Copy the example environment file:
   ```bash
   cp env.example .env.local
   ```

2. Edit `.env.local` and add your API keys (optional for basic UI, required for full AI features):
   ```env
   OPENAI_API_KEY=your_key_here
   # Add other API keys as needed
   ```

### Step 4: Run Development Server

```bash
npm run dev
```

### Step 5: Open in Browser

Navigate to: [http://localhost:3000](http://localhost:3000)

You should see the ATLAS AI JARVIS-style interface!

---

## Project Structure Overview

```
ATLAS AI/
├── app/                    # Next.js app directory
│   ├── layout.tsx         # Root layout
│   ├── page.tsx           # Main page
│   └── globals.css        # Global styles
├── components/            # React components
│   ├── ArcReactor.tsx     # Central arc reactor
│   ├── StatusBar.tsx      # Top status bar
│   ├── SystemMonitor.tsx  # System metrics
│   ├── WeatherPanel.tsx   # Weather info
│   ├── CommandCenter.tsx  # Terminal/controls
│   ├── VoiceInterface.tsx # Voice controls
│   ├── NavigationRing.tsx # Navigation
│   └── WelcomeAnimation.tsx # Startup animation
├── lib/                   # Core libraries
│   └── atlas-core/
│       ├── config.ts      # Configuration
│       ├── memory.ts      # Memory system
│       └── ai-engine.ts   # AI engine
├── package.json           # Dependencies
├── tsconfig.json          # TypeScript config
├── tailwind.config.ts     # Tailwind config
└── README.md              # Documentation
```

---

## Troubleshooting

### Issue: `npm` is not recognized

**Solution**: Node.js is not installed or not in PATH.
1. Install Node.js from [nodejs.org](https://nodejs.org/)
2. Restart your terminal
3. Verify: `npm --version`

### Issue: Port 3000 is already in use

**Solution**: Use a different port:
```bash
npm run dev -- -p 3001
```

### Issue: Module not found errors

**Solution**: Reinstall dependencies:
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue: TypeScript errors

**Solution**: These are likely due to missing dependencies. Run:
```bash
npm install
```

Then restart your IDE/editor.

### Issue: Tailwind styles not working

**Solution**: Ensure Tailwind is properly configured:
1. Check `tailwind.config.ts` exists
2. Check `postcss.config.js` exists
3. Restart the dev server

---

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

---

## Next Steps

1. **Customize Configuration**
   - Edit `lib/atlas-core/config.ts` for system settings
   - Modify `tailwind.config.ts` for theme colors

2. **Add AI Integration**
   - Get API keys from OpenAI, DeepSeek, or Gemini
   - Add keys to `.env.local`
   - Integrate with `lib/atlas-core/ai-engine.ts`

3. **Customize UI**
   - Edit components in `components/` directory
   - Modify styles in `app/globals.css`
   - Adjust animations and effects

4. **Deploy**
   - Deploy to Vercel: `vercel`
   - Or deploy to your preferred platform

---

## Support

If you encounter issues:
1. Check the README.md for detailed documentation
2. Verify all dependencies are installed
3. Check console for error messages
4. Ensure Node.js version is 18.x or higher

---

**"Good day, Sir. ATLAS systems are ready for deployment."** 🤖✨

