# 🎮 ATLAS AI - Commands Reference

## Complete Command List

### 📱 App Commands

#### **Web Applications**

**Google/Chrome**
- ✅ `open Google`
- ✅ `open Chrome`
- ✅ `open browser`
- ✅ `search [query] in Google`
- ✅ `search [query] on Google`

**YouTube**
- ✅ `open YouTube`
- ✅ `open YT`
- ✅ `search [video] on YouTube`
- ✅ `play [video] on YouTube`

**Communication**
- ✅ `open WhatsApp`
- ✅ `open Telegram`
- ✅ `open Discord`
- ✅ `open Gmail`

**Media**
- ✅ `open Spotify`
- ✅ `play music on Spotify`
- ✅ `open [song] on Spotify`

**Development**
- ✅ `open GitHub`
- ✅ `open VS Code` (requires desktop setup)

**Social Media**
- ✅ `open Twitter`
- ✅ `open X`

---

### ⚙️ System Commands

#### **Volume Control**
```
✅ volume up
✅ volume down
✅ increase volume
✅ decrease volume
✅ mute
✅ unmute
```

#### **Brightness Control**
```
✅ brightness up
✅ brightness down
✅ increase brightness
✅ decrease brightness
✅ brightness [percentage]%  (e.g., "brightness 75%")
```

#### **Network Control**
```
✅ wifi on
✅ wifi off
✅ enable wifi
✅ disable wifi
✅ bluetooth on
✅ bluetooth off
✅ enable bluetooth
✅ disable bluetooth
```

#### **System Actions**
```
✅ take screenshot
✅ capture screen
✅ screenshot
```

#### **File Operations**
```
✅ open file
✅ open folder
```

---

### 🎤 Voice Commands

All commands work with voice! Just say:

```
"Hey ATLAS, open Google"
"Hey ATLAS, volume up"
"Hey ATLAS, search AI in YouTube"
"Hey ATLAS, brightness 50%"
"Hey ATLAS, take screenshot"
```

---

### 💬 Chat Commands

You can also type commands in the AI Chat Interface:

```
You: "open Google"
ATLAS: "Opening Google in browser"

You: "volume up"
ATLAS: "Volume increased"

You: "search Python tutorials in YouTube"
ATLAS: "Opening YouTube and searching for Python tutorials"
```

---

### 🔄 Combined Commands

You can combine multiple actions:

```
✅ "open Google and search for AI"
✅ "open YouTube and play music"
✅ "volume up and brightness 75%"
```

---

## 📋 Supported Apps (12+)

1. **Google** - Search, browser
2. **YouTube** - Videos, music
3. **WhatsApp** - Messaging
4. **Telegram** - Messaging
5. **Gmail** - Email
6. **Spotify** - Music streaming
7. **Discord** - Chat, voice
8. **Twitter/X** - Social media
9. **GitHub** - Code repository
10. **VS Code** - Code editor (desktop)
11. **Calculator** - System calculator
12. **Notepad** - Text editor (Windows)

---

## 🎯 Command Examples

### **Opening Apps**
```
✅ "open Google"
✅ "launch YouTube"
✅ "start Spotify"
✅ "open WhatsApp"
```

### **Searching in Apps**
```
✅ "search AI in Google"
✅ "search Python tutorials on YouTube"
✅ "find music on Spotify"
✅ "look for code on GitHub"
```

### **System Controls**
```
✅ "volume up"          → Increases volume
✅ "volume down"        → Decreases volume
✅ "brightness 80%"     → Sets brightness to 80%
✅ "wifi on"           → Enables WiFi
✅ "bluetooth off"     → Disables Bluetooth
✅ "take screenshot"   → Captures screen
```

### **Complex Commands**
```
✅ "open Google and search for machine learning"
✅ "open YouTube and play relaxing music"
✅ "volume up and open Spotify"
```

---

## 🎨 UI Components

### **1. App Control Panel**
- Command input field
- Quick command buttons
- Command history
- Real-time status
- Suggestions dropdown

### **2. Available Apps Panel**
- Visual app grid
- Category filters
- Click to open
- App descriptions

---

## 💡 Usage Tips

1. **Be Specific**: Say app name clearly
2. **Use Aliases**: Try different names (chrome = Google)
3. **Natural Language**: Commands work naturally
4. **Check History**: See past commands
5. **Voice + Text**: Both work the same way

---

## 🔍 How Commands Work

### **Command Processing**

1. **Parse Command**: Extract app/action
2. **Identify Type**: App or system command
3. **Execute Action**: Open app or control system
4. **Provide Feedback**: Confirm to user

### **App Opening Flow**

```
Command: "open Google"
    ↓
Parse: App = Google, Action = open
    ↓
Find: Google app info (URL, actions)
    ↓
Execute: window.open(google.com)
    ↓
Feedback: "Opening Google in browser"
```

---

## 📊 Command Statistics

- **Total Apps**: 12+
- **Total Commands**: 50+
- **System Actions**: 10+
- **Voice Support**: ✅ All commands
- **Chat Support**: ✅ All commands

---

## 🚀 Quick Start

1. **Open App Control Panel** (right side)
2. **Type or speak command**: "open Google"
3. **Press Enter or click Execute**
4. **See result**: App opens in new tab

**Or use voice**:
1. Click microphone button
2. Say: "Hey ATLAS, open Google"
3. ATLAS executes and confirms

---

## ✅ Summary

**Command Features**:
- ✅ 12+ supported apps
- ✅ 50+ commands
- ✅ Voice + text support
- ✅ System controls
- ✅ Command history
- ✅ Quick actions
- ✅ Suggestions
- ✅ Combined commands

**"Good day, Sir. ATLAS can now execute app and system commands through voice and text."** 🤖🎮✨

---

**Try Now**:
- "open Google"
- "volume up"
- "search AI in YouTube"
- "brightness 75%"

