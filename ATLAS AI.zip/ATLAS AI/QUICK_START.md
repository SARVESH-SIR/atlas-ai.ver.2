# 🚀 Quick Start Guide - See ATLAS AI Preview

## Step 1: Install Node.js (If Not Installed)

Node.js is required to run the ATLAS AI application.

### Download & Install:
1. Go to [https://nodejs.org/](https://nodejs.org/)
2. Download the **LTS version** (recommended: 18.x or higher)
3. Run the installer and follow the installation wizard
4. **Important**: Make sure to check "Add to PATH" during installation

### Verify Installation:
After installing, **close and reopen your terminal/PowerShell**, then run:
```bash
node --version
npm --version
```

You should see version numbers if Node.js is installed correctly.

---

## Step 2: Install Dependencies

Once Node.js is installed, open terminal/PowerShell in the project folder and run:

```bash
npm install
```

This will install all required packages (Next.js, React, Tailwind CSS, etc.)
- This may take 2-5 minutes depending on your internet speed
- You'll see a progress bar during installation

---

## Step 3: Start Development Server

After dependencies are installed, run:

```bash
npm run dev
```

You should see output like:
```
  ▲ Next.js 14.2.0
  - Local:        http://localhost:3000
  - Ready in 2.5s
```

---

## Step 4: Open in Browser

Open your web browser and go to:

**http://localhost:3000**

You should see the ATLAS AI JARVIS-style interface! 🎉

---

## 🎨 What You'll See

- **Dark futuristic interface** with glowing blue/cyan accents
- **Animated Arc Reactor** in the center
- **System monitoring panels** on the left
- **Weather panel** on the right
- **Voice interface controls** below the reactor
- **Welcome animation** on first load

---

## ⚠️ Troubleshooting

### Problem: `node` command not found
**Solution**: 
- Make sure Node.js is installed
- Close and reopen your terminal
- If still not working, restart your computer

### Problem: Port 3000 is already in use
**Solution**: Use a different port:
```bash
npm run dev -- -p 3001
```
Then open: http://localhost:3001

### Problem: Dependencies installation fails
**Solution**: 
- Make sure you have internet connection
- Try deleting `node_modules` folder (if exists) and `package-lock.json`
- Run `npm install` again

### Problem: The page doesn't load
**Solution**: 
- Make sure the dev server is running (you should see "Ready" in terminal)
- Check the terminal for any error messages
- Make sure you're going to the correct URL: http://localhost:3000

---

## 📝 Quick Commands Reference

```bash
# Install dependencies (first time only)
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Check for linting errors
npm run lint
```

---

## 🎯 Next Steps After Preview

Once you see the interface:
1. Try interacting with the components
2. Check out the animations and effects
3. Customize colors in `tailwind.config.ts`
4. Add AI integration by adding API keys to `.env.local`

---

**"Good day, Sir. ATLAS systems are ready for preview."** 🤖✨

