/**
 * ATLAS Master Brain - Orchestrates All Knowledge Brains
 * Coordinates multiple specialized AI brains for enhanced intelligence
 */

import { knowledgeEngine, KnowledgeResponse } from './knowledge-engine';
import { reasoningEngine, ReasoningResponse } from './reasoning-engine';
import { researchEngine, ResearchResult } from './research-engine';
import { codingEngine, CodeResponse } from './coding-engine';
import { creativeEngine, CreativeResponse } from './creative-engine';
import { scienceEngine, ScienceResponse } from './science-engine';
import { medicalEngine, MedicalResponse } from './medical-engine';
import { languageEngine, TranslationResponse } from './language-engine';
import { llmAdapterManager } from '../llm/llm-adapter';

export interface MasterBrainResponse {
  primary: any;
  additional?: Array<{ brain: string; response: any }>;
  synthesis: string;
  confidence: number;
  reasoning: string;
}

export class MasterBrain {
  /**
   * Process query using all relevant knowledge brains
   */
  async processQuery(query: string, context?: string): Promise<MasterBrainResponse> {
    // Detect query type and route to appropriate brains
    const queryType = this.detectQueryType(query);
    const relevantBrains = this.selectRelevantBrains(queryType, query);

    // Process with primary brain
    const primaryResponse = await this.processWithPrimaryBrain(query, queryType, context);

    // Process with additional brains for comprehensive response
    const additionalResponses = await Promise.all(
      relevantBrains.slice(1).map(brain => 
        this.processWithBrain(brain, query, context)
      )
    );

    // Synthesize all responses
    const synthesis = this.synthesizeResponses(primaryResponse, additionalResponses);
    
    return {
      primary: primaryResponse,
      additional: additionalResponses.map((resp, idx) => ({
        brain: relevantBrains[idx + 1],
        response: resp,
      })),
      synthesis,
      confidence: this.calculateOverallConfidence(primaryResponse, additionalResponses),
      reasoning: this.generateMasterReasoning(query, queryType, primaryResponse, additionalResponses),
    };
  }

  /**
   * Detect query type
   */
  private detectQueryType(query: string): string {
    const lowerQuery = query.toLowerCase();

    if (lowerQuery.includes('code') || lowerQuery.includes('program') || lowerQuery.includes('function')) {
      return 'coding';
    }
    if (lowerQuery.includes('translate') || lowerQuery.includes('language') || lowerQuery.includes('meaning')) {
      return 'language';
    }
    if (lowerQuery.includes('create') || lowerQuery.includes('write') || lowerQuery.includes('story') || lowerQuery.includes('poem')) {
      return 'creative';
    }
    if (lowerQuery.includes('research') || lowerQuery.includes('study') || lowerQuery.includes('paper')) {
      return 'research';
    }
    if (lowerQuery.includes('solve') || lowerQuery.includes('reason') || lowerQuery.includes('analyze')) {
      return 'reasoning';
    }
    if (lowerQuery.includes('medical') || lowerQuery.includes('health') || lowerQuery.includes('symptom')) {
      return 'medical';
    }
    if (lowerQuery.includes('physics') || lowerQuery.includes('chemistry') || lowerQuery.includes('biology')) {
      return 'science';
    }

    return 'knowledge';
  }

  /**
   * Select relevant brains for query
   */
  private selectRelevantBrains(queryType: string, query: string): string[] {
    const brainMap: Record<string, string[]> = {
      coding: ['coding', 'reasoning', 'knowledge'],
      language: ['language', 'knowledge'],
      creative: ['creative', 'knowledge'],
      research: ['research', 'knowledge', 'reasoning'],
      reasoning: ['reasoning', 'knowledge', 'research'],
      medical: ['medical', 'knowledge', 'research'],
      science: ['science', 'knowledge', 'reasoning'],
      knowledge: ['knowledge', 'reasoning'],
    };

    return brainMap[queryType] || ['knowledge'];
  }

  /**
   * Process with primary brain (with LLM enhancement)
   */
  private async processWithPrimaryBrain(query: string, queryType: string, context?: string): Promise<any> {
    // Try to enhance with LLM if available
    const llmAdapter = llmAdapterManager.getDefaultAdapter();
    const useLLM = llmAdapter && llmAdapter.isReady();

    if (useLLM) {
      // Use ChatGPT for enhanced brain responses
      try {
        const brainContext = `You are the ATLAS ${queryType} brain. Provide expert-level response.`;
        const llmResponse = await llmAdapter.generateResponse(query, `${context || ''}\n${brainContext}`);
        
        // Combine with brain-specific processing
        switch (queryType) {
          case 'coding':
            const codeResponse = await codingEngine.generateCode(query);
            return { ...codeResponse, enhancedContent: llmResponse.content };
          case 'language':
            const langResponse = await languageEngine.translate(query, 'english');
            return { ...langResponse, enhancedContent: llmResponse.content };
          case 'creative':
            const creativeResponse = await creativeEngine.create(query);
            return { ...creativeResponse, enhancedContent: llmResponse.content };
          case 'research':
            const researchResponse = await researchEngine.research(query);
            return { ...researchResponse, enhancedContent: llmResponse.content };
          case 'reasoning':
            const reasoningResponse = await reasoningEngine.reason(query, context);
            return { ...reasoningResponse, enhancedContent: llmResponse.content };
          case 'medical':
            const medicalResponse = await medicalEngine.getInformation(query);
            return { ...medicalResponse, enhancedContent: llmResponse.content };
          case 'science':
            const scienceResponse = await scienceEngine.explain(query);
            return { ...scienceResponse, enhancedContent: llmResponse.content };
          default:
            const knowledgeResponse = await knowledgeEngine.processQuery(query, context);
            return { ...knowledgeResponse, enhancedContent: llmResponse.content };
        }
      } catch (llmError) {
        console.error('LLM enhancement error:', llmError);
        // Fall through to non-LLM processing
      }
    }

    // Non-LLM processing (fallback or if LLM not available)
    switch (queryType) {
      case 'coding':
        return await codingEngine.generateCode(query);
      case 'language':
        return await languageEngine.translate(query, 'english');
      case 'creative':
        return await creativeEngine.create(query);
      case 'research':
        return await researchEngine.research(query);
      case 'reasoning':
        return await reasoningEngine.reason(query, context);
      case 'medical':
        return await medicalEngine.getInformation(query);
      case 'science':
        return await scienceEngine.explain(query);
      default:
        return await knowledgeEngine.processQuery(query, context);
    }
  }

  /**
   * Process with specific brain
   */
  private async processWithBrain(brainName: string, query: string, context?: string): Promise<any> {
    switch (brainName) {
      case 'knowledge':
        return await knowledgeEngine.processQuery(query, context);
      case 'reasoning':
        return await reasoningEngine.reason(query, context);
      case 'research':
        return await researchEngine.research(query);
      default:
        return { message: 'Processing...' };
    }
  }

  /**
   * Synthesize responses from multiple brains
   */
  private synthesizeResponses(primary: any, additional: any[]): string {
    return `Master Synthesis:
    
Primary Response: [${typeof primary === 'object' ? JSON.stringify(primary).substring(0, 100) : primary}...]

Additional Insights: ${additional.length} complementary perspectives from specialized knowledge brains.

Integrated Answer: Combining the primary response with insights from ${additional.length} additional knowledge brains, I provide you with a comprehensive and well-reasoned answer, Sir.`;
  }

  /**
   * Calculate overall confidence
   */
  private calculateOverallConfidence(primary: any, additional: any[]): number {
    // Base confidence from primary
    const primaryConf = primary.confidence || 0.7;
    
    // Additional brains increase confidence
    const additionalBoost = Math.min(0.15, additional.length * 0.03);
    
    return Math.min(0.98, primaryConf + additionalBoost);
  }

  /**
   * Generate master reasoning
   */
  private generateMasterReasoning(
    query: string,
    queryType: string,
    primary: any,
    additional: any[]
  ): string {
    return `Master Reasoning:
    
Query Analysis: "${query}" was identified as a ${queryType} query.
Brain Selection: Primary brain (${queryType}) + ${additional.length} supporting brain(s).
Processing: All relevant knowledge brains processed the query in parallel.
Synthesis: Responses were integrated to provide comprehensive answer.
Confidence: High confidence based on multi-brain validation, Sir.`;
  }

  /**
   * Get all available brains
   */
  getAvailableBrains(): string[] {
    return [
      'knowledge',
      'reasoning',
      'research',
      'coding',
      'creative',
      'science',
      'medical',
      'language',
    ];
  }

  /**
   * Get brain capabilities
   */
  getBrainCapabilities(brainName: string): string[] {
    const capabilities: Record<string, string[]> = {
      knowledge: ['Universal knowledge', 'Multi-domain expertise', 'Information synthesis'],
      reasoning: ['Logical reasoning', 'Problem-solving', 'Critical thinking'],
      research: ['Information gathering', 'Source analysis', 'Knowledge synthesis'],
      coding: ['Code generation', 'Debugging', 'Optimization', 'Architecture analysis'],
      creative: ['Story generation', 'Poetry', 'Ideas', 'Design concepts'],
      science: ['Scientific explanations', 'Formula analysis', 'Problem solving'],
      medical: ['Health information', 'Educational content', 'Wellness tips'],
      language: ['Translation', 'Language detection', 'Multilingual support'],
    };

    return capabilities[brainName] || [];
  }
}

export const masterBrain = new MasterBrain();

