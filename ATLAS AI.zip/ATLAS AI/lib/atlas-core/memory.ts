/**
 * ATLAS AI Memory System
 * Handles long-term memory, preferences, and user data storage
 */

export interface UserMemory {
  userId: string;
  name: string;
  preferences: {
    voiceSpeed: number;
    voicePitch: number;
    language: string;
    theme: string;
    wakeWord: string;
  };
  habits: string[];
  contacts: Contact[];
  projects: Project[];
  history: ConversationHistory[];
  bio?: string;
}

export interface Contact {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  relationship?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'completed' | 'paused';
  createdAt: Date;
  updatedAt: Date;
}

export interface ConversationHistory {
  id: string;
  timestamp: Date;
  userMessage: string;
  atlasResponse: string;
  context?: Record<string, any>;
}

class AtlasMemory {
  private memory: Map<string, UserMemory> = new Map();

  constructor() {
    // Initialize with creator's data
    this.initializeCreatorMemory();
  }

  private initializeCreatorMemory() {
    const creatorId = 'creator';
    const creatorMemory: UserMemory = {
      userId: creatorId,
      name: 'K.V.SARVESH',
      preferences: {
        voiceSpeed: 1.0,
        voicePitch: 1.0,
        language: 'en-IN',
        theme: 'jarvis-blue',
        wakeWord: 'Hey ATLAS',
      },
      habits: [],
      contacts: [],
      projects: [],
      history: [],
      bio: 'Creator of ATLAS AI',
    };

    this.memory.set(creatorId, creatorMemory);
  }

  // Save user memory
  saveMemory(userId: string, data: Partial<UserMemory>): void {
    const existing = this.memory.get(userId) || {
      userId,
      name: '',
      preferences: {
        voiceSpeed: 1.0,
        voicePitch: 1.0,
        language: 'en-IN',
        theme: 'jarvis-blue',
        wakeWord: 'Hey ATLAS',
      },
      habits: [],
      contacts: [],
      projects: [],
      history: [],
    };

    this.memory.set(userId, { ...existing, ...data });
  }

  // Get user memory
  getMemory(userId: string): UserMemory | undefined {
    return this.memory.get(userId);
  }

  // Add conversation to history
  addToHistory(userId: string, userMessage: string, atlasResponse: string, context?: Record<string, any>): void {
    const userMemory = this.memory.get(userId);
    if (!userMemory) return;

    const historyEntry: ConversationHistory = {
      id: `${Date.now()}-${Math.random()}`,
      timestamp: new Date(),
      userMessage,
      atlasResponse,
      context,
    };

    userMemory.history.push(historyEntry);
    
    // Keep only last 1000 conversations in memory
    if (userMemory.history.length > 1000) {
      userMemory.history = userMemory.history.slice(-1000);
    }

    this.memory.set(userId, userMemory);
  }

  // Get conversation context
  getRecentContext(userId: string, limit: number = 10): ConversationHistory[] {
    const userMemory = this.memory.get(userId);
    if (!userMemory) return [];

    return userMemory.history.slice(-limit);
  }

  // Add habit
  addHabit(userId: string, habit: string): void {
    const userMemory = this.memory.get(userId);
    if (!userMemory) return;

    if (!userMemory.habits.includes(habit)) {
      userMemory.habits.push(habit);
      this.memory.set(userId, userMemory);
    }
  }

  // Add contact
  addContact(userId: string, contact: Contact): void {
    const userMemory = this.memory.get(userId);
    if (!userMemory) return;

    const existingIndex = userMemory.contacts.findIndex(c => c.id === contact.id);
    if (existingIndex >= 0) {
      userMemory.contacts[existingIndex] = contact;
    } else {
      userMemory.contacts.push(contact);
    }

    this.memory.set(userId, userMemory);
  }

  // Add project
  addProject(userId: string, project: Project): void {
    const userMemory = this.memory.get(userId);
    if (!userMemory) return;

    const existingIndex = userMemory.projects.findIndex(p => p.id === project.id);
    if (existingIndex >= 0) {
      userMemory.projects[existingIndex] = project;
    } else {
      userMemory.projects.push(project);
    }

    this.memory.set(userId, userMemory);
  }
}

// Singleton instance
export const atlasMemory = new AtlasMemory();

