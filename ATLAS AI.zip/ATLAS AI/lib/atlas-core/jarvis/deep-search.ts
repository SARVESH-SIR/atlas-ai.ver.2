/**
 * ATLAS AI - Jarvis-Level Deep Search
 * Semantic search, cross-platform search, intelligent search
 */

export interface SearchResult {
  id: string;
  type: 'file' | 'email' | 'calendar' | 'note' | 'app' | 'command' | 'web' | 'knowledge';
  title: string;
  content: string;
  snippet: string;
  relevance: number; // 0-1
  metadata: Record<string, any>;
  timestamp?: Date;
  url?: string;
}

export interface SearchQuery {
  query: string;
  filters?: {
    type?: SearchResult['type'][];
    dateRange?: { start: Date; end: Date };
    tags?: string[];
    category?: string;
  };
  limit?: number;
  sortBy?: 'relevance' | 'date' | 'name';
}

export class DeepSearchEngine {
  private searchIndex: Map<string, Set<string>> = new Map(); // term -> resultIds
  private results: Map<string, SearchResult> = new Map();
  private searchHistory: Array<{ query: string; timestamp: Date; results: number }> = [];

  constructor() {
    this.initializeIndex();
  }

  /**
   * Initialize search index
   */
  private initializeIndex() {
    // Would load existing index in production
  }

  /**
   * Index search result
   */
  indexResult(result: SearchResult): void {
    this.results.set(result.id, result);

    // Extract search terms
    const terms = this.extractSearchTerms(result.title, result.content);

    // Index terms
    terms.forEach(term => {
      if (!this.searchIndex.has(term)) {
        this.searchIndex.set(term, new Set());
      }
      this.searchIndex.get(term)!.add(result.id);
    });
  }

  /**
   * Extract search terms from text
   */
  private extractSearchTerms(title: string, content: string): string[] {
    const combined = `${title} ${content}`.toLowerCase();
    
    // Split into words
    const words = combined
      .split(/[\s\-_.,;:!?()\[\]{}]+/)
      .filter(word => word.length > 2); // Filter short words

    // Add bigrams for better matching
    const bigrams: string[] = [];
    for (let i = 0; i < words.length - 1; i++) {
      bigrams.push(`${words[i]} ${words[i + 1]}`);
    }

    return [...new Set([...words, ...bigrams])];
  }

  /**
   * Perform deep search
   */
  async search(query: SearchQuery): Promise<SearchResult[]> {
    const startTime = Date.now();
    const queryText = query.query.toLowerCase();
    const queryTerms = queryText.split(/\s+/).filter(term => term.length > 2);

    // Find matching results
    const resultIds = new Set<string>();
    const resultScores = new Map<string, number>();

    queryTerms.forEach(term => {
      // Direct matches
      for (const [indexTerm, ids] of this.searchIndex.entries()) {
        if (indexTerm.includes(term) || term.includes(indexTerm)) {
          ids.forEach(id => {
            resultIds.add(id);
            resultScores.set(id, (resultScores.get(id) || 0) + 1);
          });
        }
      }

      // Partial matches
      for (const [indexTerm, ids] of this.searchIndex.entries()) {
        if (indexTerm.startsWith(term) || term.startsWith(indexTerm)) {
          ids.forEach(id => {
            resultIds.add(id);
            resultScores.set(id, (resultScores.get(id) || 0) + 0.5);
          });
        }
      }
    });

    // Get results
    let results = Array.from(resultIds)
      .map(id => this.results.get(id))
      .filter((result): result is SearchResult => result !== undefined);

    // Calculate relevance scores
    results = results.map(result => {
      const baseScore = resultScores.get(result.id) || 0;
      
      // Boost exact title matches
      const titleMatch = result.title.toLowerCase().includes(queryText);
      if (titleMatch) {
        result.relevance = Math.min(1.0, baseScore / queryTerms.length + 0.5);
      } else {
        result.relevance = Math.min(1.0, baseScore / queryTerms.length);
      }

      // Boost recent results
      if (result.timestamp) {
        const daysSince = (Date.now() - result.timestamp.getTime()) / (1000 * 60 * 60 * 24);
        result.relevance *= Math.max(0.5, 1 - daysSince / 30); // Decay over 30 days
      }

      return result;
    });

    // Apply filters
    if (query.filters) {
      if (query.filters.type && query.filters.type.length > 0) {
        results = results.filter(r => query.filters!.type!.includes(r.type));
      }

      if (query.filters.dateRange) {
        results = results.filter(r => {
          if (!r.timestamp) return false;
          return r.timestamp >= query.filters!.dateRange!.start &&
                 r.timestamp <= query.filters!.dateRange!.end;
        });
      }

      if (query.filters.tags && query.filters.tags.length > 0) {
        results = results.filter(r => {
          const resultTags = r.metadata.tags || [];
          return query.filters!.tags!.some(tag => resultTags.includes(tag));
        });
      }

      if (query.filters.category) {
        results = results.filter(r => r.metadata.category === query.filters!.category);
      }
    }

    // Sort results
    const sortBy = query.sortBy || 'relevance';
    results.sort((a, b) => {
      switch (sortBy) {
        case 'relevance':
          return b.relevance - a.relevance;
        case 'date':
          if (!a.timestamp || !b.timestamp) return 0;
          return b.timestamp.getTime() - a.timestamp.getTime();
        case 'name':
          return a.title.localeCompare(b.title);
        default:
          return b.relevance - a.relevance;
      }
    });

    // Limit results
    const limit = query.limit || 20;
    results = results.slice(0, limit);

    // Generate snippets
    results = results.map(result => ({
      ...result,
      snippet: this.generateSnippet(result.content, query.query),
    }));

    // Log search
    this.searchHistory.push({
      query: query.query,
      timestamp: new Date(),
      results: results.length,
    });

    // Keep only last 1000 searches
    if (this.searchHistory.length > 1000) {
      this.searchHistory = this.searchHistory.slice(-1000);
    }

    return results;
  }

  /**
   * Generate snippet from content
   */
  private generateSnippet(content: string, query: string, maxLength: number = 200): string {
    const lowerContent = content.toLowerCase();
    const lowerQuery = query.toLowerCase();
    
    // Find first occurrence of query
    const index = lowerContent.indexOf(lowerQuery);
    
    if (index === -1) {
      // No match, return beginning
      return content.substring(0, maxLength) + '...';
    }

    // Extract snippet around match
    const start = Math.max(0, index - 50);
    const end = Math.min(content.length, index + query.length + 50);
    let snippet = content.substring(start, end);

    if (start > 0) snippet = '...' + snippet;
    if (end < content.length) snippet = snippet + '...';

    // Highlight query in snippet (simplified)
    return snippet;
  }

  /**
   * Get search suggestions
   */
  getSearchSuggestions(query: string, limit: number = 5): string[] {
    const lowerQuery = query.toLowerCase();
    const suggestions = new Set<string>();

    // Get suggestions from search history
    this.searchHistory.forEach(history => {
      if (history.query.toLowerCase().startsWith(lowerQuery)) {
        suggestions.add(history.query);
      }
    });

    // Get suggestions from indexed terms
    this.searchIndex.forEach((_, term) => {
      if (term.startsWith(lowerQuery) && term.length > lowerQuery.length) {
        suggestions.add(term);
      }
    });

    return Array.from(suggestions).slice(0, limit);
  }

  /**
   * Get popular searches
   */
  getPopularSearches(limit: number = 10): Array<{ query: string; count: number }> {
    const queryCounts = new Map<string, number>();

    this.searchHistory.forEach(history => {
      queryCounts.set(history.query, (queryCounts.get(history.query) || 0) + 1);
    });

    return Array.from(queryCounts.entries())
      .map(([query, count]) => ({ query, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  /**
   * Clear search index
   */
  clearIndex(): void {
    this.searchIndex.clear();
    this.results.clear();
  }

  /**
   * Get search statistics
   */
  getSearchStatistics(): {
    totalSearches: number;
    indexedResults: number;
    indexedTerms: number;
    averageResultsPerQuery: number;
  } {
    const totalResults = this.searchHistory.reduce((sum, h) => sum + h.results, 0);
    const averageResults = this.searchHistory.length > 0
      ? totalResults / this.searchHistory.length
      : 0;

    return {
      totalSearches: this.searchHistory.length,
      indexedResults: this.results.size,
      indexedTerms: this.searchIndex.size,
      averageResultsPerQuery: averageResults,
    };
  }
}

// Singleton instance
export const deepSearchEngine = new DeepSearchEngine();

