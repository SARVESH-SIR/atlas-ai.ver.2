/**
 * ATLAS AI - Jarvis-Level Advanced Calendar & Meeting Management
 * Smart scheduling, conflict resolution, meeting preparation
 */

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  start: Date;
  end: Date;
  location?: string;
  attendees: string[];
  organizer: string;
  status: 'confirmed' | 'tentative' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  reminders: Array<{ minutes: number; sent: boolean }>;
  category: string;
  tags: string[];
  recurring?: {
    frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
    interval: number;
    endDate?: Date;
    daysOfWeek?: number[];
  };
}

export interface MeetingPreparation {
  eventId: string;
  agenda: string[];
  documents: string[];
  attendees: Array<{ name: string; role?: string; email?: string }>;
  location: { name: string; address?: string; virtual?: boolean };
  estimatedDuration: number;
  preparationTime: number; // minutes needed before meeting
}

export interface ScheduleConflict {
  event1: CalendarEvent;
  event2: CalendarEvent;
  overlap: { start: Date; end: Date };
  severity: 'low' | 'medium' | 'high';
  suggestion: string;
}

export class AdvancedCalendarSystem {
  private events: Map<string, CalendarEvent> = new Map();
  private meetings: Map<string, MeetingPreparation> = new Map();

  constructor() {
    this.initializeDefaultEvents();
  }

  /**
   * Initialize default calendar events (for demo)
   */
  private initializeDefaultEvents() {
    // Example events would be loaded from actual calendar
  }

  /**
   * Create calendar event
   */
  createEvent(event: Omit<CalendarEvent, 'id'>): CalendarEvent {
    const newEvent: CalendarEvent = {
      ...event,
      id: `event-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };

    // Check for conflicts
    const conflicts = this.detectConflicts(newEvent);
    if (conflicts.length > 0) {
      console.warn(`[Calendar] Conflicts detected for event: ${newEvent.title}`);
    }

    this.events.set(newEvent.id, newEvent);

    // Create meeting preparation if needed
    if (event.attendees.length > 0) {
      this.prepareMeeting(newEvent.id);
    }

    return newEvent;
  }

  /**
   * Detect scheduling conflicts
   */
  detectConflicts(event: CalendarEvent): ScheduleConflict[] {
    const conflicts: ScheduleConflict[] = [];

    for (const existingEvent of this.events.values()) {
      if (existingEvent.id === event.id || existingEvent.status === 'cancelled') {
        continue;
      }

      // Check time overlap
      const overlap = this.getTimeOverlap(event, existingEvent);
      if (overlap) {
        const severity = this.calculateConflictSeverity(event, existingEvent);
        const suggestion = this.generateConflictSuggestion(event, existingEvent, overlap);

        conflicts.push({
          event1: event,
          event2: existingEvent,
          overlap,
          severity,
          suggestion,
        });
      }
    }

    return conflicts;
  }

  /**
   * Get time overlap between events
   */
  private getTimeOverlap(event1: CalendarEvent, event2: CalendarEvent): { start: Date; end: Date } | null {
    const start = event1.start > event2.start ? event1.start : event2.start;
    const end = event1.end < event2.end ? event1.end : event2.end;

    if (start < end) {
      return { start, end };
    }

    return null;
  }

  /**
   * Calculate conflict severity
   */
  private calculateConflictSeverity(event1: CalendarEvent, event2: CalendarEvent): 'low' | 'medium' | 'high' {
    // Both urgent = high severity
    if (event1.priority === 'urgent' && event2.priority === 'urgent') {
      return 'high';
    }

    // One urgent = medium severity
    if (event1.priority === 'urgent' || event2.priority === 'urgent') {
      return 'medium';
    }

    // Both high priority = medium severity
    if (event1.priority === 'high' && event2.priority === 'high') {
      return 'medium';
    }

    return 'low';
  }

  /**
   * Generate conflict resolution suggestion
   */
  private generateConflictSuggestion(
    event1: CalendarEvent,
    event2: CalendarEvent,
    overlap: { start: Date; end: Date }
  ): string {
    const overlapMinutes = (overlap.end.getTime() - overlap.start.getTime()) / (1000 * 60);

    if (event1.priority === 'urgent' && event2.priority !== 'urgent') {
      return `Reschedule "${event2.title}" - "${event1.title}" is urgent`;
    }

    if (event2.priority === 'urgent' && event1.priority !== 'urgent') {
      return `Reschedule "${event1.title}" - "${event2.title}" is urgent`;
    }

    if (overlapMinutes < 15) {
      return `Minor overlap (${Math.floor(overlapMinutes)} min). Both events can proceed.`;
    }

    return `Significant overlap detected. Consider rescheduling one of the events.`;
  }

  /**
   * Prepare meeting
   */
  prepareMeeting(eventId: string): MeetingPreparation {
    const event = this.events.get(eventId);
    if (!event || event.attendees.length === 0) {
      throw new Error('Event not found or has no attendees');
    }

    const duration = (event.end.getTime() - event.start.getTime()) / (1000 * 60);

    const preparation: MeetingPreparation = {
      eventId,
      agenda: this.extractAgenda(event),
      documents: [],
      attendees: event.attendees.map(email => ({
        name: email.split('@')[0],
        email,
      })),
      location: {
        name: event.location || 'Virtual',
        virtual: !event.location || event.location.includes('zoom') || event.location.includes('meet'),
      },
      estimatedDuration: duration,
      preparationTime: Math.max(15, duration * 0.1), // 10% of meeting time, min 15 min
    };

    this.meetings.set(eventId, preparation);
    return preparation;
  }

  /**
   * Extract agenda from event
   */
  private extractAgenda(event: CalendarEvent): string[] {
    if (!event.description) return [];

    // Simple agenda extraction (would be more sophisticated in production)
    const lines = event.description.split('\n');
    const agenda: string[] = [];

    lines.forEach(line => {
      const trimmed = line.trim();
      if (trimmed.match(/^[-*]\s+.+/) || trimmed.match(/^\d+\.\s+.+/)) {
        agenda.push(trimmed.replace(/^[-*\d.]+\s+/, ''));
      }
    });

    return agenda.length > 0 ? agenda : [event.title];
  }

  /**
   * Find optimal meeting time
   */
  findOptimalMeetingTime(
    duration: number, // minutes
    attendees: string[],
    preferences?: {
      startDate?: Date;
      endDate?: Date;
      preferredTimes?: Array<{ start: string; end: string }>;
      avoidTimes?: Array<{ start: string; end: string }>;
    }
  ): Date | null {
    const startDate = preferences?.startDate || new Date();
    const endDate = preferences?.endDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    // Find available slots
    const availableSlots = this.findAvailableSlots(startDate, endDate, duration);

    if (availableSlots.length === 0) {
      return null;
    }

    // Prioritize preferred times
    if (preferences?.preferredTimes) {
      for (const preferred of preferences.preferredTimes) {
        const preferredStart = this.parseTimeString(preferred.start);
        if (preferredStart) {
          const slot = availableSlots.find(slot => {
            const slotHour = slot.getHours();
            const preferredHour = preferredStart.getHours();
            return Math.abs(slotHour - preferredHour) <= 1;
          });

          if (slot) return slot;
        }
      }
    }

    // Return first available slot
    return availableSlots[0];
  }

  /**
   * Find available time slots
   */
  private findAvailableSlots(startDate: Date, endDate: Date, duration: number): Date[] {
    const slots: Date[] = [];
    const current = new Date(startDate);

    while (current < endDate) {
      // Skip weekends (optional - could be configurable)
      const dayOfWeek = current.getDay();
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        current.setDate(current.getDate() + 1);
        continue;
      }

      // Check business hours (9 AM - 5 PM)
      current.setHours(9, 0, 0, 0);

      while (current.getHours() < 17) {
        const slotEnd = new Date(current.getTime() + duration * 60 * 1000);

        if (slotEnd.getHours() > 17) {
          break; // Slot extends beyond business hours
        }

        // Check if slot is available
        const conflictingEvents = Array.from(this.events.values()).filter(event => {
          if (event.status === 'cancelled') return false;
          return !(slotEnd <= event.start || current >= event.end);
        });

        if (conflictingEvents.length === 0) {
          slots.push(new Date(current));
        }

        // Move to next hour
        current.setHours(current.getHours() + 1);
      }

      // Move to next day
      current.setDate(current.getDate() + 1);
    }

    return slots;
  }

  /**
   * Parse time string (e.g., "09:00", "2 PM")
   */
  private parseTimeString(timeStr: string): Date | null {
    // Simplified parsing (would be more robust in production)
    const match = timeStr.match(/(\d{1,2}):?(\d{2})?\s*(AM|PM)?/i);
    if (!match) return null;

    const hour = parseInt(match[1]);
    const minute = match[2] ? parseInt(match[2]) : 0;
    const ampm = match[3]?.toUpperCase();

    let hour24 = hour;
    if (ampm === 'PM' && hour !== 12) hour24 += 12;
    if (ampm === 'AM' && hour === 12) hour24 = 0;

    const date = new Date();
    date.setHours(hour24, minute, 0, 0);
    return date;
  }

  /**
   * Get upcoming events
   */
  getUpcomingEvents(limit: number = 10): CalendarEvent[] {
    const now = new Date();
    const upcoming = Array.from(this.events.values())
      .filter(event => event.start >= now && event.status !== 'cancelled')
      .sort((a, b) => a.start.getTime() - b.start.getTime())
      .slice(0, limit);

    return upcoming;
  }

  /**
   * Get today's events
   */
  getTodayEvents(): CalendarEvent[] {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    return Array.from(this.events.values())
      .filter(event => {
        const eventStart = new Date(event.start);
        eventStart.setHours(0, 0, 0, 0);
        return eventStart >= today && eventStart < tomorrow && event.status !== 'cancelled';
      })
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  }

  /**
   * Get events by date range
   */
  getEventsByDateRange(start: Date, end: Date): CalendarEvent[] {
    return Array.from(this.events.values())
      .filter(event => {
        const eventStart = new Date(event.start);
        return eventStart >= start && eventStart <= end && event.status !== 'cancelled';
      })
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  }

  /**
   * Send meeting reminders
   */
  async sendMeetingReminders(minutesBefore: number = 15): Promise<{
    sent: number;
    errors: number;
  }> {
    const now = new Date();
    const reminderTime = new Date(now.getTime() + minutesBefore * 60 * 1000);

    let sent = 0;
    let errors = 0;

    for (const event of this.events.values()) {
      if (event.status === 'cancelled') continue;

      // Check if reminder should be sent
      const timeUntilEvent = event.start.getTime() - now.getTime();
      const reminderTimeMs = minutesBefore * 60 * 1000;

      if (timeUntilEvent > 0 && timeUntilEvent <= reminderTimeMs) {
        // Check if already sent
        const reminder = event.reminders.find(r => r.minutes === minutesBefore);
        if (reminder && reminder.sent) continue;

        try {
          // Send reminder (would integrate with notification system)
          console.log(`[Calendar] Sending reminder for: ${event.title}`);

          // Mark as sent
          if (reminder) {
            reminder.sent = true;
          } else {
            event.reminders.push({ minutes: minutesBefore, sent: true });
          }

          this.events.set(event.id, event);
          sent++;
        } catch (error) {
          errors++;
          console.error(`[Calendar] Error sending reminder for ${event.title}:`, error);
        }
      }
    }

    return { sent, errors };
  }

  /**
   * Get meeting preparation
   */
  getMeetingPreparation(eventId: string): MeetingPreparation | null {
    return this.meetings.get(eventId) || null;
  }

  /**
   * Update event
   */
  updateEvent(eventId: string, updates: Partial<CalendarEvent>): boolean {
    const event = this.events.get(eventId);
    if (!event) return false;

    const updatedEvent = { ...event, ...updates };
    
    // Re-check conflicts if time changed
    if (updates.start || updates.end) {
      const conflicts = this.detectConflicts(updatedEvent);
      if (conflicts.length > 0) {
        console.warn(`[Calendar] Conflicts detected after update: ${updatedEvent.title}`);
      }
    }

    this.events.set(eventId, updatedEvent);
    return true;
  }

  /**
   * Delete event
   */
  deleteEvent(eventId: string): boolean {
    this.events.delete(eventId);
    this.meetings.delete(eventId);
    return true;
  }

  /**
   * Get all events
   */
  getAllEvents(): CalendarEvent[] {
    return Array.from(this.events.values())
      .filter(event => event.status !== 'cancelled')
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  }
}

// Singleton instance
export const advancedCalendarSystem = new AdvancedCalendarSystem();

