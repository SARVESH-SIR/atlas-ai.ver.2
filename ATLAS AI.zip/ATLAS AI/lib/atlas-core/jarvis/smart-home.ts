/**
 * ATLAS AI - Jarvis-Level Smart Home Control
 * Intelligent home automation and device control
 */

export interface SmartDevice {
  id: string;
  name: string;
  type: 'light' | 'thermostat' | 'lock' | 'camera' | 'speaker' | 'tv' | 'sensor' | 'switch' | 'appliance';
  room: string;
  status: 'on' | 'off' | 'active' | 'inactive' | 'locked' | 'unlocked';
  state?: Record<string, any>;
  controllable: boolean;
  lastUpdated: Date;
}

export interface Room {
  id: string;
  name: string;
  devices: string[]; // Device IDs
}

export interface SmartScene {
  id: string;
  name: string;
  description: string;
  deviceStates: Record<string, Record<string, any>>;
  enabled: boolean;
}

export class SmartHomeController {
  private devices: Map<string, SmartDevice> = new Map();
  private rooms: Map<string, Room> = new Map();
  private scenes: Map<string, SmartScene> = new Map();
  private currentScene: string | null = null;

  constructor() {
    this.initializeDefaultSetup();
  }

  /**
   * Initialize default smart home setup
   */
  private initializeDefaultSetup() {
    // Default rooms
    const defaultRooms: Room[] = [
      { id: 'living-room', name: 'Living Room', devices: [] },
      { id: 'bedroom', name: 'Bedroom', devices: [] },
      { id: 'kitchen', name: 'Kitchen', devices: [] },
      { id: 'office', name: 'Office', devices: [] },
      { id: 'bathroom', name: 'Bathroom', devices: [] },
    ];

    defaultRooms.forEach(room => {
      this.rooms.set(room.id, room);
    });

    // Default devices (simulated)
    const defaultDevices: SmartDevice[] = [
      {
        id: 'light-living-main',
        name: 'Living Room Main Light',
        type: 'light',
        room: 'living-room',
        status: 'off',
        state: { brightness: 100, color: 'white' },
        controllable: true,
        lastUpdated: new Date(),
      },
      {
        id: 'light-bedroom',
        name: 'Bedroom Light',
        type: 'light',
        room: 'bedroom',
        status: 'off',
        state: { brightness: 80, color: 'warm-white' },
        controllable: true,
        lastUpdated: new Date(),
      },
      {
        id: 'thermostat-main',
        name: 'Main Thermostat',
        type: 'thermostat',
        room: 'living-room',
        status: 'active',
        state: { temperature: 22, mode: 'auto', targetTemp: 22 },
        controllable: true,
        lastUpdated: new Date(),
      },
      {
        id: 'lock-front-door',
        name: 'Front Door Lock',
        type: 'lock',
        room: 'living-room',
        status: 'locked',
        controllable: true,
        lastUpdated: new Date(),
      },
      {
        id: 'camera-front',
        name: 'Front Door Camera',
        type: 'camera',
        room: 'living-room',
        status: 'active',
        state: { recording: true, motionDetection: true },
        controllable: true,
        lastUpdated: new Date(),
      },
      {
        id: 'speaker-living',
        name: 'Living Room Speaker',
        type: 'speaker',
        room: 'living-room',
        status: 'inactive',
        state: { volume: 50, playing: false },
        controllable: true,
        lastUpdated: new Date(),
      },
      {
        id: 'tv-living',
        name: 'Living Room TV',
        type: 'tv',
        room: 'living-room',
        status: 'off',
        state: { channel: 1, volume: 30 },
        controllable: true,
        lastUpdated: new Date(),
      },
      {
        id: 'light-kitchen',
        name: 'Kitchen Light',
        type: 'light',
        room: 'kitchen',
        status: 'off',
        state: { brightness: 90, color: 'white' },
        controllable: true,
        lastUpdated: new Date(),
      },
    ];

    defaultDevices.forEach(device => {
      this.devices.set(device.id, device);
      const room = this.rooms.get(device.room);
      if (room) {
        room.devices.push(device.id);
      }
    });

    // Default scenes
    const defaultScenes: SmartScene[] = [
      {
        id: 'good-morning',
        name: 'Good Morning',
        description: 'Wake up routine: lights on, temperature adjust',
        deviceStates: {
          'light-living-main': { status: 'on', brightness: 60 },
          'light-bedroom': { status: 'on', brightness: 50 },
          'thermostat-main': { temperature: 22 },
        },
        enabled: true,
      },
      {
        id: 'movie-night',
        name: 'Movie Night',
        description: 'Dim lights, turn on TV, adjust speakers',
        deviceStates: {
          'light-living-main': { status: 'on', brightness: 20 },
          'tv-living': { status: 'on', volume: 40 },
          'speaker-living': { status: 'active', volume: 35 },
        },
        enabled: true,
      },
      {
        id: 'good-night',
        name: 'Good Night',
        description: 'Turn off lights, lock doors, set security',
        deviceStates: {
          'light-living-main': { status: 'off' },
          'light-bedroom': { status: 'off' },
          'light-kitchen': { status: 'off' },
          'lock-front-door': { status: 'locked' },
          'tv-living': { status: 'off' },
        },
        enabled: true,
      },
      {
        id: 'away',
        name: 'Away',
        description: 'Security mode: lock everything, enable cameras',
        deviceStates: {
          'light-living-main': { status: 'off' },
          'light-bedroom': { status: 'off' },
          'light-kitchen': { status: 'off' },
          'lock-front-door': { status: 'locked' },
          'camera-front': { status: 'active', motionDetection: true },
        },
        enabled: true,
      },
    ];

    defaultScenes.forEach(scene => {
      this.scenes.set(scene.id, scene);
    });
  }

  /**
   * Control device
   */
  async controlDevice(
    deviceId: string,
    action: string,
    parameters?: Record<string, any>
  ): Promise<{ success: boolean; message: string }> {
    const device = this.devices.get(deviceId);
    if (!device) {
      return { success: false, message: `Device "${deviceId}" not found` };
    }

    if (!device.controllable) {
      return { success: false, message: `Device "${device.name}" is not controllable` };
    }

    try {
      switch (action) {
        case 'turn_on':
          if (device.type === 'light') {
            device.status = 'on';
            if (parameters?.brightness) {
              device.state = { ...device.state, brightness: parameters.brightness };
            }
          } else if (device.type === 'tv' || device.type === 'speaker') {
            device.status = 'on';
          } else if (device.type === 'switch') {
            device.status = 'on';
          }
          break;

        case 'turn_off':
          if (['light', 'tv', 'speaker', 'switch'].includes(device.type)) {
            device.status = 'off';
          }
          break;

        case 'set_brightness':
          if (device.type === 'light' && device.state) {
            device.state.brightness = parameters?.value || 100;
          }
          break;

        case 'set_temperature':
          if (device.type === 'thermostat' && device.state) {
            device.state.targetTemp = parameters?.temperature || 22;
            device.state.temperature = parameters?.temperature || 22;
          }
          break;

        case 'lock':
          if (device.type === 'lock') {
            device.status = 'locked';
          }
          break;

        case 'unlock':
          if (device.type === 'lock') {
            device.status = 'unlocked';
          }
          break;

        case 'set_volume':
          if ((device.type === 'speaker' || device.type === 'tv') && device.state) {
            device.state.volume = parameters?.volume || 50;
          }
          break;

        default:
          return { success: false, message: `Unknown action: ${action}` };
      }

      device.lastUpdated = new Date();
      this.devices.set(deviceId, device);

      return {
        success: true,
        message: `${device.name} ${action.replace('_', ' ')} successfully`,
      };
    } catch (error: any) {
      return { success: false, message: `Error controlling device: ${error.message}` };
    }
  }

  /**
   * Activate scene
   */
  async activateScene(sceneId: string): Promise<{ success: boolean; message: string }> {
    const scene = this.scenes.get(sceneId);
    if (!scene) {
      return { success: false, message: `Scene "${sceneId}" not found` };
    }

    if (!scene.enabled) {
      return { success: false, message: `Scene "${scene.name}" is disabled` };
    }

    try {
      for (const [deviceId, state] of Object.entries(scene.deviceStates)) {
        const device = this.devices.get(deviceId);
        if (!device) continue;

        // Apply state changes
        if (state.status) {
          if (state.status === 'on') {
            await this.controlDevice(deviceId, 'turn_on', state);
          } else if (state.status === 'off') {
            await this.controlDevice(deviceId, 'turn_off');
          }
        }

        if (state.brightness && device.type === 'light') {
          await this.controlDevice(deviceId, 'set_brightness', { value: state.brightness });
        }

        if (state.temperature && device.type === 'thermostat') {
          await this.controlDevice(deviceId, 'set_temperature', { temperature: state.temperature });
        }

        if (state.volume && (device.type === 'speaker' || device.type === 'tv')) {
          await this.controlDevice(deviceId, 'set_volume', { volume: state.volume });
        }
      }

      this.currentScene = sceneId;

      return {
        success: true,
        message: `Scene "${scene.name}" activated successfully`,
      };
    } catch (error: any) {
      return { success: false, message: `Error activating scene: ${error.message}` };
    }
  }

  /**
   * Control room
   */
  async controlRoom(
    roomId: string,
    action: string,
    parameters?: Record<string, any>
  ): Promise<{ success: boolean; message: string; devicesAffected: number }> {
    const room = this.rooms.get(roomId);
    if (!room) {
      return { success: false, message: `Room "${roomId}" not found`, devicesAffected: 0 };
    }

    let devicesAffected = 0;

    for (const deviceId of room.devices) {
      const device = this.devices.get(deviceId);
      if (!device) continue;

      if (action === 'turn_on_lights') {
        if (device.type === 'light') {
          await this.controlDevice(deviceId, 'turn_on', parameters);
          devicesAffected++;
        }
      } else if (action === 'turn_off_lights') {
        if (device.type === 'light') {
          await this.controlDevice(deviceId, 'turn_off');
          devicesAffected++;
        }
      } else if (action === 'turn_off_all') {
        if (['light', 'tv', 'speaker'].includes(device.type)) {
          await this.controlDevice(deviceId, 'turn_off');
          devicesAffected++;
        }
      }
    }

    return {
      success: true,
      message: `${action} completed for ${room.name}`,
      devicesAffected,
    };
  }

  /**
   * Get all devices
   */
  getAllDevices(): SmartDevice[] {
    return Array.from(this.devices.values());
  }

  /**
   * Get devices by room
   */
  getDevicesByRoom(roomId: string): SmartDevice[] {
    const room = this.rooms.get(roomId);
    if (!room) return [];

    return room.devices
      .map(deviceId => this.devices.get(deviceId))
      .filter((device): device is SmartDevice => device !== undefined);
  }

  /**
   * Get all rooms
   */
  getAllRooms(): Room[] {
    return Array.from(this.rooms.values());
  }

  /**
   * Get all scenes
   */
  getAllScenes(): SmartScene[] {
    return Array.from(this.scenes.values());
  }

  /**
   * Create new scene
   */
  createScene(scene: Omit<SmartScene, 'id'>): SmartScene {
    const newScene: SmartScene = {
      ...scene,
      id: `scene-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };

    this.scenes.set(newScene.id, newScene);
    return newScene;
  }

  /**
   * Parse voice command for smart home
   */
  parseVoiceCommand(command: string): {
    action: string;
    target?: string;
    parameters?: Record<string, any>;
  } | null {
    const lowerCommand = command.toLowerCase();

    // Light controls
    if (lowerCommand.match(/turn\s+on\s+(?:the\s+)?lights?/)) {
      return { action: 'turn_on_lights', target: 'room' };
    }
    if (lowerCommand.match(/turn\s+off\s+(?:the\s+)?lights?/)) {
      return { action: 'turn_off_lights', target: 'room' };
    }
    if (lowerCommand.match(/dim\s+(?:the\s+)?lights?/)) {
      return { action: 'dim_lights', parameters: { brightness: 30 } };
    }

    // Scene activation
    if (lowerCommand.includes('good morning') || lowerCommand.includes('morning scene')) {
      return { action: 'activate_scene', target: 'good-morning' };
    }
    if (lowerCommand.includes('movie night') || lowerCommand.includes('movie scene')) {
      return { action: 'activate_scene', target: 'movie-night' };
    }
    if (lowerCommand.includes('good night') || lowerCommand.includes('night scene')) {
      return { action: 'activate_scene', target: 'good-night' };
    }
    if (lowerCommand.includes('away') || lowerCommand.includes('away scene')) {
      return { action: 'activate_scene', target: 'away' };
    }

    // Temperature
    if (lowerCommand.match(/set\s+temperature\s+to\s+(\d+)/)) {
      const match = lowerCommand.match(/set\s+temperature\s+to\s+(\d+)/);
      const temp = match ? parseInt(match[1]) : 22;
      return { action: 'set_temperature', parameters: { temperature: temp } };
    }

    return null;
  }

  /**
   * Get device status summary
   */
  getStatusSummary(): {
    totalDevices: number;
    activeDevices: number;
    rooms: number;
    scenes: number;
    currentScene: string | null;
  } {
    const allDevices = this.getAllDevices();
    const activeDevices = allDevices.filter(
      d => d.status === 'on' || d.status === 'active'
    ).length;

    return {
      totalDevices: allDevices.length,
      activeDevices,
      rooms: this.rooms.size,
      scenes: this.scenes.size,
      currentScene: this.currentScene,
    };
  }
}

// Singleton instance
export const smartHomeController = new SmartHomeController();

