/**
 * ATLAS AI - Jarvis-Level Advanced Voice Interaction
 * Natural conversations, emotion detection, voice cloning, multi-language
 */

export interface VoiceProfile {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'neutral';
  accent: string;
  language: string;
  voiceId?: string;
  settings: {
    pitch: number;
    rate: number;
    volume: number;
    emotion: 'neutral' | 'happy' | 'sad' | 'excited' | 'calm' | 'formal';
  };
}

export interface EmotionState {
  detected: 'happy' | 'sad' | 'neutral' | 'excited' | 'frustrated' | 'calm';
  confidence: number;
  context: string;
  suggestedResponse: string;
}

export interface ConversationContext {
  topic: string;
  intent: string;
  entities: Record<string, any>;
  history: Array<{ role: 'user' | 'assistant'; message: string; timestamp: Date }>;
  sentiment: 'positive' | 'negative' | 'neutral';
}

export class AdvancedVoiceSystem {
  private voiceProfiles: Map<string, VoiceProfile> = new Map();
  private activeProfile: string = 'default';
  private conversationContexts: Map<string, ConversationContext> = new Map();
  private emotionHistory: Array<{ timestamp: Date; emotion: EmotionState }> = [];

  constructor() {
    this.initializeDefaultProfiles();
  }

  /**
   * Initialize default voice profiles
   */
  private initializeDefaultProfiles() {
    const defaultProfiles: VoiceProfile[] = [
      {
        id: 'jarvis-male',
        name: 'Jarvis (Male)',
        gender: 'male',
        accent: 'british',
        language: 'en-US',
        settings: {
          pitch: 0.0,
          rate: 1.0,
          volume: 1.0,
          emotion: 'calm',
        },
      },
      {
        id: 'jarvis-female',
        name: 'Friday (Female)',
        gender: 'female',
        accent: 'american',
        language: 'en-US',
        settings: {
          pitch: 0.3,
          rate: 1.0,
          volume: 1.0,
          emotion: 'calm',
        },
      },
      {
        id: 'chitti',
        name: 'Chitti (Indian)',
        gender: 'male',
        accent: 'indian',
        language: 'en-IN',
        settings: {
          pitch: 0.0,
          rate: 1.1,
          volume: 1.0,
          emotion: 'excited',
        },
      },
      {
        id: 'default',
        name: 'ATLAS Default',
        gender: 'neutral',
        accent: 'neutral',
        language: 'en-US',
        settings: {
          pitch: 0.0,
          rate: 1.0,
          volume: 1.0,
          emotion: 'neutral',
        },
      },
    ];

    defaultProfiles.forEach(profile => {
      this.voiceProfiles.set(profile.id, profile);
    });
  }

  /**
   * Detect emotion from text/voice
   */
  detectEmotion(text: string, context?: string): EmotionState {
    const lowerText = text.toLowerCase();

    // Emotion detection keywords
    const emotionKeywords = {
      happy: ['happy', 'great', 'awesome', 'excellent', 'wonderful', 'amazing', 'love', 'thanks', 'thank you'],
      sad: ['sad', 'unhappy', 'disappointed', 'sorry', 'bad', 'terrible', 'worried', 'anxious'],
      excited: ['excited', 'wow', 'fantastic', 'incredible', 'super', 'brilliant', 'yes!', 'great!'],
      frustrated: ['frustrated', 'angry', 'annoyed', 'hate', 'can\'t', 'won\'t', 'not working', 'broken'],
      calm: ['ok', 'fine', 'good', 'alright', 'sure', 'calm', 'peaceful'],
    };

    let detectedEmotion: EmotionState['detected'] = 'neutral';
    let maxMatches = 0;

    for (const [emotion, keywords] of Object.entries(emotionKeywords)) {
      const matches = keywords.filter(keyword => lowerText.includes(keyword)).length;
      if (matches > maxMatches) {
        maxMatches = matches;
        detectedEmotion = emotion as EmotionState['detected'];
      }
    }

    const confidence = Math.min(0.95, 0.5 + (maxMatches * 0.15));

    // Generate suggested response based on emotion
    let suggestedResponse = '';
    switch (detectedEmotion) {
      case 'happy':
        suggestedResponse = 'I\'m glad to hear that! How can I help you further?';
        break;
      case 'sad':
        suggestedResponse = 'I understand. Is there anything I can do to help?';
        break;
      case 'excited':
        suggestedResponse = 'That\'s wonderful! Let\'s make it happen.';
        break;
      case 'frustrated':
        suggestedResponse = 'I understand your frustration. Let me help you resolve this.';
        break;
      default:
        suggestedResponse = 'I\'m here to help. What would you like to do?';
    }

    const emotionState: EmotionState = {
      detected: detectedEmotion,
      confidence,
      context: context || text,
      suggestedResponse,
    };

    // Store in history
    this.emotionHistory.push({ timestamp: new Date(), emotion: emotionState });

    // Keep only last 100 emotions
    if (this.emotionHistory.length > 100) {
      this.emotionHistory = this.emotionHistory.slice(-100);
    }

    return emotionState;
  }

  /**
   * Get voice profile
   */
  getVoiceProfile(id?: string): VoiceProfile {
    const profileId = id || this.activeProfile;
    const profile = this.voiceProfiles.get(profileId);
    return profile || this.voiceProfiles.get('default')!;
  }

  /**
   * Set active voice profile
   */
  setActiveVoiceProfile(id: string): boolean {
    if (this.voiceProfiles.has(id)) {
      this.activeProfile = id;
      return true;
    }
    return false;
  }

  /**
   * Get all voice profiles
   */
  getAllVoiceProfiles(): VoiceProfile[] {
    return Array.from(this.voiceProfiles.values());
  }

  /**
   * Update conversation context
   */
  updateConversationContext(sessionId: string, userMessage: string, assistantMessage?: string): ConversationContext {
    let context = this.conversationContexts.get(sessionId);

    if (!context) {
      context = {
        topic: '',
        intent: '',
        entities: {},
        history: [],
        sentiment: 'neutral',
      };
    }

    // Add to history
    context.history.push({
      role: 'user',
      message: userMessage,
      timestamp: new Date(),
    });

    if (assistantMessage) {
      context.history.push({
        role: 'assistant',
        message: assistantMessage,
        timestamp: new Date(),
      });
    }

    // Detect sentiment
    const emotion = this.detectEmotion(userMessage);
    context.sentiment = ['happy', 'excited'].includes(emotion.detected) ? 'positive' :
                       ['sad', 'frustrated'].includes(emotion.detected) ? 'negative' : 'neutral';

    // Extract topic (simplified)
    const words = userMessage.toLowerCase().split(/\s+/);
    const topicKeywords = ['weather', 'calendar', 'email', 'meeting', 'task', 'reminder', 'home', 'app'];
    const topic = topicKeywords.find(keyword => words.includes(keyword)) || '';
    if (topic) context.topic = topic;

    // Keep only last 20 messages in history
    if (context.history.length > 20) {
      context.history = context.history.slice(-20);
    }

    this.conversationContexts.set(sessionId, context);
    return context;
  }

  /**
   * Get conversation context
   */
  getConversationContext(sessionId: string): ConversationContext | null {
    return this.conversationContexts.get(sessionId) || null;
  }

  /**
   * Generate natural response with emotion
   */
  generateNaturalResponse(
    userMessage: string,
    baseResponse: string,
    emotion?: EmotionState
  ): string {
    if (!emotion) {
      emotion = this.detectEmotion(userMessage);
    }

    // Adjust response based on emotion
    let response = baseResponse;

    if (emotion.detected === 'frustrated') {
      response = `I understand this is frustrating. ${response} Let me help you resolve this step by step.`;
    } else if (emotion.detected === 'excited') {
      response = `That's exciting! ${response} Let's make it happen!`;
    } else if (emotion.detected === 'sad') {
      response = `I'm sorry to hear that. ${response} Is there anything else I can help with?`;
    }

    // Get active profile for voice settings
    const profile = this.getVoiceProfile();
    
    // Adjust based on emotion setting
    if (profile.settings.emotion !== 'neutral') {
      // Could add emotion-based text variations here
    }

    return response;
  }

  /**
   * Get voice settings for TTS
   */
  getVoiceSettings(): {
    voice: string;
    pitch: number;
    rate: number;
    volume: number;
    lang: string;
  } {
    const profile = this.getVoiceProfile();
    
    // Map profile to voice settings
    const voiceMap: Record<string, string> = {
      'jarvis-male': 'en-GB-Standard-B',
      'jarvis-female': 'en-US-Standard-F',
      'chitti': 'en-IN-Standard-D',
      'default': 'en-US-Standard-D',
    };

    return {
      voice: voiceMap[profile.id] || voiceMap['default'],
      pitch: profile.settings.pitch,
      rate: profile.settings.rate,
      volume: profile.settings.volume,
      lang: profile.language,
    };
  }

  /**
   * Analyze conversation sentiment
   */
  analyzeConversationSentiment(sessionId: string): {
    overall: 'positive' | 'negative' | 'neutral';
    trend: 'improving' | 'declining' | 'stable';
    emotions: Array<{ emotion: string; count: number }>;
  } {
    const context = this.conversationContexts.get(sessionId);
    if (!context) {
      return {
        overall: 'neutral',
        trend: 'stable',
        emotions: [],
      };
    }

    // Analyze recent emotions
    const recentEmotions = this.emotionHistory
      .slice(-10)
      .map(e => e.emotion.detected);

    const emotionCounts: Record<string, number> = {};
    recentEmotions.forEach(emotion => {
      emotionCounts[emotion] = (emotionCounts[emotion] || 0) + 1;
    });

    const emotions = Object.entries(emotionCounts).map(([emotion, count]) => ({
      emotion,
      count,
    }));

    // Determine overall sentiment
    const positiveCount = (emotionCounts['happy'] || 0) + (emotionCounts['excited'] || 0);
    const negativeCount = (emotionCounts['sad'] || 0) + (emotionCounts['frustrated'] || 0);
    
    let overall: 'positive' | 'negative' | 'neutral' = 'neutral';
    if (positiveCount > negativeCount) overall = 'positive';
    else if (negativeCount > positiveCount) overall = 'negative';

    // Determine trend (simplified)
    const trend: 'improving' | 'declining' | 'stable' = 'stable';
    // Could analyze emotion changes over time here

    return { overall, trend, emotions };
  }

  /**
   * Create custom voice profile
   */
  createVoiceProfile(profile: Omit<VoiceProfile, 'id'>): VoiceProfile {
    const newProfile: VoiceProfile = {
      ...profile,
      id: `voice-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };

    this.voiceProfiles.set(newProfile.id, newProfile);
    return newProfile;
  }

  /**
   * Update voice profile settings
   */
  updateVoiceProfile(id: string, settings: Partial<VoiceProfile['settings']>): boolean {
    const profile = this.voiceProfiles.get(id);
    if (!profile) return false;

    profile.settings = { ...profile.settings, ...settings };
    this.voiceProfiles.set(id, profile);
    return true;
  }

  /**
   * Get emotion history
   */
  getEmotionHistory(limit: number = 20): typeof this.emotionHistory {
    return this.emotionHistory.slice(-limit);
  }
}

// Singleton instance
export const advancedVoiceSystem = new AdvancedVoiceSystem();

