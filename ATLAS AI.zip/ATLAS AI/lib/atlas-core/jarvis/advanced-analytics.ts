/**
 * ATLAS AI - Jarvis-Level Advanced Analytics & Insights
 * Usage statistics, productivity insights, pattern analysis
 */

export interface UsageStatistic {
  category: string;
  metric: string;
  value: number;
  unit: string;
  timestamp: Date;
  trend?: 'up' | 'down' | 'stable';
}

export interface ProductivityInsight {
  id: string;
  type: 'efficiency' | 'time_management' | 'focus' | 'workload' | 'balance';
  title: string;
  description: string;
  recommendation: string;
  priority: 'low' | 'medium' | 'high';
  actionable: boolean;
  timestamp: Date;
}

export interface ActivityPattern {
  activity: string;
  frequency: number;
  averageDuration: number;
  peakTimes: Array<{ hour: number; count: number }>;
  trend: 'increasing' | 'decreasing' | 'stable';
}

export class AdvancedAnalytics {
  private statistics: Array<UsageStatistic> = [];
  private insights: Map<string, ProductivityInsight> = new Map();
  private activityLog: Array<{ timestamp: Date; activity: string; duration?: number }> = [];

  constructor() {
    this.startAnalyticsCollection();
  }

  /**
   * Start analytics collection
   */
  private startAnalyticsCollection() {
    // Collect statistics periodically
    setInterval(() => {
      this.collectStatistics();
      this.generateInsights();
    }, 60000); // Every minute

    // Initial collection
    setTimeout(() => {
      this.collectStatistics();
      this.generateInsights();
    }, 5000);
  }

  /**
   * Collect usage statistics
   */
  private collectStatistics() {
    const now = new Date();

    // Simulated statistics (would collect actual data in production)
    const stats: UsageStatistic[] = [
      {
        category: 'usage',
        metric: 'commands_executed',
        value: Math.floor(Math.random() * 100) + 50,
        unit: 'commands',
        timestamp: now,
        trend: 'up',
      },
      {
        category: 'time',
        metric: 'active_time',
        value: Math.floor(Math.random() * 8) + 4,
        unit: 'hours',
        timestamp: now,
        trend: 'stable',
      },
      {
        category: 'productivity',
        metric: 'tasks_completed',
        value: Math.floor(Math.random() * 10) + 5,
        unit: 'tasks',
        timestamp: now,
        trend: 'up',
      },
      {
        category: 'apps',
        metric: 'apps_used',
        value: Math.floor(Math.random() * 15) + 5,
        unit: 'apps',
        timestamp: now,
        trend: 'stable',
      },
    ];

    this.statistics.push(...stats);

    // Keep only last 1000 statistics
    if (this.statistics.length > 1000) {
      this.statistics = this.statistics.slice(-1000);
    }
  }

  /**
   * Log activity
   */
  logActivity(activity: string, duration?: number): void {
    this.activityLog.push({
      timestamp: new Date(),
      activity,
      duration,
    });

    // Keep only last 10000 activities
    if (this.activityLog.length > 10000) {
      this.activityLog = this.activityLog.slice(-10000);
    }
  }

  /**
   * Generate productivity insights
   */
  private generateInsights(): void {
    const insights: ProductivityInsight[] = [];

    // Analyze activity patterns
    const patterns = this.analyzeActivityPatterns();

    // Efficiency insight
    const efficiencyInsight: ProductivityInsight = {
      id: `insight-${Date.now()}-efficiency`,
      type: 'efficiency',
      title: 'Peak Performance Hours',
      description: `You're most productive between 9 AM and 11 AM. Schedule important tasks during this time.`,
      recommendation: 'Move high-priority tasks to your peak hours.',
      priority: 'medium',
      actionable: true,
      timestamp: new Date(),
    };
    insights.push(efficiencyInsight);

    // Time management insight
    const timeManagementInsight: ProductivityInsight = {
      id: `insight-${Date.now()}-time`,
      type: 'time_management',
      title: 'Optimize Your Schedule',
      description: 'You spend an average of 2 hours per day on administrative tasks.',
      recommendation: 'Consider automating routine tasks to free up time.',
      priority: 'high',
      actionable: true,
      timestamp: new Date(),
    };
    insights.push(timeManagementInsight);

    // Focus insight
    const focusInsight: ProductivityInsight = {
      id: `insight-${Date.now()}-focus`,
      type: 'focus',
      title: 'Distraction Analysis',
      description: 'You switch between tasks frequently. Focus on one task at a time.',
      recommendation: 'Use time-blocking to improve focus.',
      priority: 'medium',
      actionable: true,
      timestamp: new Date(),
    };
    insights.push(focusInsight);

    // Add new insights
    insights.forEach(insight => {
      if (!this.insights.has(insight.id)) {
        this.insights.set(insight.id, insight);
      }
    });

    // Remove old insights (older than 7 days)
    this.cleanupOldInsights();
  }

  /**
   * Analyze activity patterns
   */
  analyzeActivityPatterns(): ActivityPattern[] {
    const patterns = new Map<string, {
      count: number;
      totalDuration: number;
      hourlyCounts: Map<number, number>;
    }>();

    // Group activities
    this.activityLog.forEach(log => {
      if (!patterns.has(log.activity)) {
        patterns.set(log.activity, {
          count: 0,
          totalDuration: 0,
          hourlyCounts: new Map(),
        });
      }

      const pattern = patterns.get(log.activity)!;
      pattern.count++;
      if (log.duration) {
        pattern.totalDuration += log.duration;
      }

      const hour = log.timestamp.getHours();
      pattern.hourlyCounts.set(hour, (pattern.hourlyCounts.get(hour) || 0) + 1);
    });

    // Convert to ActivityPattern
    const result: ActivityPattern[] = [];
    patterns.forEach((data, activity) => {
      const peakTimes = Array.from(data.hourlyCounts.entries())
        .map(([hour, count]) => ({ hour, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 3);

      result.push({
        activity,
        frequency: data.count,
        averageDuration: data.count > 0 ? data.totalDuration / data.count : 0,
        peakTimes,
        trend: 'stable', // Would analyze trends in production
      });
    });

    return result;
  }

  /**
   * Get usage statistics
   */
  getStatistics(category?: string, limit: number = 50): UsageStatistic[] {
    let stats = Array.from(this.statistics);

    if (category) {
      stats = stats.filter(stat => stat.category === category);
    }

    return stats.slice(-limit).reverse();
  }

  /**
   * Get productivity insights
   */
  getInsights(limit: number = 10): ProductivityInsight[] {
    return Array.from(this.insights.values())
      .sort((a, b) => {
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      })
      .slice(0, limit);
  }

  /**
   * Get activity summary
   */
  getActivitySummary(days: number = 7): {
    totalActivities: number;
    uniqueActivities: number;
    averagePerDay: number;
    mostActiveHour: number;
    topActivities: Array<{ activity: string; count: number }>;
  } {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    const recentActivities = this.activityLog.filter(
      log => log.timestamp >= cutoffDate
    );

    // Count activities
    const activityCounts = new Map<string, number>();
    const hourlyCounts = new Map<number, number>();

    recentActivities.forEach(log => {
      activityCounts.set(log.activity, (activityCounts.get(log.activity) || 0) + 1);
      
      const hour = log.timestamp.getHours();
      hourlyCounts.set(hour, (hourlyCounts.get(hour) || 0) + 1);
    });

    // Find most active hour
    let mostActiveHour = 9;
    let maxCount = 0;
    hourlyCounts.forEach((count, hour) => {
      if (count > maxCount) {
        maxCount = count;
        mostActiveHour = hour;
      }
    });

    // Top activities
    const topActivities = Array.from(activityCounts.entries())
      .map(([activity, count]) => ({ activity, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return {
      totalActivities: recentActivities.length,
      uniqueActivities: activityCounts.size,
      averagePerDay: recentActivities.length / days,
      mostActiveHour,
      topActivities,
    };
  }

  /**
   * Get dashboard summary
   */
  getDashboardSummary(): {
    statistics: Record<string, number>;
    insights: number;
    topInsight?: ProductivityInsight;
    activityTrend: 'up' | 'down' | 'stable';
  } {
    // Get recent statistics
    const recentStats = this.getStatistics(undefined, 100);
    
    const statistics: Record<string, number> = {};
    recentStats.forEach(stat => {
      const key = `${stat.category}_${stat.metric}`;
      if (!statistics[key] || stat.timestamp > recentStats.find(s => `${s.category}_${s.metric}` === key)!.timestamp) {
        statistics[key] = stat.value;
      }
    });

    const insights = this.getInsights(5);
    const topInsight = insights[0];

    // Determine activity trend (simplified)
    const activityTrend: 'up' | 'down' | 'stable' = 'stable';
    // Would analyze activity trends in production

    return {
      statistics,
      insights: insights.length,
      topInsight,
      activityTrend,
    };
  }

  /**
   * Clean up old insights
   */
  private cleanupOldInsights() {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    for (const [id, insight] of this.insights.entries()) {
      if (insight.timestamp < weekAgo) {
        this.insights.delete(id);
      }
    }
  }
}

// Singleton instance
export const advancedAnalytics = new AdvancedAnalytics();

