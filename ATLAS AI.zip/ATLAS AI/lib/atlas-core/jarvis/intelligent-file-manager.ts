/**
 * ATLAS AI - Jarvis-Level Intelligent File Management
 * Smart organization, search, cleanup, analysis
 */

export interface FileItem {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  size: number; // in bytes
  extension?: string;
  mimeType?: string;
  created: Date;
  modified: Date;
  tags: string[];
  category: string;
  importance: 'low' | 'medium' | 'high' | 'critical';
  accessed: Date;
}

export interface OrganizationRule {
  id: string;
  name: string;
  condition: {
    type: 'extension' | 'name' | 'size' | 'date' | 'pattern';
    pattern: string;
    operator: 'equals' | 'contains' | 'matches' | 'greater_than' | 'less_than';
    value: any;
  };
  action: {
    type: 'move' | 'tag' | 'delete' | 'archive' | 'compress';
    target: string;
  };
  enabled: boolean;
}

export interface FileAnalysis {
  totalFiles: number;
  totalSize: number;
  byType: Record<string, { count: number; size: number }>;
  byCategory: Record<string, { count: number; size: number }>;
  duplicates: Array<{ files: string[]; size: number }>;
  largeFiles: Array<{ name: string; path: string; size: number }>;
  oldFiles: Array<{ name: string; path: string; age: number }>;
}

export class IntelligentFileManager {
  private files: Map<string, FileItem> = new Map();
  private organizationRules: Map<string, OrganizationRule> = new Map();
  private searchIndex: Map<string, Set<string>> = new Map(); // term -> fileIds

  constructor() {
    this.initializeDefaultRules();
  }

  /**
   * Initialize default organization rules
   */
  private initializeDefaultRules() {
    const defaultRules: OrganizationRule[] = [
      {
        id: 'organize-documents',
        name: 'Organize Documents',
        condition: {
          type: 'extension',
          pattern: 'pdf|doc|docx|txt|rtf',
          operator: 'matches',
          value: true,
        },
        action: {
          type: 'move',
          target: 'Documents',
        },
        enabled: true,
      },
      {
        id: 'organize-images',
        name: 'Organize Images',
        condition: {
          type: 'extension',
          pattern: 'jpg|jpeg|png|gif|bmp|svg|webp',
          operator: 'matches',
          value: true,
        },
        action: {
          type: 'move',
          target: 'Pictures',
        },
        enabled: true,
      },
      {
        id: 'organize-videos',
        name: 'Organize Videos',
        condition: {
          type: 'extension',
          pattern: 'mp4|avi|mov|mkv|wmv|flv|webm',
          operator: 'matches',
          value: true,
        },
        action: {
          type: 'move',
          target: 'Videos',
        },
        enabled: true,
      },
      {
        id: 'organize-audio',
        name: 'Organize Audio',
        condition: {
          type: 'extension',
          pattern: 'mp3|wav|flac|aac|ogg|m4a',
          operator: 'matches',
          value: true,
        },
        action: {
          type: 'move',
          target: 'Music',
        },
        enabled: true,
      },
      {
        id: 'tag-important',
        name: 'Tag Important Files',
        condition: {
          type: 'name',
          pattern: 'important|urgent|critical|confidential',
          operator: 'contains',
          value: true,
        },
        action: {
          type: 'tag',
          target: 'important',
        },
        enabled: true,
      },
    ];

    defaultRules.forEach(rule => {
      this.organizationRules.set(rule.id, rule);
    });
  }

  /**
   * Add file to index
   */
  indexFile(file: FileItem): void {
    this.files.set(file.id, file);

    // Update search index
    const terms = this.extractSearchTerms(file);
    terms.forEach(term => {
      if (!this.searchIndex.has(term)) {
        this.searchIndex.set(term, new Set());
      }
      this.searchIndex.get(term)!.add(file.id);
    });
  }

  /**
   * Extract search terms from file
   */
  private extractSearchTerms(file: FileItem): string[] {
    const terms: string[] = [];

    // Add file name words
    const nameWords = file.name.toLowerCase().split(/[\s\-_\.]+/);
    terms.push(...nameWords);

    // Add extension
    if (file.extension) {
      terms.push(file.extension.toLowerCase());
    }

    // Add tags
    file.tags.forEach(tag => {
      terms.push(tag.toLowerCase());
    });

    // Add category
    terms.push(file.category.toLowerCase());

    return terms.filter(term => term.length > 2); // Filter short terms
  }

  /**
   * Search files
   */
  searchFiles(query: string, options?: {
    type?: 'file' | 'folder' | 'all';
    category?: string;
    tags?: string[];
    minSize?: number;
    maxSize?: number;
  }): FileItem[] {
    const lowerQuery = query.toLowerCase();
    const queryTerms = lowerQuery.split(/\s+/).filter(term => term.length > 2);

    const matchingFileIds = new Set<string>();

    // Find files matching query terms
    queryTerms.forEach(term => {
      for (const [indexTerm, fileIds] of this.searchIndex.entries()) {
        if (indexTerm.includes(term) || term.includes(indexTerm)) {
          fileIds.forEach(id => matchingFileIds.add(id));
        }
      }
    });

    // Get matching files
    let results = Array.from(matchingFileIds)
      .map(id => this.files.get(id))
      .filter((file): file is FileItem => file !== undefined);

    // Apply filters
    if (options?.type && options.type !== 'all') {
      results = results.filter(file => file.type === options.type);
    }

    if (options?.category) {
      results = results.filter(file => file.category === options.category);
    }

    if (options?.tags && options.tags.length > 0) {
      results = results.filter(file =>
        options.tags!.some(tag => file.tags.includes(tag))
      );
    }

    if (options?.minSize) {
      results = results.filter(file => file.size >= options.minSize!);
    }

    if (options?.maxSize) {
      results = results.filter(file => file.size <= options.maxSize!);
    }

    // Sort by relevance (simplified - could be more sophisticated)
    results.sort((a, b) => {
      // Prioritize exact matches
      const aExact = a.name.toLowerCase().includes(lowerQuery);
      const bExact = b.name.toLowerCase().includes(lowerQuery);
      if (aExact && !bExact) return -1;
      if (!aExact && bExact) return 1;

      // Then by importance
      const importanceOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return importanceOrder[a.importance] - importanceOrder[b.importance];
    });

    return results;
  }

  /**
   * Organize files using rules
   */
  async organizeFiles(fileIds?: string[]): Promise<{
    organized: number;
    moved: number;
    tagged: number;
    errors: number;
  }> {
    const filesToOrganize = fileIds
      ? fileIds.map(id => this.files.get(id)).filter((f): f is FileItem => f !== undefined)
      : Array.from(this.files.values());

    let organized = 0;
    let moved = 0;
    let tagged = 0;
    let errors = 0;

    for (const file of filesToOrganize) {
      try {
        for (const rule of this.organizationRules.values()) {
          if (!rule.enabled) continue;

          // Check if rule applies
          if (this.matchesRule(file, rule)) {
            // Apply action
            switch (rule.action.type) {
              case 'move':
                // Would move file in actual implementation
                moved++;
                break;
              case 'tag':
                if (!file.tags.includes(rule.action.target)) {
                  file.tags.push(rule.action.target);
                  this.files.set(file.id, file);
                  this.indexFile(file); // Re-index
                }
                tagged++;
                break;
              case 'delete':
                // Would delete file (with confirmation in production)
                this.files.delete(file.id);
                break;
            }
            organized++;
          }
        }
      } catch (error) {
        errors++;
        console.error(`[FileManager] Error organizing file ${file.name}:`, error);
      }
    }

    return { organized, moved, tagged, errors };
  }

  /**
   * Check if file matches rule
   */
  private matchesRule(file: FileItem, rule: OrganizationRule): boolean {
    const { condition } = rule;

    switch (condition.type) {
      case 'extension':
        if (!file.extension) return false;
        const extRegex = new RegExp(condition.pattern, 'i');
        return extRegex.test(file.extension);

      case 'name':
        const nameMatch = file.name.toLowerCase().includes(condition.pattern.toLowerCase());
        return condition.operator === 'contains' ? nameMatch : !nameMatch;

      case 'size':
        if (condition.operator === 'greater_than') {
          return file.size > condition.value;
        } else if (condition.operator === 'less_than') {
          return file.size < condition.value;
        }
        return false;

      case 'pattern':
        const regex = new RegExp(condition.pattern, 'i');
        return regex.test(file.name);

      default:
        return false;
    }
  }

  /**
   * Analyze files
   */
  analyzeFiles(): FileAnalysis {
    const allFiles = Array.from(this.files.values());

    const analysis: FileAnalysis = {
      totalFiles: allFiles.length,
      totalSize: allFiles.reduce((sum, file) => sum + file.size, 0),
      byType: {},
      byCategory: {},
      duplicates: [],
      largeFiles: [],
      oldFiles: [],
    };

    // Group by type
    allFiles.forEach(file => {
      const type = file.extension || 'unknown';
      if (!analysis.byType[type]) {
        analysis.byType[type] = { count: 0, size: 0 };
      }
      analysis.byType[type].count++;
      analysis.byType[type].size += file.size;
    });

    // Group by category
    allFiles.forEach(file => {
      const category = file.category || 'uncategorized';
      if (!analysis.byCategory[category]) {
        analysis.byCategory[category] = { count: 0, size: 0 };
      }
      analysis.byCategory[category].count++;
      analysis.byCategory[category].size += file.size;
    });

    // Find large files (> 100MB)
    analysis.largeFiles = allFiles
      .filter(file => file.size > 100 * 1024 * 1024)
      .map(file => ({
        name: file.name,
        path: file.path,
        size: file.size,
      }))
      .sort((a, b) => b.size - a.size)
      .slice(0, 10);

    // Find old files (> 1 year)
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

    analysis.oldFiles = allFiles
      .filter(file => file.accessed < oneYearAgo)
      .map(file => ({
        name: file.name,
        path: file.path,
        age: Math.floor((Date.now() - file.accessed.getTime()) / (1000 * 60 * 60 * 24)),
      }))
      .sort((a, b) => b.age - a.age)
      .slice(0, 10);

    // Find duplicates (by name and size)
    const fileMap = new Map<string, FileItem[]>();
    allFiles.forEach(file => {
      const key = `${file.name}-${file.size}`;
      if (!fileMap.has(key)) {
        fileMap.set(key, []);
      }
      fileMap.get(key)!.push(file);
    });

    analysis.duplicates = Array.from(fileMap.values())
      .filter(group => group.length > 1)
      .map(group => ({
        files: group.map(f => f.path),
        size: group[0].size * (group.length - 1), // Size that could be freed
      }))
      .slice(0, 10);

    return analysis;
  }

  /**
   * Cleanup files
   */
  async cleanupFiles(options?: {
    deleteDuplicates?: boolean;
    deleteOld?: boolean;
    deleteLarge?: boolean;
    minAge?: number; // days
    maxSize?: number; // bytes
  }): Promise<{
    deleted: number;
    freedSpace: number;
    errors: number;
  }> {
    let deleted = 0;
    let freedSpace = 0;
    let errors = 0;

    const analysis = this.analyzeFiles();

    // Delete duplicates
    if (options?.deleteDuplicates) {
      for (const duplicate of analysis.duplicates) {
        // Keep first, delete others
        for (let i = 1; i < duplicate.files.length; i++) {
          const fileId = duplicate.files[i];
          const file = Array.from(this.files.values()).find(f => f.path === fileId);
          if (file) {
            this.files.delete(file.id);
            freedSpace += file.size;
            deleted++;
          }
        }
      }
    }

    // Delete old files
    if (options?.deleteOld) {
      const minAge = options.minAge || 365; // Default 1 year
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - minAge);

      const oldFiles = Array.from(this.files.values()).filter(
        file => file.accessed < cutoffDate && file.importance !== 'critical'
      );

      oldFiles.forEach(file => {
        this.files.delete(file.id);
        freedSpace += file.size;
        deleted++;
      });
    }

    return { deleted, freedSpace, errors };
  }

  /**
   * Get file statistics
   */
  getStatistics(): {
    totalFiles: number;
    totalFolders: number;
    totalSize: number;
    averageSize: number;
    byType: Record<string, number>;
  } {
    const allFiles = Array.from(this.files.values());
    const files = allFiles.filter(f => f.type === 'file');
    const folders = allFiles.filter(f => f.type === 'folder');

    const totalSize = files.reduce((sum, file) => sum + file.size, 0);
    const averageSize = files.length > 0 ? totalSize / files.length : 0;

    const byType: Record<string, number> = {};
    files.forEach(file => {
      const type = file.extension || 'unknown';
      byType[type] = (byType[type] || 0) + 1;
    });

    return {
      totalFiles: files.length,
      totalFolders: folders.length,
      totalSize,
      averageSize,
      byType,
    };
  }

  /**
   * Create organization rule
   */
  createOrganizationRule(rule: Omit<OrganizationRule, 'id'>): OrganizationRule {
    const newRule: OrganizationRule = {
      ...rule,
      id: `rule-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };

    this.organizationRules.set(newRule.id, newRule);
    return newRule;
  }

  /**
   * Get all organization rules
   */
  getAllOrganizationRules(): OrganizationRule[] {
    return Array.from(this.organizationRules.values());
  }
}

// Singleton instance
export const intelligentFileManager = new IntelligentFileManager();

