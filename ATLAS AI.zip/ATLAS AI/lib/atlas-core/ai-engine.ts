/**
 * ATLAS AI Engine
 * Core AI processing and reasoning engine
 */

import { ATLAS_SYSTEM_PROMPT } from './config';
import { atlasMemory } from './memory';
import { masterBrain } from './knowledge-brains/master-brain';
import { llmAdapterManager } from './llm/llm-adapter';
import { actionExecutor } from './actions/action-executor';
import { appController } from './actions/app-controller';

export interface AIResponse {
  text: string;
  reasoning?: string;
  actions?: AIAction[];
  confidence: number;
}

export interface AIAction {
  type: 'device_control' | 'communication' | 'file_operation' | 'reminder' | 'research' | 'other';
  command: string;
  parameters?: Record<string, any>;
  requiresConfirmation: boolean;
}

export class AtlasAIEngine {
  private apiKey: string | null = null;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || null;
  }

  /**
   * Process user query and generate response
   */
  async processQuery(userId: string, query: string, context?: Record<string, any>): Promise<AIResponse> {
    // Get user memory and recent context
    const userMemory = atlasMemory.getMemory(userId);
    const recentContext = atlasMemory.getRecentContext(userId, 10);

    // Build context for AI
    const fullContext = this.buildContext(userMemory, recentContext, context);

    // Process query (this would integrate with OpenAI, DeepSeek, or other LLMs)
    const response = await this.generateResponse(query, fullContext);

    // Extract actions from response
    const actions = this.extractActions(response, query);

    // Save to memory
    atlasMemory.addToHistory(userId, query, response.text, context);

    return {
      text: response.text,
      reasoning: response.reasoning,
      actions,
      confidence: response.confidence || 0.8,
    };
  }

  /**
   * Build context from memory and history
   */
  private buildContext(
    userMemory: any,
    recentContext: any[],
    additionalContext?: Record<string, any>
  ): string {
    let context = ATLAS_SYSTEM_PROMPT;

    if (userMemory) {
      context += `\n\nUser Information:\n`;
      context += `Name: ${userMemory.name}\n`;
      if (userMemory.bio) {
        context += `Bio: ${userMemory.bio}\n`;
      }
      if (userMemory.preferences) {
        context += `Preferences: ${JSON.stringify(userMemory.preferences)}\n`;
      }
      if (userMemory.habits.length > 0) {
        context += `Habits: ${userMemory.habits.join(', ')}\n`;
      }
    }

    if (recentContext.length > 0) {
      context += `\n\nRecent Conversation History:\n`;
      recentContext.slice(-5).forEach((entry, index) => {
        context += `${index + 1}. User: ${entry.userMessage}\n`;
        context += `   ATLAS: ${entry.atlasResponse}\n`;
      });
    }

    if (additionalContext) {
      context += `\n\nAdditional Context: ${JSON.stringify(additionalContext)}\n`;
    }

    return context;
  }

  /**
   * Generate response using LLM (placeholder - integrate with actual LLM API)
   */
  private async generateResponse(query: string, context: string): Promise<{
    text: string;
    reasoning?: string;
    confidence?: number;
  }> {
    // Check for wake word
    if (query.toLowerCase().includes('hey atlas')) {
      return {
        text: "Good day, Sir. ATLAS is ready. How may I assist you?",
        confidence: 1.0,
      };
    }

    // Check for greetings
    if (this.isGreeting(query)) {
      return {
        text: `Hello, Sir. ATLAS systems are operational. What can I help you with today?`,
        confidence: 0.9,
      };
    }

    // Try LLM integration first (ChatGPT/OpenAI)
    try {
      const llmAdapter = llmAdapterManager.getDefaultAdapter();
      
      if (llmAdapter && llmAdapter.isReady()) {
        // Use ChatGPT for enhanced responses
        const llmResponse = await llmAdapterManager.generateResponse(query, context, {
          userId: userId,
        });
        
        // Save to memory
        atlasMemory.addToHistory(userId, query, llmResponse.content, context);
        
        // Also process through Master Brain for additional insights
        try {
          const masterResponse = await masterBrain.processQuery(query, context);
          
          return {
            text: `${llmResponse.content}\n\n[Enhanced with ${masterResponse.additional?.length || 0} knowledge brains]`,
            reasoning: masterResponse.reasoning || `Processed through ChatGPT LLM + Master Brain synthesis`,
            confidence: Math.min(0.98, (masterResponse.confidence + 0.95) / 2),
          };
        } catch (masterError) {
          // If Master Brain fails, still return LLM response
          return {
            text: llmResponse.content,
            reasoning: "Processed through ChatGPT LLM",
            confidence: 0.95,
          };
        }
      } else {
        // Fallback to Master Brain without LLM
        const masterResponse = await masterBrain.processQuery(query, context);
        
        return {
          text: masterResponse.synthesis || masterResponse.primary?.answer || masterResponse.primary?.content || "I've processed your query through multiple knowledge brains, Sir.",
          reasoning: masterResponse.reasoning,
          confidence: masterResponse.confidence,
        };
      }
    } catch (error: any) {
      console.error('AI Engine error:', error);
      
      // Final fallback
      return {
        text: `I understand your query, Sir. ${error.message?.includes('API key') ? 'Please configure OPENAI_API_KEY in environment variables for enhanced responses.' : 'Processing through knowledge brains.'}`,
        reasoning: "Fallback response",
        confidence: 0.6,
      };
    }
  }

  /**
   * Extract actionable commands from query and response
   */
  private extractActions(response: string, query: string): AIAction[] {
    const actions: AIAction[] = [];
    const lowerQuery = query.toLowerCase();

    // Use Action Executor to parse commands
    const commandResult = actionExecutor.executeCommand(query);
    
    // Extract app commands
    if (appController.isAppCommand(query)) {
      const appAction = appController.parseCommand(query);
      if (appAction) {
        actions.push({
          type: 'device_control',
          command: appAction.type === 'open_app' ? 'open_app' : 'custom_action',
          parameters: {
            app: appAction.app,
            action: appAction.action,
            ...appAction.parameters,
          },
          requiresConfirmation: appAction.requiresConfirmation,
        });
      }
    }

    // Volume control
    if (lowerQuery.includes('volume up') || lowerQuery.includes('increase volume')) {
      actions.push({
        type: 'device_control',
        command: 'volume_up',
        parameters: {},
        requiresConfirmation: false,
      });
    }

    if (lowerQuery.includes('volume down') || lowerQuery.includes('decrease volume')) {
      actions.push({
        type: 'device_control',
        command: 'volume_down',
        parameters: {},
        requiresConfirmation: false,
      });
    }

    // Brightness control
    if (lowerQuery.includes('brightness')) {
      actions.push({
        type: 'device_control',
        command: lowerQuery.includes('up') ? 'brightness_up' : lowerQuery.includes('down') ? 'brightness_down' : 'brightness_set',
        parameters: {},
        requiresConfirmation: false,
      });
    }

    // WiFi/Bluetooth
    if (lowerQuery.includes('wifi') || lowerQuery.includes('wi-fi')) {
      actions.push({
        type: 'device_control',
        command: lowerQuery.includes('on') ? 'wifi_on' : 'wifi_off',
        parameters: {},
        requiresConfirmation: true,
      });
    }

    if (lowerQuery.includes('bluetooth')) {
      actions.push({
        type: 'device_control',
        command: lowerQuery.includes('on') ? 'bluetooth_on' : 'bluetooth_off',
        parameters: {},
        requiresConfirmation: true,
      });
    }

    // Screenshot
    if (lowerQuery.includes('screenshot') || lowerQuery.includes('capture screen')) {
      actions.push({
        type: 'device_control',
        command: 'screenshot',
        parameters: {},
        requiresConfirmation: false,
      });
    }

    // Reminder
    if (lowerQuery.includes('remind me') || lowerQuery.includes('set reminder')) {
      actions.push({
        type: 'reminder',
        command: 'create_reminder',
        parameters: { text: query },
        requiresConfirmation: true,
      });
    }

    // Communication
    if (lowerQuery.includes('send message') || lowerQuery.includes('whatsapp') || lowerQuery.includes('telegram')) {
      actions.push({
        type: 'communication',
        command: 'send_message',
        parameters: { platform: this.extractPlatform(query), message: query },
        requiresConfirmation: true,
      });
    }

    return actions;
  }

  private isGreeting(query: string): boolean {
    const greetings = ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening'];
    return greetings.some(g => query.toLowerCase().includes(g));
  }

  private extractAppName(query: string): string {
    const apps = ['chrome', 'youtube', 'whatsapp', 'telegram', 'spotify', 'google'];
    for (const app of apps) {
      if (query.toLowerCase().includes(app)) {
        return app;
      }
    }
    return 'unknown';
  }

  private extractPlatform(query: string): string {
    if (query.toLowerCase().includes('whatsapp')) return 'whatsapp';
    if (query.toLowerCase().includes('telegram')) return 'telegram';
    if (query.toLowerCase().includes('email')) return 'email';
    if (query.toLowerCase().includes('sms')) return 'sms';
    return 'unknown';
  }
}

// Singleton instance
export const atlasAIEngine = new AtlasAIEngine();

