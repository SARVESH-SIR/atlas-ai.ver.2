/**
 * ATLAS AI - OpenAI/ChatGPT Integration Client
 * High-level architecture for ChatGPT LLM integration
 */

import OpenAI from 'openai';
import { ATLAS_SYSTEM_PROMPT } from '../config';
import { atlasMemory } from '../memory';

export interface LLMRequest {
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string;
  }>;
  model?: string;
  temperature?: number;
  max_tokens?: number;
  stream?: boolean;
}

export interface LLMResponse {
  content: string;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
  model?: string;
  finish_reason?: string;
}

export interface StreamingResponse {
  content: string;
  done: boolean;
}

export class OpenAIClient {
  private client: OpenAI | null = null;
  private apiKey: string | null = null;
  private isConfigured: boolean = false;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.OPENAI_API_KEY || null;
    
    if (this.apiKey) {
      try {
        this.client = new OpenAI({
          apiKey: this.apiKey,
          dangerouslyAllowBrowser: false, // Always use server-side
        });
        this.isConfigured = true;
      } catch (error) {
        console.error('OpenAI client initialization error:', error);
        this.isConfigured = false;
      }
    }
  }

  /**
   * Check if OpenAI is configured
   */
  isReady(): boolean {
    return this.isConfigured && this.client !== null;
  }

  /**
   * Generate response using ChatGPT
   */
  async generateResponse(
    userMessage: string,
    context?: string,
    options?: {
      model?: string;
      temperature?: number;
      max_tokens?: number;
      userId?: string;
    }
  ): Promise<LLMResponse> {
    if (!this.isReady()) {
      throw new Error('OpenAI client is not configured. Please add OPENAI_API_KEY to environment variables.');
    }

    try {
      // Get user memory for context
      const userId = options?.userId || 'creator';
      const userMemory = atlasMemory.getMemory(userId);
      const recentContext = atlasMemory.getRecentContext(userId, 5);

      // Build system prompt with context
      let systemPrompt = ATLAS_SYSTEM_PROMPT;
      
      if (userMemory) {
        systemPrompt += `\n\nUser Context:\n`;
        systemPrompt += `- Name: ${userMemory.name}\n`;
        if (userMemory.preferences) {
          systemPrompt += `- Preferences: ${JSON.stringify(userMemory.preferences)}\n`;
        }
      }

      // Add recent conversation context
      if (recentContext.length > 0) {
        systemPrompt += `\n\nRecent Conversation:\n`;
        recentContext.slice(-3).forEach((entry, index) => {
          systemPrompt += `${index + 1}. User: ${entry.userMessage}\n`;
          systemPrompt += `   ATLAS: ${entry.atlasResponse.substring(0, 100)}...\n`;
        });
      }

      if (context) {
        systemPrompt += `\n\nAdditional Context: ${context}\n`;
      }

      // Prepare messages
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: userMessage,
        },
      ];

      // Call OpenAI API
      const model = options?.model || 'gpt-4-turbo-preview';
      const completion = await this.client!.chat.completions.create({
        model,
        messages,
        temperature: options?.temperature ?? 0.7,
        max_tokens: options?.max_tokens ?? 2000,
        stream: false,
      });

      const response = completion.choices[0]?.message?.content || 'I apologize, but I could not generate a response.';
      
      return {
        content: response,
        usage: completion.usage ? {
          prompt_tokens: completion.usage.prompt_tokens,
          completion_tokens: completion.usage.completion_tokens,
          total_tokens: completion.usage.total_tokens,
        } : undefined,
        model: completion.model,
        finish_reason: completion.choices[0]?.finish_reason || undefined,
      };
    } catch (error: any) {
      console.error('OpenAI API error:', error);
      throw new Error(`OpenAI API error: ${error.message || 'Unknown error'}`);
    }
  }

  /**
   * Generate streaming response
   */
  async *generateStreamingResponse(
    userMessage: string,
    context?: string,
    options?: {
      model?: string;
      temperature?: number;
      max_tokens?: number;
      userId?: string;
    }
  ): AsyncGenerator<StreamingResponse, void, unknown> {
    if (!this.isReady()) {
      throw new Error('OpenAI client is not configured.');
    }

    try {
      // Build context (same as generateResponse)
      const userId = options?.userId || 'creator';
      const userMemory = atlasMemory.getMemory(userId);
      const recentContext = atlasMemory.getRecentContext(userId, 5);

      let systemPrompt = ATLAS_SYSTEM_PROMPT;
      
      if (userMemory) {
        systemPrompt += `\n\nUser Context:\n- Name: ${userMemory.name}\n`;
      }

      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage },
      ];

      const model = options?.model || 'gpt-4-turbo-preview';
      const stream = await this.client!.chat.completions.create({
        model,
        messages,
        temperature: options?.temperature ?? 0.7,
        max_tokens: options?.max_tokens ?? 2000,
        stream: true,
      });

      let fullContent = '';

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || '';
        fullContent += content;
        
        yield {
          content: fullContent,
          done: chunk.choices[0]?.finish_reason === 'stop',
        };
      }
    } catch (error: any) {
      console.error('OpenAI streaming error:', error);
      throw error;
    }
  }

  /**
   * Generate with specific brain/system prompt
   */
  async generateWithBrain(
    brainType: string,
    userMessage: string,
    brainContext: string,
    options?: {
      model?: string;
      temperature?: number;
      userId?: string;
    }
  ): Promise<LLMResponse> {
    if (!this.isReady()) {
      throw new Error('OpenAI client is not configured.');
    }

    const brainSystemPrompt = this.getBrainSystemPrompt(brainType, brainContext);
    
    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      {
        role: 'system',
        content: brainSystemPrompt,
      },
      {
        role: 'user',
        content: userMessage,
      },
    ];

    const model = options?.model || 'gpt-4-turbo-preview';
    const completion = await this.client!.chat.completions.create({
      model,
      messages,
      temperature: options?.temperature ?? 0.7,
      max_tokens: 2000,
    });

    return {
      content: completion.choices[0]?.message?.content || '',
      usage: completion.usage ? {
        prompt_tokens: completion.usage.prompt_tokens,
        completion_tokens: completion.usage.completion_tokens,
        total_tokens: completion.usage.total_tokens,
      } : undefined,
      model: completion.model,
    };
  }

  /**
   * Get brain-specific system prompt
   */
  private getBrainSystemPrompt(brainType: string, context: string): string {
    const brainPrompts: Record<string, string> = {
      knowledge: `You are ATLAS Knowledge Engine. You have universal knowledge across all domains. Provide accurate, comprehensive information. Context: ${context}`,
      reasoning: `You are ATLAS Reasoning Engine. Use logical reasoning, step-by-step analysis, and critical thinking. Context: ${context}`,
      research: `You are ATLAS Research Engine. Conduct thorough research, analyze sources, and provide well-researched answers. Context: ${context}`,
      coding: `You are ATLAS Coding Engine. Generate clean, efficient, well-documented code. Follow best practices. Context: ${context}`,
      creative: `You are ATLAS Creative Engine. Generate creative, engaging content with artistic flair. Context: ${context}`,
      science: `You are ATLAS Science Engine. Provide accurate scientific explanations with formulas and principles. Context: ${context}`,
      medical: `You are ATLAS Medical Engine. Provide educational health information with appropriate disclaimers. Context: ${context}`,
      language: `You are ATLAS Language Engine. Expert in translation, linguistics, and multilingual communication. Context: ${context}`,
    };

    return brainPrompts[brainType] || ATLAS_SYSTEM_PROMPT + `\nContext: ${context}`;
  }

  /**
   * Get available models
   */
  getAvailableModels(): string[] {
    return [
      'gpt-4-turbo-preview',
      'gpt-4',
      'gpt-3.5-turbo',
      'gpt-4o',
      'gpt-4o-mini',
    ];
  }
}

// Singleton instance
let openAIClientInstance: OpenAIClient | null = null;

export function getOpenAIClient(apiKey?: string): OpenAIClient {
  if (!openAIClientInstance) {
    openAIClientInstance = new OpenAIClient(apiKey);
  }
  return openAIClientInstance;
}

export const openAIClient = getOpenAIClient();

