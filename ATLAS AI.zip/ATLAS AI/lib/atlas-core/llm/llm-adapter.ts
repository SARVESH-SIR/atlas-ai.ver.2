/**
 * ATLAS AI - LLM Adapter Layer
 * Abstraction layer for multiple LLM providers
 */

import { OpenAIClient, LLMResponse, StreamingResponse } from './openai-client';

export interface LLMAdapter {
  generateResponse(
    message: string,
    context?: string,
    options?: any
  ): Promise<LLMResponse>;
  
  generateStreamingResponse?(
    message: string,
    context?: string,
    options?: any
  ): AsyncGenerator<StreamingResponse, void, unknown>;
  
  isReady(): boolean;
}

export class LLMAdapterManager {
  private adapters: Map<string, LLMAdapter> = new Map();
  private defaultAdapter: string = 'openai';
  private fallbackAdapter: string | null = null;

  constructor() {
    // Register OpenAI adapter
    this.registerAdapter('openai', new OpenAIClientAdapter());
    
    // Future: Register other adapters
    // this.registerAdapter('deepseek', new DeepSeekAdapter());
    // this.registerAdapter('gemini', new GeminiAdapter());
  }

  /**
   * Register an LLM adapter
   */
  registerAdapter(name: string, adapter: LLMAdapter): void {
    this.adapters.set(name, adapter);
  }

  /**
   * Get adapter by name
   */
  getAdapter(name?: string): LLMAdapter | null {
    const adapterName = name || this.defaultAdapter;
    return this.adapters.get(adapterName) || null;
  }

  /**
   * Get default adapter
   */
  getDefaultAdapter(): LLMAdapter | null {
    return this.getAdapter(this.defaultAdapter);
  }

  /**
   * Set default adapter
   */
  setDefaultAdapter(name: string): void {
    if (this.adapters.has(name)) {
      this.defaultAdapter = name;
    }
  }

  /**
   * Generate response with fallback
   */
  async generateResponse(
    message: string,
    context?: string,
    options?: { adapter?: string; userId?: string }
  ): Promise<LLMResponse> {
    const adapterName = options?.adapter || this.defaultAdapter;
    const adapter = this.getAdapter(adapterName);

    if (!adapter) {
      throw new Error(`Adapter ${adapterName} not found`);
    }

    if (!adapter.isReady()) {
      // Try fallback
      if (this.fallbackAdapter && this.fallbackAdapter !== adapterName) {
        const fallback = this.getAdapter(this.fallbackAdapter);
        if (fallback && fallback.isReady()) {
          return await fallback.generateResponse(message, context, options);
        }
      }
      
      throw new Error(`Adapter ${adapterName} is not ready. Please configure API keys.`);
    }

    try {
      return await adapter.generateResponse(message, context, options);
    } catch (error) {
      console.error(`Error with adapter ${adapterName}:`, error);
      
      // Try fallback
      if (this.fallbackAdapter && this.fallbackAdapter !== adapterName) {
        const fallback = this.getAdapter(this.fallbackAdapter);
        if (fallback && fallback.isReady()) {
          console.log(`Falling back to ${this.fallbackAdapter}`);
          return await fallback.generateResponse(message, context, options);
        }
      }
      
      throw error;
    }
  }

  /**
   * Get available adapters
   */
  getAvailableAdapters(): string[] {
    return Array.from(this.adapters.keys());
  }

  /**
   * Check adapter status
   */
  getAdapterStatus(): Record<string, boolean> {
    const status: Record<string, boolean> = {};
    
    for (const [name, adapter] of this.adapters.entries()) {
      status[name] = adapter.isReady();
    }
    
    return status;
  }
}

/**
 * OpenAI Client Adapter
 */
class OpenAIClientAdapter implements LLMAdapter {
  private client: import('./openai-client').OpenAIClient;

  constructor() {
    this.client = require('./openai-client').openAIClient;
  }

  isReady(): boolean {
    return this.client.isReady();
  }

  async generateResponse(
    message: string,
    context?: string,
    options?: any
  ): Promise<LLMResponse> {
    return await this.client.generateResponse(message, context, options);
  }

  async *generateStreamingResponse(
    message: string,
    context?: string,
    options?: any
  ): AsyncGenerator<StreamingResponse, void, unknown> {
    yield* this.client.generateStreamingResponse(message, context, options);
  }
}

// Singleton instance
export const llmAdapterManager = new LLMAdapterManager();

