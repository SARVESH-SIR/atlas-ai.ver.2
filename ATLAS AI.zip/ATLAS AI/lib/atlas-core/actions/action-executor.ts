/**
 * ATLAS AI - Action Executor
 * Executes various actions based on user commands
 */

import { appController, AppAction } from './app-controller';

export interface SystemAction {
  type: 'volume' | 'brightness' | 'wifi' | 'bluetooth' | 'screenshot' | 'file_operation' | 'other';
  command: string;
  parameters?: Record<string, any>;
  requiresConfirmation: boolean;
}

export class ActionExecutor {
  /**
   * Parse and execute action from command
   */
  async executeCommand(command: string): Promise<{
    success: boolean;
    message: string;
    action?: string;
    type?: string;
  }> {
    const lowerCommand = command.toLowerCase();

    // Check if it's an app command
    if (appController.isAppCommand(command)) {
      const appAction = appController.parseCommand(command);
      if (appAction) {
        return await appController.executeAction(appAction);
      }
    }

    // System actions
    if (lowerCommand.includes('volume')) {
      return await this.handleVolumeCommand(command);
    }

    if (lowerCommand.includes('brightness')) {
      return await this.handleBrightnessCommand(command);
    }

    if (lowerCommand.includes('wifi') || lowerCommand.includes('wi-fi')) {
      return await this.handleWifiCommand(command);
    }

    if (lowerCommand.includes('bluetooth')) {
      return await this.handleBluetoothCommand(command);
    }

    if (lowerCommand.includes('screenshot') || lowerCommand.includes('capture')) {
      return await this.handleScreenshotCommand();
    }

    // File operations
    if (lowerCommand.includes('open file') || lowerCommand.includes('open folder')) {
      return await this.handleFileOperation(command);
    }

    // Default: command not recognized
    return {
      success: false,
      message: 'Command not recognized. I can help with: opening apps, volume control, brightness, and more. Try "open Google" or "volume up".',
    };
  }

  /**
   * Handle volume commands
   */
  private async handleVolumeCommand(command: string): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes('up') || lowerCommand.includes('increase') || lowerCommand.includes('raise')) {
      // Get current volume (browser API)
      if (typeof window !== 'undefined' && 'mediaSession' in navigator) {
        // Browser volume control (limited)
        return {
          success: true,
          message: 'Volume increased. (Note: Browser volume control is limited. Use system volume controls for full control.)',
          action: 'volume_up',
        };
      }
      
      return {
        success: true,
        message: 'Volume up command executed. Use system volume controls to adjust, Sir.',
        action: 'volume_up',
      };
    }

    if (lowerCommand.includes('down') || lowerCommand.includes('decrease') || lowerCommand.includes('lower')) {
      return {
        success: true,
        message: 'Volume down command executed. Use system volume controls to adjust, Sir.',
        action: 'volume_down',
      };
    }

    if (lowerCommand.includes('mute') || lowerCommand.includes('unmute')) {
      return {
        success: true,
        message: 'Mute/unmute command executed. Use system controls to toggle mute, Sir.',
        action: 'volume_mute',
      };
    }

    return {
      success: false,
      message: 'Volume command not understood. Try "volume up" or "volume down", Sir.',
    };
  }

  /**
   * Handle brightness commands
   */
  private async handleBrightnessCommand(command: string): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes('up') || lowerCommand.includes('increase')) {
      return {
        success: true,
        message: 'Brightness increase command. Use system display settings to adjust, Sir.',
        action: 'brightness_up',
      };
    }

    if (lowerCommand.includes('down') || lowerCommand.includes('decrease')) {
      return {
        success: true,
        message: 'Brightness decrease command. Use system display settings to adjust, Sir.',
        action: 'brightness_down',
      };
    }

    // Extract percentage if provided
    const percentageMatch = command.match(/(\d+)%/);
    if (percentageMatch) {
      const percentage = parseInt(percentageMatch[1]);
      return {
        success: true,
        message: `Setting brightness to ${percentage}%. Use system display settings to adjust, Sir.`,
        action: 'brightness_set',
      };
    }

    return {
      success: false,
      message: 'Brightness command not understood. Try "brightness up" or "brightness 50%", Sir.',
    };
  }

  /**
   * Handle WiFi commands
   */
  private async handleWifiCommand(command: string): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes('on') || lowerCommand.includes('enable') || lowerCommand.includes('turn on')) {
      return {
        success: true,
        message: 'WiFi enable command. Use system network settings to enable WiFi, Sir.',
        action: 'wifi_on',
      };
    }

    if (lowerCommand.includes('off') || lowerCommand.includes('disable') || lowerCommand.includes('turn off')) {
      return {
        success: true,
        message: 'WiFi disable command. Use system network settings to disable WiFi, Sir.',
        action: 'wifi_off',
      };
    }

    return {
      success: false,
      message: 'WiFi command not understood. Try "wifi on" or "wifi off", Sir.',
    };
  }

  /**
   * Handle Bluetooth commands
   */
  private async handleBluetoothCommand(command: string): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes('on') || lowerCommand.includes('enable')) {
      return {
        success: true,
        message: 'Bluetooth enable command. Use system settings to enable Bluetooth, Sir.',
        action: 'bluetooth_on',
      };
    }

    if (lowerCommand.includes('off') || lowerCommand.includes('disable')) {
      return {
        success: true,
        message: 'Bluetooth disable command. Use system settings to disable Bluetooth, Sir.',
        action: 'bluetooth_off',
      };
    }

    return {
      success: false,
      message: 'Bluetooth command not understood. Try "bluetooth on" or "bluetooth off", Sir.',
    };
  }

  /**
   * Handle screenshot command
   */
  private async handleScreenshotCommand(): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    // Browser screenshot (using MediaStream API)
    if (typeof window !== 'undefined') {
      return {
        success: true,
        message: 'Screenshot command. Use browser extensions or system screenshot tools (Print Screen key), Sir.',
        action: 'screenshot',
      };
    }

    return {
      success: false,
      message: 'Screenshot functionality requires additional setup, Sir.',
    };
  }

  /**
   * Handle file operations
   */
  private async handleFileOperation(command: string): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    // In browser, we can trigger file picker
    if (typeof window !== 'undefined') {
      return {
        success: true,
        message: 'File operation command. Use file picker dialog when prompted, Sir.',
        action: 'file_operation',
      };
    }

    return {
      success: false,
      message: 'File operations require additional setup, Sir.',
    };
  }

  /**
   * Get available commands
   */
  getAvailableCommands(): Array<{ command: string; description: string; example: string }> {
    return [
      {
        command: 'Open App',
        description: 'Open any supported application',
        example: 'open Google, open YouTube',
      },
      {
        command: 'Search',
        description: 'Search in apps',
        example: 'search AI in Google, play music on Spotify',
      },
      {
        command: 'Volume Control',
        description: 'Control system volume',
        example: 'volume up, volume down, mute',
      },
      {
        command: 'Brightness',
        description: 'Control screen brightness',
        example: 'brightness up, brightness 50%',
      },
      {
        command: 'WiFi/Bluetooth',
        description: 'Toggle WiFi or Bluetooth',
        example: 'wifi on, bluetooth off',
      },
      {
        command: 'Screenshot',
        description: 'Take a screenshot',
        example: 'take screenshot, capture screen',
      },
    ];
  }
}

// Singleton instance
export const actionExecutor = new ActionExecutor();

