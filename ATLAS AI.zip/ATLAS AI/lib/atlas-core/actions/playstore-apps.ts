/**
 * ATLAS AI - Play Store Apps Registry
 * Comprehensive list of popular Android apps from Play Store
 */

export interface PlayStoreApp {
  name: string;
  packageName?: string;
  categories: string[];
  deepLink?: string;
  playStoreUrl: string;
  webUrl?: string;
  aliases: string[];
  description: string;
}

export class PlayStoreAppsRegistry {
  private apps: Map<string, PlayStoreApp> = new Map();

  constructor() {
    this.initializePlayStoreApps();
  }

  /**
   * Initialize popular Play Store apps
   */
  private initializePlayStoreApps() {
    const playStoreApps: PlayStoreApp[] = [
      // Social Media & Communication
      {
        name: 'WhatsApp',
        packageName: 'com.whatsapp',
        categories: ['Communication', 'Social'],
        deepLink: 'whatsapp://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.whatsapp',
        webUrl: 'https://web.whatsapp.com',
        aliases: ['whatsapp', 'wa'],
        description: 'Messaging and calling app',
      },
      {
        name: 'Telegram',
        packageName: 'org.telegram.messenger',
        categories: ['Communication', 'Social'],
        deepLink: 'tg://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=org.telegram.messenger',
        webUrl: 'https://web.telegram.org',
        aliases: ['telegram', 'tg'],
        description: 'Fast and secure messaging',
      },
      {
        name: 'Instagram',
        packageName: 'com.instagram.android',
        categories: ['Social', 'Photo'],
        deepLink: 'instagram://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.instagram.android',
        webUrl: 'https://www.instagram.com',
        aliases: ['instagram', 'insta', 'ig'],
        description: 'Photo and video sharing',
      },
      {
        name: 'Facebook',
        packageName: 'com.facebook.katana',
        categories: ['Social'],
        deepLink: 'fb://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.facebook.katana',
        webUrl: 'https://www.facebook.com',
        aliases: ['facebook', 'fb'],
        description: 'Connect with friends and family',
      },
      {
        name: 'Twitter',
        packageName: 'com.twitter.android',
        categories: ['Social', 'News'],
        deepLink: 'twitter://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.twitter.android',
        webUrl: 'https://twitter.com',
        aliases: ['twitter', 'x', 'tweet'],
        description: 'Social networking and news',
      },
      {
        name: 'Snapchat',
        packageName: 'com.snapchat.android',
        categories: ['Social', 'Photo'],
        deepLink: 'snapchat://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.snapchat.android',
        aliases: ['snapchat', 'snap'],
        description: 'Photo and video messaging',
      },
      {
        name: 'Discord',
        packageName: 'com.discord',
        categories: ['Communication', 'Gaming'],
        deepLink: 'discord://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.discord',
        webUrl: 'https://discord.com',
        aliases: ['discord'],
        description: 'Chat for gamers',
      },
      {
        name: 'LinkedIn',
        packageName: 'com.linkedin.android',
        categories: ['Social', 'Business'],
        deepLink: 'linkedin://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.linkedin.android',
        webUrl: 'https://www.linkedin.com',
        aliases: ['linkedin', 'li'],
        description: 'Professional networking',
      },
      {
        name: 'Reddit',
        packageName: 'com.reddit.frontpage',
        categories: ['Social', 'News'],
        deepLink: 'reddit://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.reddit.frontpage',
        webUrl: 'https://www.reddit.com',
        aliases: ['reddit'],
        description: 'News and discussions',
      },
      
      // Media & Entertainment
      {
        name: 'YouTube',
        packageName: 'com.google.android.youtube',
        categories: ['Media', 'Video'],
        deepLink: 'youtube://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.youtube',
        webUrl: 'https://www.youtube.com',
        aliases: ['youtube', 'yt', 'video'],
        description: 'Watch and share videos',
      },
      {
        name: 'YouTube Music',
        packageName: 'com.google.android.apps.youtube.music',
        categories: ['Media', 'Music'],
        deepLink: 'youtubemusic://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.youtube.music',
        aliases: ['youtube music', 'yt music'],
        description: 'Music streaming',
      },
      {
        name: 'Spotify',
        packageName: 'com.spotify.music',
        categories: ['Media', 'Music'],
        deepLink: 'spotify://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.spotify.music',
        webUrl: 'https://open.spotify.com',
        aliases: ['spotify', 'music'],
        description: 'Music streaming service',
      },
      {
        name: 'Netflix',
        packageName: 'com.netflix.mediaclient',
        categories: ['Media', 'Video'],
        deepLink: 'nflx://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.netflix.mediaclient',
        webUrl: 'https://www.netflix.com',
        aliases: ['netflix'],
        description: 'Stream movies and TV shows',
      },
      {
        name: 'Prime Video',
        packageName: 'com.amazon.avod.thirdpartyclient',
        categories: ['Media', 'Video'],
        deepLink: 'primevideo://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.amazon.avod.thirdpartyclient',
        webUrl: 'https://www.primevideo.com',
        aliases: ['prime video', 'amazon prime'],
        description: 'Amazon Prime Video',
      },
      {
        name: 'Disney+',
        packageName: 'com.disney.disneyplus',
        categories: ['Media', 'Video'],
        deepLink: 'disneyplus://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.disney.disneyplus',
        webUrl: 'https://www.disneyplus.com',
        aliases: ['disney plus', 'disney+'],
        description: 'Disney streaming service',
      },
      {
        name: 'MX Player',
        packageName: 'com.mxtech.videoplayer.ad',
        categories: ['Media', 'Video'],
        deepLink: 'mxplayer://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.mxtech.videoplayer.ad',
        aliases: ['mx player', 'mxplayer'],
        description: 'Video player',
      },
      {
        name: 'VLC',
        packageName: 'org.videolan.vlc',
        categories: ['Media', 'Video'],
        deepLink: 'vlc://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=org.videolan.vlc',
        aliases: ['vlc'],
        description: 'Media player',
      },
      
      // Productivity & Office
      {
        name: 'Gmail',
        packageName: 'com.google.android.gm',
        categories: ['Productivity', 'Communication'],
        deepLink: 'googlegmail://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.gm',
        webUrl: 'https://mail.google.com',
        aliases: ['gmail', 'email', 'mail'],
        description: 'Email client',
      },
      {
        name: 'Google Drive',
        packageName: 'com.google.android.apps.docs',
        categories: ['Productivity', 'Storage'],
        deepLink: 'googledrive://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.docs',
        webUrl: 'https://drive.google.com',
        aliases: ['google drive', 'drive', 'gdrive'],
        description: 'Cloud storage',
      },
      {
        name: 'Microsoft Word',
        packageName: 'com.microsoft.office.word',
        categories: ['Productivity', 'Office'],
        deepLink: 'ms-word://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.microsoft.office.word',
        aliases: ['word', 'ms word', 'microsoft word'],
        description: 'Word processor',
      },
      {
        name: 'Microsoft Excel',
        packageName: 'com.microsoft.office.excel',
        categories: ['Productivity', 'Office'],
        deepLink: 'ms-excel://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.microsoft.office.excel',
        aliases: ['excel', 'ms excel', 'microsoft excel'],
        description: 'Spreadsheet application',
      },
      {
        name: 'Microsoft PowerPoint',
        packageName: 'com.microsoft.office.powerpoint',
        categories: ['Productivity', 'Office'],
        deepLink: 'ms-powerpoint://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.microsoft.office.powerpoint',
        aliases: ['powerpoint', 'ppt', 'ms powerpoint'],
        description: 'Presentation software',
      },
      {
        name: 'Google Docs',
        packageName: 'com.google.android.apps.docs.editors.docs',
        categories: ['Productivity', 'Office'],
        deepLink: 'googledocs://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.docs.editors.docs',
        webUrl: 'https://docs.google.com',
        aliases: ['google docs', 'docs'],
        description: 'Online word processor',
      },
      {
        name: 'Google Sheets',
        packageName: 'com.google.android.apps.docs.editors.sheets',
        categories: ['Productivity', 'Office'],
        deepLink: 'googlesheets://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.docs.editors.sheets',
        webUrl: 'https://sheets.google.com',
        aliases: ['google sheets', 'sheets'],
        description: 'Online spreadsheet',
      },
      {
        name: 'Evernote',
        packageName: 'com.evernote',
        categories: ['Productivity', 'Notes'],
        deepLink: 'evernote://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.evernote',
        aliases: ['evernote'],
        description: 'Note-taking app',
      },
      {
        name: 'Notion',
        packageName: 'notion.id',
        categories: ['Productivity', 'Notes'],
        deepLink: 'notion://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=notion.id',
        webUrl: 'https://www.notion.so',
        aliases: ['notion'],
        description: 'All-in-one workspace',
      },
      {
        name: 'OneNote',
        packageName: 'com.microsoft.office.onenote',
        categories: ['Productivity', 'Notes'],
        deepLink: 'ms-onenote://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.microsoft.office.onenote',
        aliases: ['onenote', 'one note'],
        description: 'Digital notebook',
      },
      {
        name: 'Google Calendar',
        packageName: 'com.google.android.calendar',
        categories: ['Productivity', 'Calendar'],
        deepLink: 'googlecalendar://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.calendar',
        webUrl: 'https://calendar.google.com',
        aliases: ['google calendar', 'calendar'],
        description: 'Calendar and scheduling',
      },
      
      // Shopping & E-commerce
      {
        name: 'Amazon',
        packageName: 'in.amazon.mShop.android.shopping',
        categories: ['Shopping'],
        deepLink: 'amazon://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=in.amazon.mShop.android.shopping',
        webUrl: 'https://www.amazon.com',
        aliases: ['amazon'],
        description: 'Online shopping',
      },
      {
        name: 'Flipkart',
        packageName: 'com.flipkart.android',
        categories: ['Shopping'],
        deepLink: 'flipkart://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.flipkart.android',
        webUrl: 'https://www.flipkart.com',
        aliases: ['flipkart'],
        description: 'Online shopping platform',
      },
      {
        name: 'Paytm',
        packageName: 'net.one97.paytm',
        categories: ['Finance', 'Payment'],
        deepLink: 'paytm://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=net.one97.paytm',
        aliases: ['paytm'],
        description: 'Digital payment wallet',
      },
      {
        name: 'PhonePe',
        packageName: 'com.phonepe.app',
        categories: ['Finance', 'Payment'],
        deepLink: 'phonepe://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.phonepe.app',
        aliases: ['phonepe'],
        description: 'Digital payments',
      },
      {
        name: 'Google Pay',
        packageName: 'com.google.android.apps.nfc.payment',
        categories: ['Finance', 'Payment'],
        deepLink: 'tez://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.nfc.payment',
        aliases: ['google pay', 'gpay'],
        description: 'Digital payment app',
      },
      
      // Maps & Navigation
      {
        name: 'Google Maps',
        packageName: 'com.google.android.apps.maps',
        categories: ['Travel', 'Maps'],
        deepLink: 'googlemaps://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.maps',
        webUrl: 'https://maps.google.com',
        aliases: ['google maps', 'maps', 'gmaps'],
        description: 'Navigation and maps',
      },
      {
        name: 'Uber',
        packageName: 'com.ubercab',
        categories: ['Travel', 'Transportation'],
        deepLink: 'uber://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.ubercab',
        aliases: ['uber'],
        description: 'Ride-sharing service',
      },
      {
        name: 'Ola',
        packageName: 'com.olacabs.customer',
        categories: ['Travel', 'Transportation'],
        deepLink: 'ola://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.olacabs.customer',
        aliases: ['ola'],
        description: 'Ride-sharing app',
      },
      
      // Food & Delivery
      {
        name: 'Zomato',
        packageName: 'com.application.zomato',
        categories: ['Food', 'Delivery'],
        deepLink: 'zomato://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.application.zomato',
        webUrl: 'https://www.zomato.com',
        aliases: ['zomato'],
        description: 'Food delivery and restaurant finder',
      },
      {
        name: 'Swiggy',
        packageName: 'in.swiggy.android',
        categories: ['Food', 'Delivery'],
        deepLink: 'swiggy://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=in.swiggy.android',
        webUrl: 'https://www.swiggy.com',
        aliases: ['swiggy'],
        description: 'Food delivery app',
      },
      {
        name: 'Uber Eats',
        packageName: 'com.ubercab.eats',
        categories: ['Food', 'Delivery'],
        deepLink: 'ubereats://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.ubercab.eats',
        aliases: ['uber eats', 'ubereats'],
        description: 'Food delivery service',
      },
      
      // Photography & Editing
      {
        name: 'Photos',
        packageName: 'com.google.android.apps.photos',
        categories: ['Photo', 'Gallery'],
        deepLink: 'googlephotos://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.photos',
        aliases: ['google photos', 'photos'],
        description: 'Photo storage and editing',
      },
      {
        name: 'Snapseed',
        packageName: 'com.niksoftware.snapseed',
        categories: ['Photo', 'Editing'],
        deepLink: 'snapseed://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.niksoftware.snapseed',
        aliases: ['snapseed'],
        description: 'Photo editing app',
      },
      {
        name: 'VSCO',
        packageName: 'com.vsco.cam',
        categories: ['Photo', 'Editing'],
        deepLink: 'vsco://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.vsco.cam',
        aliases: ['vsco'],
        description: 'Photo editing and sharing',
      },
      {
        name: 'Canva',
        packageName: 'com.canva.editor',
        categories: ['Photo', 'Design'],
        deepLink: 'canva://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.canva.editor',
        webUrl: 'https://www.canva.com',
        aliases: ['canva'],
        description: 'Graphic design tool',
      },
      
      // Development & Programming
      {
        name: 'GitHub',
        packageName: 'com.github.android',
        categories: ['Development', 'Code'],
        deepLink: 'github://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.github.android',
        webUrl: 'https://github.com',
        aliases: ['github', 'git'],
        description: 'Code repository',
      },
      {
        name: 'Stack Overflow',
        packageName: 'com.stackexchange.marvin',
        categories: ['Development', 'Education'],
        deepLink: 'stackoverflow://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.stackexchange.marvin',
        webUrl: 'https://stackoverflow.com',
        aliases: ['stack overflow', 'stackoverflow'],
        description: 'Developer Q&A',
      },
      {
        name: 'Code Editor',
        packageName: 'com.rhmsoft.code',
        categories: ['Development', 'Code'],
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.rhmsoft.code',
        aliases: ['code editor', 'editor'],
        description: 'Code editor for mobile',
      },
      
      // Education & Learning
      {
        name: 'Duolingo',
        packageName: 'com.duolingo',
        categories: ['Education', 'Language'],
        deepLink: 'duolingo://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.duolingo',
        webUrl: 'https://www.duolingo.com',
        aliases: ['duolingo'],
        description: 'Language learning',
      },
      {
        name: 'Khan Academy',
        packageName: 'org.khanacademy.android',
        categories: ['Education', 'Learning'],
        deepLink: 'khanacademy://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=org.khanacademy.android',
        webUrl: 'https://www.khanacademy.org',
        aliases: ['khan academy', 'khan'],
        description: 'Free online courses',
      },
      {
        name: 'Coursera',
        packageName: 'org.coursera.android',
        categories: ['Education', 'Learning'],
        deepLink: 'coursera://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=org.coursera.android',
        webUrl: 'https://www.coursera.org',
        aliases: ['coursera'],
        description: 'Online courses',
      },
      
      // News & Reading
      {
        name: 'Google News',
        packageName: 'com.google.android.apps.magazines',
        categories: ['News', 'Reading'],
        deepLink: 'googlenews://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.magazines',
        webUrl: 'https://news.google.com',
        aliases: ['google news', 'news'],
        description: 'News aggregation',
      },
      {
        name: 'Medium',
        packageName: 'com.medium.reader',
        categories: ['News', 'Reading'],
        deepLink: 'medium://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.medium.reader',
        webUrl: 'https://medium.com',
        aliases: ['medium'],
        description: 'Articles and stories',
      },
      
      // Fitness & Health
      {
        name: 'Google Fit',
        packageName: 'com.google.android.apps.fitness',
        categories: ['Health', 'Fitness'],
        deepLink: 'googlefit://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.fitness',
        aliases: ['google fit', 'fit'],
        description: 'Health and fitness tracking',
      },
      {
        name: 'MyFitnessPal',
        packageName: 'com.myfitnesspal.android',
        categories: ['Health', 'Fitness'],
        deepLink: 'myfitnesspal://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.myfitnesspal.android',
        aliases: ['myfitnesspal', 'fitness pal'],
        description: 'Calorie counter and diet tracker',
      },
      
      // Gaming
      {
        name: 'PUBG Mobile',
        packageName: 'com.tencent.ig',
        categories: ['Gaming'],
        deepLink: 'pubgmobile://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.tencent.ig',
        aliases: ['pubg', 'pubg mobile'],
        description: 'Battle royale game',
      },
      {
        name: 'Free Fire',
        packageName: 'com.dts.freefireth',
        categories: ['Gaming'],
        deepLink: 'freefire://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.dts.freefireth',
        aliases: ['free fire'],
        description: 'Battle royale game',
      },
      {
        name: 'Candy Crush',
        packageName: 'com.king.candycrushsaga',
        categories: ['Gaming', 'Puzzle'],
        deepLink: 'candycrush://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.king.candycrushsaga',
        aliases: ['candy crush'],
        description: 'Puzzle game',
      },
      
      // More Popular Apps
      {
        name: 'Chrome',
        packageName: 'com.android.chrome',
        categories: ['Productivity', 'Browser'],
        deepLink: 'googlechrome://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.android.chrome',
        webUrl: 'https://www.google.com',
        aliases: ['chrome', 'browser', 'google chrome'],
        description: 'Web browser',
      },
      {
        name: 'Firefox',
        packageName: 'org.mozilla.firefox',
        categories: ['Productivity', 'Browser'],
        deepLink: 'firefox://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=org.mozilla.firefox',
        aliases: ['firefox'],
        description: 'Web browser',
      },
      {
        name: 'Opera',
        packageName: 'com.opera.browser',
        categories: ['Productivity', 'Browser'],
        deepLink: 'opera://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.opera.browser',
        aliases: ['opera'],
        description: 'Web browser',
      },
      {
        name: 'Zoom',
        packageName: 'us.zoom.videomeetings',
        categories: ['Communication', 'Video'],
        deepLink: 'zoomus://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=us.zoom.videomeetings',
        webUrl: 'https://zoom.us',
        aliases: ['zoom'],
        description: 'Video conferencing',
      },
      {
        name: 'Skype',
        packageName: 'com.skype.raider',
        categories: ['Communication', 'Video'],
        deepLink: 'skype://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.skype.raider',
        aliases: ['skype'],
        description: 'Video and voice calls',
      },
      {
        name: 'TikTok',
        packageName: 'com.zhiliaoapp.musically',
        categories: ['Social', 'Video'],
        deepLink: 'tiktok://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.zhiliaoapp.musically',
        webUrl: 'https://www.tiktok.com',
        aliases: ['tiktok'],
        description: 'Short video platform',
      },
      {
        name: 'Pinterest',
        packageName: 'com.pinterest',
        categories: ['Social', 'Photo'],
        deepLink: 'pinterest://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.pinterest',
        webUrl: 'https://www.pinterest.com',
        aliases: ['pinterest'],
        description: 'Image discovery and sharing',
      },
      {
        name: 'Shazam',
        packageName: 'com.shazam.android',
        categories: ['Media', 'Music'],
        deepLink: 'shazam://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.shazam.android',
        aliases: ['shazam'],
        description: 'Music identification',
      },
      {
        name: 'SoundCloud',
        packageName: 'com.soundcloud.android',
        categories: ['Media', 'Music'],
        deepLink: 'soundcloud://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.soundcloud.android',
        webUrl: 'https://soundcloud.com',
        aliases: ['soundcloud'],
        description: 'Audio streaming',
      },
      {
        name: 'Adobe Acrobat',
        packageName: 'com.adobe.reader',
        categories: ['Productivity', 'PDF'],
        deepLink: 'adobe://',
        playStoreUrl: 'https://play.google.com/store/apps/details?id=com.adobe.reader',
        aliases: ['adobe acrobat', 'pdf reader'],
        description: 'PDF reader and editor',
      },
    ];

    // Index all apps
    playStoreApps.forEach(app => {
      this.apps.set(app.name.toLowerCase(), app);
      app.aliases.forEach(alias => {
        this.apps.set(alias.toLowerCase(), app);
      });
    });
  }

  /**
   * Search apps by name or category
   */
  searchApps(query: string): PlayStoreApp[] {
    const lowerQuery = query.toLowerCase();
    const results: PlayStoreApp[] = [];
    const found = new Set<string>();

    // Direct match
    const directMatch = this.apps.get(lowerQuery);
    if (directMatch && !found.has(directMatch.name)) {
      results.push(directMatch);
      found.add(directMatch.name);
    }

    // Partial match in name
    for (const app of this.apps.values()) {
      if (found.has(app.name)) continue;
      
      if (app.name.toLowerCase().includes(lowerQuery) ||
          app.aliases.some(alias => alias.toLowerCase().includes(lowerQuery)) ||
          app.description.toLowerCase().includes(lowerQuery) ||
          app.categories.some(cat => cat.toLowerCase().includes(lowerQuery))) {
        results.push(app);
        found.add(app.name);
      }
    }

    return results;
  }

  /**
   * Get apps by category
   */
  getAppsByCategory(category: string): PlayStoreApp[] {
    const lowerCategory = category.toLowerCase();
    const results: PlayStoreApp[] = [];
    const found = new Set<string>();

    for (const app of this.apps.values()) {
      if (found.has(app.name)) continue;
      
      if (app.categories.some(cat => cat.toLowerCase() === lowerCategory)) {
        results.push(app);
        found.add(app.name);
      }
    }

    return results;
  }

  /**
   * Get all categories
   */
  getAllCategories(): string[] {
    const categories = new Set<string>();
    
    for (const app of this.apps.values()) {
      app.categories.forEach(cat => categories.add(cat));
    }
    
    return Array.from(categories).sort();
  }

  /**
   * Find app by name or alias
   */
  findApp(query: string): PlayStoreApp | null {
    const lowerQuery = query.toLowerCase();
    
    // Try direct match first
    const directMatch = this.apps.get(lowerQuery);
    if (directMatch) return directMatch;
    
    // Try partial match
    for (const [key, app] of this.apps.entries()) {
      if (lowerQuery.includes(key) || key.includes(lowerQuery)) {
        return app;
      }
    }
    
    return null;
  }

  /**
   * Get all apps
   */
  getAllApps(): PlayStoreApp[] {
    const uniqueApps = new Map<string, PlayStoreApp>();
    
    for (const app of this.apps.values()) {
      if (!uniqueApps.has(app.name)) {
        uniqueApps.set(app.name, app);
      }
    }
    
    return Array.from(uniqueApps.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * Open app (handles both deep link and Play Store)
   */
  openApp(app: PlayStoreApp, parameters?: Record<string, any>): {
    success: boolean;
    message: string;
    url?: string;
    type: 'deeplink' | 'web' | 'playstore';
  } {
    // Try web URL first (works in browser)
    if (app.webUrl && typeof window !== 'undefined') {
      let url = app.webUrl;
      
      // Add search query if provided
      if (parameters?.query) {
        if (app.name.toLowerCase().includes('google')) {
          url = `https://www.google.com/search?q=${encodeURIComponent(parameters.query)}`;
        } else if (app.name.toLowerCase().includes('youtube')) {
          url = `https://www.youtube.com/results?search_query=${encodeURIComponent(parameters.query)}`;
        }
      }
      
      window.open(url, '_blank');
      
      return {
        success: true,
        message: `Opening ${app.name}${parameters?.query ? ` and searching for "${parameters.query}"` : ''} in browser`,
        url,
        type: 'web',
      };
    }

    // Try deep link (for mobile/desktop apps)
    if (app.deepLink && typeof window !== 'undefined') {
      const deepLink = app.deepLink;
      try {
        // Attempt deep link (will open app if installed)
        window.location.href = deepLink;
        
        // Fallback to Play Store if app not installed
        setTimeout(() => {
          window.open(app.playStoreUrl, '_blank');
        }, 1000);
        
        return {
          success: true,
          message: `Opening ${app.name}${app.packageName ? ' (or Play Store if not installed)' : ''}`,
          url: deepLink,
          type: 'deeplink',
        };
      } catch (error) {
        // If deep link fails, open Play Store
        window.open(app.playStoreUrl, '_blank');
        
        return {
          success: true,
          message: `Opening ${app.name} on Play Store`,
          url: app.playStoreUrl,
          type: 'playstore',
        };
      }
    }

    // Fallback to Play Store
    if (typeof window !== 'undefined') {
      window.open(app.playStoreUrl, '_blank');
      
      return {
        success: true,
        message: `Opening ${app.name} on Play Store`,
        url: app.playStoreUrl,
        type: 'playstore',
      };
    }

    return {
      success: false,
      message: `Cannot open ${app.name}. Please install from Play Store.`,
      type: 'playstore',
    };
  }

  /**
   * Get total app count
   */
  getTotalApps(): number {
    return this.getAllApps().length;
  }
}

// Singleton instance
export const playStoreAppsRegistry = new PlayStoreAppsRegistry();

