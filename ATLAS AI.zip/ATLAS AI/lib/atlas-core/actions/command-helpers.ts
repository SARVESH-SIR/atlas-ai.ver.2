/**
 * ATLAS AI - Command Helpers
 * Utility functions for command parsing and execution
 */

import { appController } from './app-controller';
import { actionExecutor } from './action-executor';

export interface ParsedCommand {
  type: 'app' | 'system' | 'ai' | 'unknown';
  action?: any;
  confidence: number;
}

/**
 * Parse and identify command type
 */
export function parseCommand(command: string): ParsedCommand {
  const lowerCommand = command.toLowerCase().trim();

  // Check app commands
  if (appController.isAppCommand(command)) {
    const appAction = appController.parseCommand(command);
    return {
      type: 'app',
      action: appAction,
      confidence: 0.95,
    };
  }

  // Check system commands
  const systemKeywords = [
    'volume', 'brightness', 'wifi', 'bluetooth', 'screenshot',
    'screen', 'capture', 'open file', 'close',
  ];

  if (systemKeywords.some(keyword => lowerCommand.includes(keyword))) {
    return {
      type: 'system',
      confidence: 0.9,
    };
  }

  // Check if it's a clear action command
  const actionKeywords = [
    'open', 'launch', 'start', 'run', 'search', 'play',
    'send', 'call', 'message', 'email',
  ];

  if (actionKeywords.some(keyword => lowerCommand.includes(keyword))) {
    return {
      type: 'app',
      confidence: 0.7,
    };
  }

  // Default to AI query
  return {
    type: 'ai',
    confidence: 0.5,
  };
}

/**
 * Get command suggestions
 */
export function getCommandSuggestions(partialCommand: string): string[] {
  const lowerPartial = partialCommand.toLowerCase();
  const suggestions: string[] = [];

  // App suggestions
  const apps = appController.getAvailableApps();
  apps.forEach(app => {
    if (app.name.toLowerCase().includes(lowerPartial) ||
        app.aliases.some(alias => alias.toLowerCase().includes(lowerPartial))) {
      suggestions.push(`open ${app.name}`);
      suggestions.push(`search in ${app.name}`);
    }
  });

  // System command suggestions
  if (lowerPartial.includes('vol')) {
    suggestions.push('volume up', 'volume down', 'mute');
  }
  if (lowerPartial.includes('bright')) {
    suggestions.push('brightness up', 'brightness down', 'brightness 50%');
  }
  if (lowerPartial.includes('wifi')) {
    suggestions.push('wifi on', 'wifi off');
  }
  if (lowerPartial.includes('screen')) {
    suggestions.push('take screenshot', 'capture screen');
  }

  return suggestions.slice(0, 5);
}

/**
 * Execute command with proper routing
 */
export async function executeCommand(command: string): Promise<{
  success: boolean;
  message: string;
  type: string;
}> {
  const parsed = parseCommand(command);

  if (parsed.type === 'app' || parsed.type === 'system') {
    return await actionExecutor.executeCommand(command);
  }

  // Default to AI processing
  return {
    success: true,
    message: 'Processing with AI...',
    type: 'ai',
  };
}

