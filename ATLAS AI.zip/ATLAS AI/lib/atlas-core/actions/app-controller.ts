/**
 * ATLAS AI - App Controller
 * Controls applications and performs actions on user's device
 */

import { playStoreAppsRegistry, PlayStoreApp } from './playstore-apps';

export interface AppAction {
  type: 'open_app' | 'close_app' | 'search' | 'navigate' | 'click' | 'type' | 'custom';
  app?: string;
  action?: string;
  parameters?: Record<string, any>;
  requiresConfirmation: boolean;
}

export interface AppInfo {
  name: string;
  aliases: string[];
  platforms: ('web' | 'windows' | 'macos' | 'linux' | 'mobile')[];
  actions: string[];
  url?: string;
  executable?: string;
}

export class AppController {
  private apps: Map<string, AppInfo> = new Map();

  constructor() {
    this.initializeApps();
  }

  /**
   * Check if app exists (local or Play Store)
   */
  hasApp(appName: string): boolean {
    return this.apps.has(appName.toLowerCase()) || 
           playStoreAppsRegistry.findApp(appName) !== null;
  }

  /**
   * Initialize available apps
   */
  private initializeApps() {
    const appDefinitions: AppInfo[] = [
      {
        name: 'Google',
        aliases: ['google', 'chrome', 'browser', 'search'],
        platforms: ['web', 'windows', 'macos', 'linux', 'mobile'],
        actions: ['open', 'search', 'navigate'],
        url: 'https://www.google.com',
      },
      {
        name: 'YouTube',
        aliases: ['youtube', 'yt', 'video', 'watch'],
        platforms: ['web', 'windows', 'macos', 'linux', 'mobile'],
        actions: ['open', 'search', 'play'],
        url: 'https://www.youtube.com',
      },
      {
        name: 'WhatsApp',
        aliases: ['whatsapp', 'wa', 'message'],
        platforms: ['web', 'windows', 'macos', 'mobile'],
        actions: ['open', 'send_message', 'call'],
        url: 'https://web.whatsapp.com',
      },
      {
        name: 'Telegram',
        aliases: ['telegram', 'tg'],
        platforms: ['web', 'windows', 'macos', 'mobile'],
        actions: ['open', 'send_message'],
        url: 'https://web.telegram.org',
      },
      {
        name: 'Gmail',
        aliases: ['gmail', 'email', 'mail'],
        platforms: ['web', 'windows', 'macos', 'mobile'],
        actions: ['open', 'compose', 'search'],
        url: 'https://mail.google.com',
      },
      {
        name: 'Spotify',
        aliases: ['spotify', 'music', 'play music'],
        platforms: ['web', 'windows', 'macos', 'mobile'],
        actions: ['open', 'play', 'pause', 'search'],
        url: 'https://open.spotify.com',
      },
      {
        name: 'Discord',
        aliases: ['discord', 'chat'],
        platforms: ['web', 'windows', 'macos', 'mobile'],
        actions: ['open', 'join', 'message'],
        url: 'https://discord.com/app',
      },
      {
        name: 'Twitter',
        aliases: ['twitter', 'x', 'tweet'],
        platforms: ['web', 'mobile'],
        actions: ['open', 'tweet', 'search'],
        url: 'https://twitter.com',
      },
      {
        name: 'GitHub',
        aliases: ['github', 'git', 'code'],
        platforms: ['web', 'windows', 'macos', 'linux'],
        actions: ['open', 'search', 'clone'],
        url: 'https://github.com',
      },
      {
        name: 'VS Code',
        aliases: ['vscode', 'code', 'editor'],
        platforms: ['windows', 'macos', 'linux'],
        actions: ['open', 'open_file', 'open_folder'],
        executable: 'code',
      },
      {
        name: 'Calculator',
        aliases: ['calculator', 'calc'],
        platforms: ['windows', 'macos', 'linux', 'mobile'],
        actions: ['open'],
        executable: 'calc',
      },
      {
        name: 'Notepad',
        aliases: ['notepad', 'notes', 'text editor'],
        platforms: ['windows'],
        actions: ['open', 'open_file'],
        executable: 'notepad',
      },
    ];

    appDefinitions.forEach(app => {
      this.apps.set(app.name.toLowerCase(), app);
      app.aliases.forEach(alias => {
        this.apps.set(alias.toLowerCase(), app);
      });
    });
  }

  /**
   * Parse command and extract app action
   */
  parseCommand(command: string): AppAction | null {
    const lowerCommand = command.toLowerCase().trim();

    // Extract app name
    const appInfo = this.findApp(lowerCommand);
    if (!appInfo) return null;

    // Extract action
    let action: AppAction['type'] = 'open_app';
    let parameters: Record<string, any> = {};
    let requiresConfirmation = false;

    // Check for specific actions
    if (lowerCommand.includes('search')) {
      action = 'search';
      const searchQuery = this.extractSearchQuery(lowerCommand);
      parameters = { query: searchQuery };
    } else if (lowerCommand.includes('close') || lowerCommand.includes('exit')) {
      action = 'close_app';
      requiresConfirmation = false;
    } else if (lowerCommand.includes('send') || lowerCommand.includes('message')) {
      action = 'custom';
      parameters = { action: 'send_message', message: this.extractMessage(lowerCommand) };
      requiresConfirmation = true;
    } else if (lowerCommand.includes('play')) {
      action = 'custom';
      parameters = { action: 'play', query: this.extractSearchQuery(lowerCommand) };
    } else if (lowerCommand.includes('open') || lowerCommand.includes('launch')) {
      action = 'open_app';
    }

    return {
      type: action,
      app: appInfo.name,
      action: action === 'custom' ? parameters.action : undefined,
      parameters,
      requiresConfirmation,
    };
  }

  /**
   * Find app from command
   */
  private findApp(command: string): AppInfo | null {
    // First check local apps
    for (const [key, app] of this.apps.entries()) {
      if (command.includes(key)) {
        return app;
      }
    }
    
    // Then check Play Store apps
    const playStoreApp = playStoreAppsRegistry.findApp(command);
    if (playStoreApp) {
      // Convert PlayStoreApp to AppInfo
      return {
        name: playStoreApp.name,
        aliases: playStoreApp.aliases,
        platforms: ['web', 'windows', 'macos', 'linux', 'mobile'],
        actions: ['open', 'search', 'navigate'],
        url: playStoreApp.webUrl || playStoreApp.playStoreUrl,
      };
    }
    
    return null;
  }

  /**
   * Extract search query from command
   */
  private extractSearchQuery(command: string): string {
    const searchKeywords = ['search', 'for', 'find', 'look for'];
    
    for (const keyword of searchKeywords) {
      const index = command.indexOf(keyword);
      if (index !== -1) {
        const query = command.substring(index + keyword.length).trim();
        // Remove app name and common words
        return query.replace(/^(in|on|at)\s+/i, '').trim();
      }
    }

    // If no search keyword, extract after app name
    const appMatch = command.match(/(?:open|launch|search)\s+\w+\s+(.+)/);
    return appMatch ? appMatch[1].trim() : '';
  }

  /**
   * Extract message from command
   */
  private extractMessage(command: string): string {
    const messageKeywords = ['message', 'send', 'text', 'say'];
    
    for (const keyword of messageKeywords) {
      const index = command.indexOf(keyword);
      if (index !== -1) {
        const toIndex = command.indexOf(' to ');
        const message = command.substring(index + keyword.length, toIndex !== -1 ? toIndex : command.length).trim();
        return message.replace(/^(to|that|a)\s+/i, '').trim();
      }
    }

    return '';
  }

  /**
   * Execute app action
   */
  async executeAction(action: AppAction): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    try {
      switch (action.type) {
        case 'open_app':
          return await this.openApp(action.app!, action.parameters);
        
        case 'close_app':
          return await this.closeApp(action.app!);
        
        case 'search':
          return await this.searchInApp(action.app!, action.parameters?.query);
        
        case 'custom':
          return await this.executeCustomAction(action.app!, action.action!, action.parameters);
        
        default:
          return {
            success: false,
            message: `Unknown action type: ${action.type}`,
          };
      }
    } catch (error: any) {
      return {
        success: false,
        message: `Error executing action: ${error.message}`,
      };
    }
  }

  /**
   * Open app (supports both local and Play Store apps)
   */
  private async openApp(appName: string, parameters?: Record<string, any>): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    // Try local apps first
    let appInfo = this.apps.get(appName.toLowerCase());
    
    // If not found, try Play Store apps
    if (!appInfo) {
      const playStoreApp = playStoreAppsRegistry.findApp(appName);
      if (playStoreApp) {
        // Use Play Store app opening logic
        const result = playStoreAppsRegistry.openApp(playStoreApp, parameters);
        
        return {
          success: result.success,
          message: result.message,
          action: `opened_${playStoreApp.name.toLowerCase()}`,
        };
      }
      
      return {
        success: false,
        message: `App "${appName}" not found. Try searching in Play Store.`,
      };
    }

    // In browser environment, open URL
    if (typeof window !== 'undefined') {
      if (appInfo.url) {
        let url = appInfo.url;
        
        // Add search query to URL if provided
        if (parameters?.query) {
          if (appName.toLowerCase() === 'google' || appName.toLowerCase() === 'chrome') {
            url = `https://www.google.com/search?q=${encodeURIComponent(parameters.query)}`;
          } else if (appName.toLowerCase() === 'youtube') {
            url = `https://www.youtube.com/results?search_query=${encodeURIComponent(parameters.query)}`;
          } else if (appName.toLowerCase().includes('search')) {
            // Generic search URL
            url = `https://www.google.com/search?q=${encodeURIComponent(parameters.query)}`;
          }
        }

        window.open(url, '_blank');
        
        return {
          success: true,
          message: `Opening ${appInfo.name}${parameters?.query ? ` and searching for "${parameters.query}"` : ''}`,
          action: `opened_${appInfo.name.toLowerCase()}`,
        };
      }
    }

    // For desktop apps (would need Electron/desktop integration)
    return {
      success: false,
      message: `Desktop app control requires additional setup. For web apps, I've provided the URL.`,
    };
  }

  /**
   * Close app
   */
  private async closeApp(appName: string): Promise<{
    success: boolean;
    message: string;
  }> {
    return {
      success: true,
      message: `Closing ${appName}. (Note: In browser, you'll need to close the tab manually)`,
    };
  }

  /**
   * Search in app
   */
  private async searchInApp(appName: string, query?: string): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    if (!query) {
      return {
        success: false,
        message: 'Search query is required',
      };
    }

    return await this.openApp(appName, { query });
  }

  /**
   * Execute custom action
   */
  private async executeCustomAction(appName: string, action: string, parameters?: Record<string, any>): Promise<{
    success: boolean;
    message: string;
    action?: string;
  }> {
    const appInfo = this.apps.get(appName.toLowerCase());
    
    if (!appInfo) {
      return {
        success: false,
        message: `App "${appName}" not found`,
      };
    }

    switch (action) {
      case 'send_message':
        return {
          success: true,
          message: `Prepared to send message "${parameters?.message}" via ${appName}. Please confirm.`,
          action: `message_prepared`,
        };
      
      case 'play':
        return {
          success: true,
          message: `Playing "${parameters?.query}" on ${appName}`,
          action: `play_${appName.toLowerCase()}`,
        };
      
      default:
        return {
          success: false,
          message: `Unknown custom action: ${action}`,
        };
    }
  }

  /**
   * Get available apps (includes Play Store apps)
   */
  getAvailableApps(): AppInfo[] {
    const uniqueApps = new Map<string, AppInfo>();
    
    // Add local apps
    for (const app of this.apps.values()) {
      if (!uniqueApps.has(app.name)) {
        uniqueApps.set(app.name, app);
      }
    }
    
    // Add Play Store apps
    const playStoreApps = playStoreAppsRegistry.getAllApps();
    playStoreApps.forEach(psApp => {
      if (!uniqueApps.has(psApp.name)) {
        uniqueApps.set(psApp.name, {
          name: psApp.name,
          aliases: psApp.aliases,
          platforms: ['web', 'mobile'],
          actions: ['open', 'search', 'navigate'],
          url: psApp.webUrl || psApp.playStoreUrl,
        });
      }
    });
    
    return Array.from(uniqueApps.values()).sort((a, b) => a.name.localeCompare(b.name));
  }
  
  /**
   * Get Play Store apps only
   */
  getPlayStoreApps(): PlayStoreApp[] {
    return playStoreAppsRegistry.getAllApps();
  }
  
  /**
   * Search Play Store apps
   */
  searchPlayStoreApps(query: string): PlayStoreApp[] {
    return playStoreAppsRegistry.searchApps(query);
  }

  /**
   * Check if command is an app command
   */
  isAppCommand(command: string): boolean {
    return this.parseCommand(command) !== null;
  }

  /**
   * Get command examples
   */
  getCommandExamples(): Array<{ command: string; description: string }> {
    return [
      { command: 'open Google', description: 'Opens Google in browser' },
      { command: 'open YouTube', description: 'Opens YouTube' },
      { command: 'search AI in Google', description: 'Searches for AI on Google' },
      { command: 'open WhatsApp', description: 'Opens WhatsApp Web' },
      { command: 'launch VS Code', description: 'Opens VS Code editor' },
      { command: 'play music on Spotify', description: 'Opens Spotify' },
      { command: 'open Gmail', description: 'Opens Gmail' },
      { command: 'volume up', description: 'Increases volume' },
      { command: 'brightness 75%', description: 'Sets brightness to 75%' },
      { command: 'take screenshot', description: 'Captures screen' },
    ];
  }
}

// Singleton instance
export const appController = new AppController();

