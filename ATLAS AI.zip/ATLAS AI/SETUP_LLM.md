# 🔌 Setting Up ChatGPT/OpenAI Integration

## Quick Setup Guide

### Step 1: Get OpenAI API Key

1. **Visit OpenAI Platform**
   - Go to: https://platform.openai.com/api-keys
   - Sign up or log in

2. **Create API Key**
   - Click "Create new secret key"
   - Give it a name (e.g., "ATLAS AI")
   - Copy the key immediately (you won't see it again!)

3. **Add Credits** (if needed)
   - Go to: https://platform.openai.com/account/billing
   - Add payment method
   - Add credits (minimum $5 recommended)

---

### Step 2: Configure Environment

1. **Create `.env.local` file** in project root:
   ```bash
   # In project root directory
   touch .env.local
   ```

2. **Add your API key**:
   ```env
   OPENAI_API_KEY=sk-...your-key-here...
   NODE_ENV=development
   ```

3. **Important**: Never commit `.env.local` to git (it's already in .gitignore)

---

### Step 3: Verify Installation

1. **Restart Development Server**
   ```bash
   # Stop current server (Ctrl+C)
   npm run dev
   ```

2. **Check Status**
   - Open: http://localhost:3000
   - Look at "Knowledge Brains Status" panel
   - Should show: "OpenAI: Active" or green status

3. **Test Chat**
   - Open AI Chat Interface
   - Send a message
   - Should get ChatGPT-powered response

---

### Step 4: Test Integration

**Test in Chat**:
```
You: "Hello ATLAS, explain quantum computing"
ATLAS: [Enhanced ChatGPT response]
```

**Check API Status**:
```bash
curl http://localhost:3000/api/atlas/llm/status
```

Should return:
```json
{
  "success": true,
  "llm": {
    "isConfigured": true,
    "defaultAdapter": "openai"
  }
}
```

---

## 🎯 Available Models

ATLAS AI supports these OpenAI models:

### **Recommended Models**
- **gpt-4-turbo-preview** (Default) - Best quality
- **gpt-4** - High quality, reliable
- **gpt-4o** - Latest GPT-4 variant

### **Cost-Effective Models**
- **gpt-3.5-turbo** - Fast, cost-effective
- **gpt-4o-mini** - Budget-friendly GPT-4

### **Model Selection**
Models are configured in `lib/atlas-core/llm/openai-client.ts`:
```typescript
const model = options?.model || 'gpt-4-turbo-preview';
```

---

## 💰 Cost Estimation

### **Approximate Costs** (as of 2024)

**GPT-4 Turbo**:
- Input: ~$10 per 1M tokens
- Output: ~$30 per 1M tokens
- Average conversation: $0.01-0.05

**GPT-3.5 Turbo**:
- Much cheaper: ~$0.001-0.002 per conversation

### **Tips to Save**
- Use GPT-3.5 for simple queries
- Use GPT-4 for complex reasoning
- Monitor usage in OpenAI dashboard
- Set usage limits

---

## 🔍 Troubleshooting

### **Problem: "OpenAI client is not configured"**

**Solution**:
1. Check `.env.local` exists
2. Verify `OPENAI_API_KEY=sk-...` is correct
3. Restart dev server
4. Check no spaces around `=`

### **Problem: "API rate limit exceeded"**

**Solution**:
1. Check OpenAI dashboard for usage
2. Wait a few minutes
3. Add more credits if needed
4. Consider using GPT-3.5 for high volume

### **Problem: "Invalid API key"**

**Solution**:
1. Verify key starts with `sk-`
2. Check for typos
3. Regenerate key if needed
4. Ensure no extra spaces

### **Problem: "Module not found: openai"**

**Solution**:
```bash
npm install openai
```

---

## 🔐 Security Best Practices

1. ✅ **Never commit** `.env.local` to git
2. ✅ **Use environment variables** (not hardcoded)
3. ✅ **Rotate keys** periodically
4. ✅ **Set usage limits** in OpenAI dashboard
5. ✅ **Monitor usage** regularly

---

## 📊 Usage Monitoring

### **Check Usage**
1. Go to: https://platform.openai.com/usage
2. View token usage
3. Set up usage limits
4. Monitor spending

### **Set Limits**
1. Go to: https://platform.openai.com/account/limits
2. Set hard limits
3. Get alerts

---

## ✅ Verification Checklist

- [ ] OpenAI account created
- [ ] API key generated
- [ ] `.env.local` file created
- [ ] API key added to `.env.local`
- [ ] Dev server restarted
- [ ] Status shows "OpenAI: Active"
- [ ] Chat interface working
- [ ] Getting ChatGPT responses

---

## 🎉 Success!

Once configured, ATLAS AI will:
- ✅ Use ChatGPT for enhanced responses
- ✅ Combine with knowledge brains
- ✅ Provide higher quality answers
- ✅ Support streaming responses
- ✅ Work across all features

**"Good day, Sir. ChatGPT integration is now active and ready."** 🤖✨

---

**Need Help?**
- Check `ARCHITECTURE.md` for technical details
- Review `lib/atlas-core/llm/openai-client.ts` for implementation
- Visit OpenAI docs: https://platform.openai.com/docs

