'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ArcReactor from '@/components/ArcReactor';
import SystemMonitor from '@/components/SystemMonitor';
import WeatherPanel from '@/components/WeatherPanel';
import CommandCenter from '@/components/CommandCenter';
import VoiceInterface from '@/components/VoiceInterface';
import NavigationRing from '@/components/NavigationRing';
import StatusBar from '@/components/StatusBar';
import WelcomeAnimation from '@/components/WelcomeAnimation';
import AIChatInterface from '@/components/AIChatInterface';
import TaskManager from '@/components/TaskManager';
import QuickActions from '@/components/QuickActions';
import NotificationsPanel from '@/components/NotificationsPanel';
import DeviceDetector from '@/components/DeviceDetector';
import SearchPanel from '@/components/SearchPanel';
import KnowledgeBrainsStatus from '@/components/KnowledgeBrainsStatus';
import AppControlPanel from '@/components/AppControlPanel';
import AvailableApps from '@/components/AvailableApps';
import PlayStoreAppsBrowser from '@/components/PlayStoreAppsBrowser';
import ProactiveSuggestions from '@/components/ProactiveSuggestions';
import SmartAutomationPanel from '@/components/SmartAutomationPanel';
import SmartHomeControl from '@/components/SmartHomeControl';
import { useSystemStats } from '@/hooks/useSystemStats';

export default function Home() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [userName] = useState('K.V.SARVESH');
  const [systemStatus, setSystemStatus] = useState('Initializing...');
  const systemStats = useSystemStats();

  useEffect(() => {
    // Simulate startup sequence
    const startupSequence = [
      { status: 'Loading Core Modules...', delay: 500 },
      { status: 'Establishing Secure Connection...', delay: 800 },
      { status: 'Activating Quantum Kernel...', delay: 600 },
      { status: 'All Systems Online', delay: 500 },
    ];

    let currentIndex = 0;
    const timer = setInterval(() => {
      if (currentIndex < startupSequence.length) {
        setSystemStatus(startupSequence[currentIndex].status);
        if (currentIndex === startupSequence.length - 1) {
          setIsInitialized(true);
          clearInterval(timer);
        }
        currentIndex++;
      }
    }, startupSequence[0].delay);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-gradient-to-br from-atlas-darker via-atlas-dark to-atlas-darker">
      {/* Background Grid Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="h-full w-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 217, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 217, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Animated Glow Orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-20 left-20 w-96 h-96 bg-atlas-primary rounded-full opacity-20 blur-3xl"
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute bottom-20 right-20 w-96 h-96 bg-atlas-accent rounded-full opacity-20 blur-3xl"
          animate={{
            x: [0, -100, 0],
            y: [0, -50, 0],
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen p-4 md:p-8">
        {/* Status Bar */}
        <StatusBar userName={userName} systemStatus={systemStatus} />

        {/* Notifications Panel */}
        <NotificationsPanel />

        {/* Welcome Animation Overlay */}
        <AnimatePresence>
          {!isInitialized && (
            <WelcomeAnimation userName={userName} systemStatus={systemStatus} />
          )}
        </AnimatePresence>

        {/* Main Layout */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: isInitialized ? 1 : 0 }}
          transition={{ duration: 1 }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-4"
        >
          {/* Left Panel - System Monitoring */}
          <div className="lg:col-span-3 space-y-4">
            <SystemMonitor />
          </div>

          {/* Center Panel - Arc Reactor & Main Interface */}
          <div className="lg:col-span-6 space-y-4 flex flex-col items-center justify-center">
            {/* Arc Reactor */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 1, type: "spring", stiffness: 200 }}
            >
              <ArcReactor />
            </motion.div>

            {/* Navigation Ring */}
            <NavigationRing />

            {/* Voice Interface */}
            <VoiceInterface />
          </div>

          {/* Right Panel - Weather & Controls */}
          <div className="lg:col-span-3 space-y-4">
            <ProactiveSuggestions />
            <WeatherPanel />
            <SmartHomeControl />
            <SmartAutomationPanel />
            <KnowledgeBrainsStatus />
            <AppControlPanel />
            <PlayStoreAppsBrowser />
            <AvailableApps />
            <SearchPanel />
            <DeviceDetector />
            <CommandCenter />
          </div>
        </motion.div>

        {/* Bottom Section - Additional Controls */}
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: isInitialized ? 1 : 0 }}
          transition={{ delay: 1.5 }}
          className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {/* Quick Actions */}
          <QuickActions />
          
          {/* Task Manager */}
          <TaskManager />
          {/* Network Traffic - Auto-updating */}
          <div className="hologram-effect rounded-lg p-4">
            <h3 className="text-atlas-primary text-sm font-semibold mb-2 glow-text">
              NETWORK TRAFFIC
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>UP</span>
                <span className="text-atlas-accent">{systemStats.network.uploadSpeed.toFixed(1)} KB/s</span>
              </div>
              <div className="w-full h-2 bg-atlas-dark rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-atlas-primary to-atlas-accent"
                  animate={{ width: `${systemStats.network.upload}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
              <div className="flex justify-between text-xs mt-2">
                <span>DOWN</span>
                <span className="text-atlas-accent">{systemStats.network.downloadSpeed.toFixed(1)} KB/s</span>
              </div>
              <div className="w-full h-2 bg-atlas-dark rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-atlas-secondary to-atlas-primary"
                  animate={{ width: `${systemStats.network.download}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </div>

          {/* System Usage - Auto-updating */}
          <div className="hologram-effect rounded-lg p-4">
            <h3 className="text-atlas-primary text-sm font-semibold mb-2 glow-text">
              SYSTEM USAGE
            </h3>
            <motion.div
              key={Math.round((systemStats.cpu.usage + systemStats.memory.usage + systemStats.gpu.usage) / 3)}
              className="text-3xl font-bold text-atlas-accent glow-text"
              initial={{ scale: 1.1 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              {Math.round((systemStats.cpu.usage + systemStats.memory.usage + systemStats.gpu.usage) / 3)}%
            </motion.div>
            <p className="text-xs text-atlas-primary mt-1">Average CPU/Memory/GPU</p>
          </div>

          {/* ATLAS AI Footer */}
          <div className="flex items-center justify-center">
            <motion.div
              className="text-atlas-primary text-xl font-bold glow-text"
              animate={{
                textShadow: [
                  "0 0 10px rgba(0, 217, 255, 0.8)",
                  "0 0 20px rgba(0, 217, 255, 1)",
                  "0 0 10px rgba(0, 217, 255, 0.8)",
                ],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              ATLAS AI SYSTEMS
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* AI Chat Interface - Floating */}
      <AIChatInterface />

      {/* Scan Lines Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <motion.div
          className="absolute w-full h-1 bg-atlas-primary"
          animate={{
            top: ["0%", "100%"],
            opacity: [0.5, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      </div>
    </div>
  );
}

