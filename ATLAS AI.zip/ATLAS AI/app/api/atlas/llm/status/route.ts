/**
 * ATLAS AI - LLM Status API
 * Check LLM adapter status and configuration
 */

import { NextRequest, NextResponse } from 'next/server';
import { llmAdapterManager } from '@/lib/atlas-core/llm/llm-adapter';

export async function GET(request: NextRequest) {
  try {
    const adapterStatus = llmAdapterManager.getAdapterStatus();
    const availableAdapters = llmAdapterManager.getAvailableAdapters();
    const defaultAdapter = llmAdapterManager.getDefaultAdapter();

    return NextResponse.json({
      success: true,
      llm: {
        availableAdapters,
        adapterStatus,
        defaultAdapter: defaultAdapter?.isReady() ? 'openai' : null,
        isConfigured: defaultAdapter?.isReady() || false,
        recommendations: !defaultAdapter?.isReady() 
          ? [
              'Add OPENAI_API_KEY to your .env.local file',
              'Get API key from https://platform.openai.com/api-keys',
              'Restart your development server after adding the key',
            ]
          : ['LLM is configured and ready'],
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Unknown error',
      },
      { status: 500 }
    );
  }
}

