/**
 * ATLAS AI Chat API Route
 * Server-side route for ChatGPT/OpenAI integration
 */

import { NextRequest, NextResponse } from 'next/server';
import { atlasAIEngine } from '@/lib/atlas-core/ai-engine';
import { llmAdapterManager } from '@/lib/atlas-core/llm/llm-adapter';

export async function POST(request: NextRequest) {
  try {
    const { message, userId = 'creator', context, stream = false } = await request.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      );
    }

    // Check if streaming is requested
    if (stream) {
      const llmAdapter = llmAdapterManager.getDefaultAdapter();
      
      if (llmAdapter && llmAdapter.isReady() && llmAdapter.generateStreamingResponse) {
        // Setup streaming response
        const encoder = new TextEncoder();
        const stream = new ReadableStream({
          async start(controller) {
            try {
              for await (const chunk of llmAdapter.generateStreamingResponse!(message, context, { userId })) {
                const data = JSON.stringify({
                  content: chunk.content,
                  done: chunk.done,
                });
                controller.enqueue(encoder.encode(`data: ${data}\n\n`));
                
                if (chunk.done) {
                  controller.close();
                }
              }
            } catch (error: any) {
              controller.error(error);
            }
          },
        });

        return new Response(stream, {
          headers: {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
          },
        });
      }
    }

    // Regular non-streaming response
    const response = await atlasAIEngine.processQuery(userId, message, context);

    return NextResponse.json({
      success: true,
      response: response.text,
      reasoning: response.reasoning,
      actions: response.actions,
      confidence: response.confidence,
      usage: response.usage,
    });
  } catch (error: any) {
    console.error('ATLAS AI Chat Error:', error);
    
    // Provide helpful error messages
    let errorMessage = 'Failed to process query';
    let statusCode = 500;

    if (error.message?.includes('API key') || error.message?.includes('not configured')) {
      errorMessage = 'OpenAI API key not configured. Please add OPENAI_API_KEY to environment variables.';
      statusCode = 503;
    } else if (error.message?.includes('rate limit')) {
      errorMessage = 'API rate limit exceeded. Please try again later.';
      statusCode = 429;
    }

    return NextResponse.json(
      {
        error: errorMessage,
        message: error.message || 'Unknown error',
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined,
      },
      { status: statusCode }
    );
  }
}

export async function GET() {
  const adapterStatus = llmAdapterManager.getAdapterStatus();
  const availableAdapters = llmAdapterManager.getAvailableAdapters();

  return NextResponse.json({
    message: 'ATLAS AI Chat API',
    version: '1.2.5',
    status: 'operational',
    llm: {
      adapters: availableAdapters,
      status: adapterStatus,
      default: adapterStatus.openai ? 'openai' : 'none',
    },
    endpoints: {
      POST: '/api/atlas/chat - Send a message to ATLAS',
      GET: '/api/atlas/chat - Get API status',
    },
  });
}
